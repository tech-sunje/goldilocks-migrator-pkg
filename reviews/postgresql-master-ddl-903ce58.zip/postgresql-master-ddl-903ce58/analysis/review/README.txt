각 .review.txt: 원문과 간단한 주석/확인 사유
변환 SQL: ../converted/
상세 보고서: ../reports/
전체 내역: ../changes.json
