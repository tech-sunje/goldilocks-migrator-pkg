# PostgreSQL master 객체 생성 SQL 예비 분석

원본: `903ce587e665af18ef1af24b4632e5ed4bf78edc` / 소스 버전: **20devel** / 분석 도구: **0.1.43, PG18 프로필**.

PG20 프로필 요청은 실제로 거부되었습니다. 따라서 아래는 master 지원 인증이 아니라 기존 PG18 규칙을 적용한 예비 분석입니다. PostgreSQL·GOLDILOCKS에서 SQL을 실행하지 않았습니다.

선정 범위: create_*.sql 16개와 객체 정의 중심의 추가 회귀 파일 17개. 기존 Lexer의 원본 위치 토큰을 활용하고 검토 harness에서 SQL 표준 본문 경계를 보강하여 최상위 CREATE 입력을 골랐습니다. ALTER·DROP·SELECT·INSERT·psql 명령은 별도 분석 대상에서 제외했습니다. 루틴 본문 내부 문장은 원문 그대로 포함됩니다. 전체 regress/sql 파일을 모두 분석한 결과는 아닙니다.

회귀 파일에는 의도적인 오류, 같은 이름 재생성, 권한/선행 객체/psql 분기에 의존하는 문장이 섞여 있습니다. 개별 CREATE 추출은 그 실행 문맥을 재현하지 않습니다. 자동 분류는 원본이나 대상에서 실행 성공을 뜻하지 않으며 검토 판정도 대상 미지원 확정이 아닙니다.

총 **33개 파일 / 3033개 CREATE 입력**. 자동 변환 분류 571개, 호환 분류 191개, 추가/수동 검토 2270개, 차단 1개. 입력 CREATE 기준이며 finding 건수 및 엔진 내부 분리 단위 3,049개와 구분합니다.

## 추출 경계의 추가 한계

BEGIN ATOMIC 포함 13개를 확인하고, 기존 추출에서 잘렸던 12개의 원문 범위를 harness에서 END까지 보정했다. CASE END와 중첩 ATOMIC·인용·주석·후속 객체의 합성 회귀 및 3,033개 원본 범위 roundtrip을 검증했다. 프로덕션 엔진의 splitter는 수정하지 않아 완전한 CREATE 입력 3,033개에서 내부 분리 단위 3,049개가 나온다. 12개는 엔진 프레이밍 문제로 별도 표시했다(framing-candidates.csv). 이 파서 경고를 대상 DB 미지원으로 해석하지 않는다.

## 분석 설정 격리와 초기 집계 정정

초기 일괄 실행에서는 event_trigger__0025.sql 및 __0026.sql의 내부 동적 DDL 분석이 공유 Config.source를 postgresql에서 altibase로 변경하는 현상을 재현했다. DynamicSql.ddl이 같은 설정으로 Analyzer.analyze를 호출하고 Analyzer가 source를 덮어쓰는 경로다. 이후 파일의 원본 언어 판정과 보고서 메타데이터에 영향을 줄 수 있으므로 초기 집계는 철회하고 initial-batch-unreliable/에 보존했다.

정본 analysis/는 문장마다 새 설정을 만든 IsolatedAnalysis harness 결과다. 프로필 누출을 엔진에서 수정한 것은 아니며, 단일 루틴 내부의 변환 결과도 검토 대상이다. 프로그램 자체를 이 문제에 대해 수정했다거나 전체 PostgreSQL 의미 검증을 완료했다고 보고하지 않는다.

재현 로그: source-isolation-probe.log. 매뉴얼 재대조: MANUAL_RECHECK.md, 모든 MANUAL finding 연결: manual-recheck.csv.

## 파일별 목록

| 원본 파일 | CREATE 수 | 자동 변환 | 호환 | 검토 | 차단 |
|---|---:|---:|---:|---:|---:|
| create_aggregate.sql | 43 | 0 | 0 | 43 | 0 |
| create_am.sql | 48 | 4 | 2 | 42 | 0 |
| create_cast.sql | 12 | 0 | 0 | 12 | 0 |
| create_function_c.sql | 3 | 0 | 0 | 3 | 0 |
| create_function_sql.sql | 74 | 10 | 3 | 61 | 0 |
| create_index.sql | 154 | 60 | 6 | 87 | 1 |
| create_index_spgist.sql | 16 | 0 | 0 | 16 | 0 |
| create_misc.sql | 6 | 1 | 0 | 5 | 0 |
| create_operator.sql | 37 | 0 | 6 | 31 | 0 |
| create_procedure.sql | 26 | 2 | 0 | 24 | 0 |
| create_role.sql | 48 | 3 | 7 | 38 | 0 |
| create_schema.sql | 20 | 0 | 0 | 20 | 0 |
| create_table.sql | 228 | 55 | 0 | 173 | 0 |
| create_table_like.sql | 78 | 13 | 3 | 62 | 0 |
| create_type.sql | 51 | 1 | 0 | 50 | 0 |
| create_view.sql | 148 | 34 | 55 | 59 | 0 |
| domain.sql | 114 | 2 | 2 | 110 | 0 |
| enum.sql | 17 | 1 | 0 | 16 | 0 |
| event_trigger.sql | 104 | 26 | 5 | 73 | 0 |
| event_trigger_login.sql | 3 | 0 | 0 | 3 | 0 |
| foreign_data.sql | 124 | 9 | 12 | 103 | 0 |
| generated_stored.sql | 148 | 16 | 2 | 130 | 0 |
| generated_virtual.sql | 152 | 16 | 2 | 134 | 0 |
| identity.sql | 51 | 9 | 2 | 40 | 0 |
| matview.sql | 66 | 8 | 12 | 46 | 0 |
| publication.sql | 232 | 53 | 18 | 161 | 0 |
| replica_identity.sql | 18 | 12 | 0 | 6 | 0 |
| rowsecurity.sql | 218 | 56 | 13 | 149 | 0 |
| rules.sql | 168 | 57 | 16 | 95 | 0 |
| sequence.sql | 52 | 12 | 18 | 22 | 0 |
| subscription.sql | 69 | 2 | 1 | 66 | 0 |
| tablespace.sql | 64 | 29 | 1 | 34 | 0 |
| triggers.sql | 441 | 80 | 5 | 356 | 0 |

## 우선 검토할 실제 사례

1. **차단 오탐 후보 — create_index.sql:557**: CREATE TEMP TABLE ... ON COMMIT DROP가 최상위 DROP 안전 규칙에 차단됩니다. `Safety.destructive`가 깊이 0의 DROP 단어를 검사하면서 명령 시작과 절 내부 키워드를 구분하지 않는 것을 확인했습니다. CREATE 내부 ON COMMIT DROP를 제거하는 방식으로 해결하면 안 됩니다. 매뉴얼의 대상 GTT는 PRESERVE/DELETE ROWS만 명시하므로 차단 사유를 교정해도 DROP 동작의 원문 호환은 확정할 수 없습니다.
2. **원본 오류 사례의 자동 분류 — create_table.sql:87**: 원본 주석에 invalid use of aggregate로 명시된 DEFAULT (avg(1))가 자동 변환 분류이며 변환 SQL에도 그대로 남습니다. 열 DEFAULT 문법 인식과 함수 사용 문맥의 의미 검증을 구분해야 합니다. 대상 DB의 실제 오류는 이번에 실행 확인하지 않았습니다.
3. **IDENTITY의 포괄 경고 및 NULL 충돌 — identity.sql:480~481**: 초기 잘못된 배치 결과에서는 자동 분류였으나 설정 격리 정본에서는 검토 대상입니다. 정상 IDENTITY도 GENERATED 포괄 경고에 걸리는 27개 finding을 별도로 확인했습니다. 대상은 IDENTITY를 지원하고 암묵적으로 NOT NULL로 취급하지만 원본의 명시적 NULL·복수 IDENTITY·다른 동반 기능은 별도 검사해야 합니다.

위 사항은 발견 내역이며 이번 조사에서 변환 엔진을 수정하지 않았습니다. 원본 주석의 fail/error만으로 전후 모든 CREATE를 오류로 자동 분류하지 않았습니다.

## 검토 규칙 상위 항목

| 규칙 | 검토 finding 수 |
|---|---:|
| PG_TABLE_FEATURE_REVIEW | 578 |
| PG_OBJECT_FEATURE_REVIEW | 485 |
| TYPE_REVIEW | 479 |
| PG_TRIGGER_FUNCTION_REVIEW | 233 |
| COLUMN_CLAUSE_REVIEW | 205 |
| STORAGE_REVIEW | 204 |
| SYNTAX_REVIEW | 165 |
| PG_ROUTINE_RETURN_REVIEW | 125 |
| PG_PUBLICATION_UNSUPPORTED | 125 |
| PG_TYPE_REVIEW | 115 |
| INDEX_REVIEW | 78 |
| PG_ROUTINE_LANGUAGE_REVIEW | 74 |
| PG_ROLE_OPTION_REVIEW | 70 |
| PG_INDEX_OPTION_REVIEW | 44 |
| CTAS_REVIEW | 42 |

파일별 원본 및 SHA256은 provenance.json, 문장별 원본 위치는 input/manifest.json, 문장별 분류·사유·링크는 cases.csv, 상세 원문/변환 비교는 analysis/reports/report.html에 있습니다. POSTGRESQL-COPYRIGHT를 함께 보관합니다.

## PostgreSQL CREATE 수동검토 매뉴얼 재대조

공식 GOLDILOCKS 매뉴얼 고정 커밋: `f5976dfdb7296116f2aa988746c3e375993b4825`. SQL·내장 자료형/함수·PSM 함수/프로시저·외부 루틴·트리거·RETURN TABLE·EXECUTE IMMEDIATE 장을 확인했다.

설정을 격리한 정본 3,033개 CREATE 중 MANUAL finding **2314개 / 규칙 37종 / 해당 문장 1992개**를 규칙별로 재대조하고 모든 finding에 근거와 재검토 설명을 연결했다. 각 문장 전체의 의미를 수동 실행 검증했다는 뜻은 아니다. CONFIRM 전 항목의 개별 의미 검증 완료로 확대해서도 안 된다.

BEGIN ATOMIC 포함 13개 중 추출에서 잘렸던 12개 범위를 검토 harness에서 END까지 보정했다. 원본 전체 입력은 보존했으나 엔진은 같은 12개를 여러 단위로 분리한다. 이 엔진 프레이밍 오류를 대상 미지원으로 치환하지 않았으며 framing-candidates.csv에 연결했다.

엔진 판정을 변경하지 않았다. 아래의 “지원 문법”은 기능/문법이 문서에 존재한다는 판단이며, 원본 문장 전체의 실행·의미 동등성·의존 객체를 보장하지 않는다. 매뉴얼에서 직접 대응을 확인하지 못한 객체를 미지원 확정으로 취급하지 않았다.

## 우선 교정할 이유

- CREATE SCHEMA 내부 요소: **24개** 경고. 대상은 내부 TABLE/VIEW/INDEX/SEQUENCE/GRANT/COMMENT를 지원한다. 도구의 내부 객체 변환 경로가 부족한 것이며 컨테이너 문법 자체의 미지원이 아니다.
- IDENTITY: **27개** GENERATED 경고는 실제 IDENTITY 절이다. 대상에 지원 문법이 있다. 계산 생성열·INCLUDING GENERATED와 분리하고 타입/NULL/복수 IDENTITY 검사 후 처리해야 한다.
- @ 연산자: **10개 finding, 8개 문장**의 DB 링크 설명이 잘못되었다. 원본은 PostgreSQL 연산자 문맥이며, 연산자 자체의 대상 대응 검토는 남는다.
- INTERVAL: **3개 finding, 1개 VIEW**. 대상 타입은 지원하지만 PostgreSQL 문자열 단위와 ::interval 변환이 필요하다. VIEW 안의 다른 함수·타입까지 호환으로 인정한 것은 아니다.
- 집합 반환/외부 C/DML 트리거: 대상에 각각 RETURN TABLE, 외부 C 루틴, DML 트리거가 있다. PostgreSQL의 선언·본문·ABI·호출 의미 변환이 필요하다는 설명으로 정리해야 한다.

## 검토 유지가 타당한 예

- UNIQUE NULLS [NOT] DISTINCT와 인덱스 열 정렬 NULLS FIRST/LAST는 다른 의미다.
- PostgreSQL random()과 대상 RANDOM(min,max)는 인자 수·범위가 다르다. GREATEST는 NULL 처리도 다르다.
- 대상 USER 인증값, 권한 옵션, TABLESPACE 파일/크기, 다중 IDENTITY/SERIAL은 정책·값·보조 객체 검토가 필요하다.
- ON COMMIT DROP의 최상위 DROP 차단은 오탐이지만, 대상 GTT 문법은 PRESERVE/DELETE ROWS만 확인되어 원문 DROP 동작을 자동 호환으로 바꿀 수 없다.
- DOMAIN/ENUM/FDW/PUBLICATION/MATERIALIZED VIEW 등은 직접 대응의 확인 근거가 부족하다. 매뉴얼에 항목이 없다는 사실만으로 모든 대체 구현이 불가능하다고 단정하지 않는다.

## 규칙별 재검토

| 규칙 | finding 수 | 재검토 | 설명·근거 |
|---|---:|---|---|
| PG_TABLE_FEATURE_REVIEW | 578 | 문법·의미 대응 확인 유지 | IDENTITY와 계산 생성열·PARTITION·INHERITS·COLLATE를 구분해야 한다. 대상 CREATE TABLE에 같은 절이 있는지와 저장·분산·비교 의미 보존을 별도로 검토한다. [매뉴얼 1](https://github.com/sunjesoft/goldilocks-manuals/blob/f5976dfdb7296116f2aa988746c3e375993b4825/docs/goldilocks/26c.1/ko/part-03-sql-manual/19-sql-references-c-g.md#L3410-L4005) |
| PG_OBJECT_FEATURE_REVIEW | 485 | 직접 대응 근거 미확인 | DOMAIN/ENUM/AGGREGATE/RULE/FDW/이벤트 트리거 등 PostgreSQL 객체에 대한 동일 생성 문법의 근거를 이번 매뉴얼 범위에서 확인하지 못했다. PSM RECORD/컬렉션 지원만으로 SQL CREATE TYPE/DOMAIN의 호환성을 결론낼 수 없다. [매뉴얼 1](https://github.com/sunjesoft/goldilocks-manuals/blob/f5976dfdb7296116f2aa988746c3e375993b4825/docs/goldilocks/26c.1/ko/part-03-sql-manual/19-sql-references-c-g.md#L3410-L4005) [매뉴얼 2](https://github.com/sunjesoft/goldilocks-manuals/blob/f5976dfdb7296116f2aa988746c3e375993b4825/docs/goldilocks/26c.1/ko/part-04-sql-psm-manual/22-psm-datatypes.md#L161-L260) [매뉴얼 3](https://github.com/sunjesoft/goldilocks-manuals/blob/f5976dfdb7296116f2aa988746c3e375993b4825/docs/goldilocks/26c.1/ko/part-04-sql-psm-manual/29-trigger.md#L25-L90) |
| PG_TRIGGER_FUNCTION_REVIEW | 233 | 지원 기능 있으나 변환 필요 | 대상 DML 트리거는 지원한다. PostgreSQL EXECUTE FUNCTION 호출을 대상의 트리거 본문·전이변수·반환 동작으로 연결하는 구현이 필요하므로 트리거 미지원으로 표시하면 안 된다. [매뉴얼 1](https://github.com/sunjesoft/goldilocks-manuals/blob/f5976dfdb7296116f2aa988746c3e375993b4825/docs/goldilocks/26c.1/ko/part-04-sql-psm-manual/31-psm-sql-references.md#L1634-L1798) [매뉴얼 2](https://github.com/sunjesoft/goldilocks-manuals/blob/f5976dfdb7296116f2aa988746c3e375993b4825/docs/goldilocks/26c.1/ko/part-04-sql-psm-manual/29-trigger.md#L25-L90) |
| STORAGE_REVIEW | 204 | 원본 옵션별 확인 유지 | 대상 테이블 속성 문법과 원본 USING/WITH/PARTITION/상속/저장 옵션의 의미가 같다는 근거는 별도다. 이 규칙만으로 전체 옵션 미지원을 확정하지 않는다. [매뉴얼 1](https://github.com/sunjesoft/goldilocks-manuals/blob/f5976dfdb7296116f2aa988746c3e375993b4825/docs/goldilocks/26c.1/ko/part-03-sql-manual/19-sql-references-c-g.md#L3410-L4005) |
| PG_ROUTINE_RETURN_REVIEW | 125 | 타입·반환 방식 변환 필요 | 대상은 스칼라 함수와 RETURN TABLE을 지원한다. 원본 SETOF/TABLE/복합·다형·VOID 반환은 선언·본문·호출 방식의 변환이 필요하다. 집합 반환 기능 자체가 없다는 결론은 부정확하다. [매뉴얼 1](https://github.com/sunjesoft/goldilocks-manuals/blob/f5976dfdb7296116f2aa988746c3e375993b4825/docs/goldilocks/26c.1/ko/part-04-sql-psm-manual/31-psm-sql-references.md#L772-L838) [매뉴얼 2](https://github.com/sunjesoft/goldilocks-manuals/blob/f5976dfdb7296116f2aa988746c3e375993b4825/docs/goldilocks/26c.1/ko/part-04-sql-psm-manual/30-psm-language-element-references.md#L4446-L4524) [매뉴얼 3](https://github.com/sunjesoft/goldilocks-manuals/blob/f5976dfdb7296116f2aa988746c3e375993b4825/docs/goldilocks/26c.1/ko/part-04-sql-psm-manual/22-psm-datatypes.md#L161-L260) |
| PG_PUBLICATION_UNSUPPORTED | 125 | 직접 대응 근거 미확인 | 공식 SQL 생성 문법에서 PostgreSQL 논리복제 PUBLICATION의 직접 대응은 확인하지 못했다. 조회한 매뉴얼에 없다는 것만으로 전체 복제 기능의 부재를 증명하지 않는다. 별도 복제 구성과 테이블 발행 의미 검토가 필요하다. [매뉴얼 1](https://github.com/sunjesoft/goldilocks-manuals/blob/f5976dfdb7296116f2aa988746c3e375993b4825/docs/goldilocks/26c.1/ko/part-03-sql-manual/19-sql-references-c-g.md#L3410-L4005) |
| PG_TYPE_REVIEW | 115 | 자료형·연산 의미 확인 유지 | 내장 숫자/문자/시간 타입과 PostgreSQL 배열·사용자 타입·BOX/POINT/TSVECTOR 등은 구분한다. PSM 컬렉션을 SQL 배열 열과 바로 동일시할 수 없다. [매뉴얼 1](https://github.com/sunjesoft/goldilocks-manuals/blob/f5976dfdb7296116f2aa988746c3e375993b4825/docs/goldilocks/26c.1/ko/part-03-sql-manual/16-built-in-data-type-references.md#L11-L117) [매뉴얼 2](https://github.com/sunjesoft/goldilocks-manuals/blob/f5976dfdb7296116f2aa988746c3e375993b4825/docs/goldilocks/26c.1/ko/part-04-sql-psm-manual/22-psm-datatypes.md#L161-L260) |
| PG_ROUTINE_LANGUAGE_REVIEW | 74 | 지원 기능 있으나 변환 필요 | 대상에도 외부 C 루틴과 LIBRARY/call specification이 있다. PostgreSQL LANGUAGE C/internal·라이브러리 심벌과 실행 ABI가 그대로 호환되는 것은 아니므로 별도 변환·배포 검토를 유지한다. [매뉴얼 1](https://github.com/sunjesoft/goldilocks-manuals/blob/f5976dfdb7296116f2aa988746c3e375993b4825/docs/goldilocks/26c.1/ko/part-04-sql-psm-manual/28-external-routine.md#L13-L55) [매뉴얼 2](https://github.com/sunjesoft/goldilocks-manuals/blob/f5976dfdb7296116f2aa988746c3e375993b4825/docs/goldilocks/26c.1/ko/part-04-sql-psm-manual/31-psm-sql-references.md#L772-L838) |
| PG_ROLE_OPTION_REVIEW | 70 | 권한·인증 정책 확인 유지 | 대상 USER/ROLE 생성 및 권한 모델과 SUPERUSER/CREATEDB/CREATEROLE/REPLICATION/BYPASSRLS의 대응은 정책 결정이 필요하다. 역할을 임의로 과권한화하지 않는다. [매뉴얼 1](https://github.com/sunjesoft/goldilocks-manuals/blob/f5976dfdb7296116f2aa988746c3e375993b4825/docs/goldilocks/26c.1/ko/part-03-sql-manual/19-sql-references-c-g.md#L5846-L5882) [매뉴얼 2](https://github.com/sunjesoft/goldilocks-manuals/blob/f5976dfdb7296116f2aa988746c3e375993b4825/docs/goldilocks/26c.1/ko/part-03-sql-manual/19-sql-references-c-g.md#L2623-L2668) |
| PG_INDEX_OPTION_REVIEW | 44 | 옵션 의미 확인 유지 | 대상 키의 NULLS FIRST/LAST는 원본 UNIQUE NULLS [NOT] DISTINCT와 다른 속성이다. CONCURRENTLY/WHERE/INCLUDE도 단순 삭제하면 동시성·포함열·부분 인덱스 의미가 달라진다. [매뉴얼 1](https://github.com/sunjesoft/goldilocks-manuals/blob/f5976dfdb7296116f2aa988746c3e375993b4825/docs/goldilocks/26c.1/ko/part-03-sql-manual/19-sql-references-c-g.md#L1522-L1568) |
| PSM_SELECT_PARSE_REVIEW | 35 | 분석기·원본 문맥 확인 필요 | 파서 오류는 대상 미지원의 증거가 아니다. ONLY/식별자·VALUES·조인 별칭·타입·정규화/콜레이션 등 실제 실패 토큰과 전체 SQL을 개별 확인해야 한다. [매뉴얼 1](https://github.com/sunjesoft/goldilocks-manuals/blob/f5976dfdb7296116f2aa988746c3e375993b4825/docs/goldilocks/26c.1/ko/part-03-sql-manual/20-sql-references-h-z.md#L3630-L3800) [매뉴얼 2](https://github.com/sunjesoft/goldilocks-manuals/blob/f5976dfdb7296116f2aa988746c3e375993b4825/docs/goldilocks/26c.1/ko/part-04-sql-psm-manual/31-psm-sql-references.md#L772-L838) |
| PG_PARAMETER_REVIEW | 32 | 지원 문법으로 변환 필요 | 대상 함수 인자는 이름·모드·타입을 가진다. 원본 이름 없는 인자와 $1 위치 참조를 충돌 없는 이름으로 함께 바꾸는 규칙이 필요하다. 현재 경고를 호환으로 지우는 것으로는 해결되지 않는다. [매뉴얼 1](https://github.com/sunjesoft/goldilocks-manuals/blob/f5976dfdb7296116f2aa988746c3e375993b4825/docs/goldilocks/26c.1/ko/part-04-sql-psm-manual/31-psm-sql-references.md#L772-L838) |
| PG_SERVER_UNSUPPORTED | 27 | 직접 대응 근거 미확인 | PostgreSQL SERVER/FDW와 같은 객체 생성·사용자 매핑의 직접 대응은 이번 SQL 매뉴얼에서 확인하지 못했다. 원격 연결이나 데이터 연계 전체의 불가능으로 확대하지 않는다. [매뉴얼 1](https://github.com/sunjesoft/goldilocks-manuals/blob/f5976dfdb7296116f2aa988746c3e375993b4825/docs/goldilocks/26c.1/ko/part-03-sql-manual/19-sql-references-c-g.md#L3410-L4005) [매뉴얼 2](https://github.com/sunjesoft/goldilocks-manuals/blob/f5976dfdb7296116f2aa988746c3e375993b4825/docs/goldilocks/26c.1/ko/part-03-sql-manual/19-sql-references-c-g.md#L5846-L5882) |
| PG_BUILTIN_FUNCTION_REVIEW | 25 | 함수별 대응 근거 미확인 | PostgreSQL 전용 내부/접근방식 함수와 대상 함수의 이름·인자·반환·NULL 의미를 개별 대조해야 한다. 사용자 함수와 내장 함수를 구분하고 이름이 없다는 이유만으로 전체 SQL을 실행 불가로 단정하지 않는다. [매뉴얼 1](https://github.com/sunjesoft/goldilocks-manuals/blob/f5976dfdb7296116f2aa988746c3e375993b4825/docs/goldilocks/26c.1/ko/part-04-sql-psm-manual/31-psm-sql-references.md#L772-L838) [매뉴얼 2](https://github.com/sunjesoft/goldilocks-manuals/blob/f5976dfdb7296116f2aa988746c3e375993b4825/docs/goldilocks/26c.1/ko/part-03-sql-manual/16-built-in-data-type-references.md#L11-L117) |
| COMMON_DDL_SYNTAX_REVIEW | 24 | 지원 문법·분석기 보강 후보 | 대상 CREATE SCHEMA는 내부 TABLE/VIEW/INDEX/SEQUENCE/GRANT/COMMENT 요소를 명시적으로 지원한다. 해당 요소 내부 변환과 실행 순서·권한 검증이 남아 있어 문장 전체 자동 호환을 보장하지 않는다. [매뉴얼 1](https://github.com/sunjesoft/goldilocks-manuals/blob/f5976dfdb7296116f2aa988746c3e375993b4825/docs/goldilocks/26c.1/ko/part-03-sql-manual/19-sql-references-c-g.md#L2833-L2890) |
| PG_INDEX_METHOD_REVIEW | 21 | 접근방식 대응 확인 유지 | 대상 CREATE INDEX의 열 목록·속성 문법과 PostgreSQL GiST/SP-GiST/GIN/BRIN/사용자 접근방식은 별개다. BTREE로 일괄 치환해 같은 연산자·접근 성능을 보장할 수 없다. [매뉴얼 1](https://github.com/sunjesoft/goldilocks-manuals/blob/f5976dfdb7296116f2aa988746c3e375993b4825/docs/goldilocks/26c.1/ko/part-03-sql-manual/19-sql-references-c-g.md#L1522-L1568) |
| PG_CAST_REVIEW | 13 | 타입·리터럴 변환 필요 | 대상 CAST/자료형을 확인하되 SQL 배열·복합·UNKNOWN/XML 등의 의미와 원본 리터럴 표현을 함께 봐야 한다. INTERVAL 자체는 대상 지원 타입이며 원본의 단위 문자열은 별도 정규화가 필요하다. [매뉴얼 1](https://github.com/sunjesoft/goldilocks-manuals/blob/f5976dfdb7296116f2aa988746c3e375993b4825/docs/goldilocks/26c.1/ko/part-03-sql-manual/16-built-in-data-type-references.md#L11-L117) [매뉴얼 2](https://github.com/sunjesoft/goldilocks-manuals/blob/f5976dfdb7296116f2aa988746c3e375993b4825/docs/goldilocks/26c.1/ko/part-03-sql-manual/16-built-in-data-type-references.md#L400-L469) |
| PG_PASSWORD_REQUIRED | 11 | 대상 인증값 필요 | 대상 CREATE USER의 IDENTIFIED BY 비밀번호는 문법에 명시되어 있다. 원본에 없는 비밀번호를 생성하거나 기존 인증 정보를 추정할 수 없어 정책·입력을 요구하는 판단을 유지한다. [매뉴얼 1](https://github.com/sunjesoft/goldilocks-manuals/blob/f5976dfdb7296116f2aa988746c3e375993b4825/docs/goldilocks/26c.1/ko/part-03-sql-manual/19-sql-references-c-g.md#L5846-L5882) |
| DBLINK_REVIEW | 10 | 판정 사유 오탐 | 이 자료의 @ 토큰은 PostgreSQL @>/<@ 등의 연산자 문맥이다. 이를 DB 링크라고 설명하는 것은 오탐이다. 원본 연산자의 대상 구현 대응은 별도 검토해야 하므로 전체 문장을 자동 호환으로 바꾸지는 않는다. [매뉴얼 1](https://github.com/sunjesoft/goldilocks-manuals/blob/f5976dfdb7296116f2aa988746c3e375993b4825/docs/goldilocks/26c.1/ko/part-03-sql-manual/19-sql-references-c-g.md#L1522-L1568) [매뉴얼 2](https://github.com/sunjesoft/goldilocks-manuals/blob/f5976dfdb7296116f2aa988746c3e375993b4825/docs/goldilocks/26c.1/ko/part-03-sql-manual/16-built-in-data-type-references.md#L11-L117) |
| PG_CONSTRAINT_TRIGGER_REVIEW | 10 | 지원 기능 있으나 의미 확인 필요 | 대상 DML 트리거가 있어도 PostgreSQL CONSTRAINT TRIGGER의 지연 시점·제약 보장과 함수 호출 의미가 같다고 확인한 것은 아니다. 단순 일반 트리거로 바꾸지 않는다. [매뉴얼 1](https://github.com/sunjesoft/goldilocks-manuals/blob/f5976dfdb7296116f2aa988746c3e375993b4825/docs/goldilocks/26c.1/ko/part-04-sql-psm-manual/31-psm-sql-references.md#L1634-L1798) [매뉴얼 2](https://github.com/sunjesoft/goldilocks-manuals/blob/f5976dfdb7296116f2aa988746c3e375993b4825/docs/goldilocks/26c.1/ko/part-04-sql-psm-manual/29-trigger.md#L25-L90) |
| PG_PARAMETER_TYPE_REVIEW | 8 | 인자 타입·가변 인자 변환 필요 | 대상 인자 모드와 타입은 문서화되어 있다. PostgreSQL VARIADIC/다형·배열/사용자 타입의 인자 규칙은 별도 변환과 호출부 검증이 필요하다. [매뉴얼 1](https://github.com/sunjesoft/goldilocks-manuals/blob/f5976dfdb7296116f2aa988746c3e375993b4825/docs/goldilocks/26c.1/ko/part-04-sql-psm-manual/31-psm-sql-references.md#L772-L838) [매뉴얼 2](https://github.com/sunjesoft/goldilocks-manuals/blob/f5976dfdb7296116f2aa988746c3e375993b4825/docs/goldilocks/26c.1/ko/part-04-sql-psm-manual/22-psm-datatypes.md#L161-L260) |
| PG_SQL_BODY_REVIEW | 7 | 지원 기능·변환 범위 구분 | 대상 PSM 본문은 여러 SQL 문장을 가질 수 있다. 현재 도구의 LANGUAGE SQL 단일 스칼라 SELECT 제한은 도구 범위이며 대상의 다중 문장 미지원이 아니다. 결과 반환·트랜잭션 의미를 보존하는 변환이 필요하다. [매뉴얼 1](https://github.com/sunjesoft/goldilocks-manuals/blob/f5976dfdb7296116f2aa988746c3e375993b4825/docs/goldilocks/26c.1/ko/part-04-sql-psm-manual/31-psm-sql-references.md#L772-L838) [매뉴얼 2](https://github.com/sunjesoft/goldilocks-manuals/blob/f5976dfdb7296116f2aa988746c3e375993b4825/docs/goldilocks/26c.1/ko/part-04-sql-psm-manual/31-psm-sql-references.md#L1402-L1465) [매뉴얼 3](https://github.com/sunjesoft/goldilocks-manuals/blob/f5976dfdb7296116f2aa988746c3e375993b4825/docs/goldilocks/26c.1/ko/part-04-sql-psm-manual/30-psm-language-element-references.md#L4446-L4524) |
| PSM_NAME_REVIEW | 6 | 원본 위치 인자 변환 필요 | $1/$2 등 위치 인자는 대상의 이름 있는 인자와 함께 치환해야 한다. 원문에 선언이 없다는 설명은 현재 변환 결과의 한계이며 단순 사용자 오기라고 볼 수 없다. [매뉴얼 1](https://github.com/sunjesoft/goldilocks-manuals/blob/f5976dfdb7296116f2aa988746c3e375993b4825/docs/goldilocks/26c.1/ko/part-04-sql-psm-manual/31-psm-sql-references.md#L772-L838) |
| PG_ESCAPE_LITERAL_REVIEW | 6 | 문자열 의미 확인 유지 | E 문자열 이스케이프는 실제 바이트·인코딩·역슬래시 의미까지 보존해야 한다. 문자열 형식을 바꾸기 전에 모든 escape를 검증해야 한다. [매뉴얼 1](https://github.com/sunjesoft/goldilocks-manuals/blob/f5976dfdb7296116f2aa988746c3e375993b4825/docs/goldilocks/26c.1/ko/part-03-sql-manual/16-built-in-data-type-references.md#L11-L117) |
| PSM_RETURN_TYPE_REVIEW | 5 | 반환 문맥 확인 유지 | 대상 함수의 값 반환과 프로시저 RETURN은 서로 다르다. 원본 RETURNS VOID 또는 프로시저 본문을 자동 치환한 결과에서 값 반환이 남는지 확인하고 호출 의미를 보존해야 한다. [매뉴얼 1](https://github.com/sunjesoft/goldilocks-manuals/blob/f5976dfdb7296116f2aa988746c3e375993b4825/docs/goldilocks/26c.1/ko/part-04-sql-psm-manual/30-psm-language-element-references.md#L4381-L4445) [매뉴얼 2](https://github.com/sunjesoft/goldilocks-manuals/blob/f5976dfdb7296116f2aa988746c3e375993b4825/docs/goldilocks/26c.1/ko/part-04-sql-psm-manual/31-psm-sql-references.md#L772-L838) [매뉴얼 3](https://github.com/sunjesoft/goldilocks-manuals/blob/f5976dfdb7296116f2aa988746c3e375993b4825/docs/goldilocks/26c.1/ko/part-04-sql-psm-manual/31-psm-sql-references.md#L1402-L1465) |
| CREATE_TABLESPACE_REVIEW | 5 | 저장 환경 설계 필요 | 대상 TABLESPACE는 메모리/디스크와 데이터파일 구성을 사용한다. PostgreSQL LOCATION 디렉터리 경로를 임의 파일·크기로 바꿀 수 없으므로 환경 입력을 요구하는 검토를 유지한다. [매뉴얼 1](https://github.com/sunjesoft/goldilocks-manuals/blob/f5976dfdb7296116f2aa988746c3e375993b4825/docs/goldilocks/26c.1/ko/part-03-sql-manual/19-sql-references-c-g.md#L5770-L5820) |
| PSM_BUILTIN_ARGUMENT_REVIEW | 2 | 인자 차이 검토 타당 | 이번 두 사례는 PostgreSQL random()과 대상 RANDOM(min,max)의 인자 수 차이다. 함수가 없다는 문제가 아니며 경계·난수 범위 의미를 정한 변환이 필요하다. [매뉴얼 1](https://github.com/sunjesoft/goldilocks-manuals/blob/f5976dfdb7296116f2aa988746c3e375993b4825/docs/goldilocks/26c.1/ko/part-03-sql-manual/17-built-in-function-references.md#L6140-L6167) |
| PSM_EXECUTE IMMEDIATE_PARSE_REVIEW | 2 | 지원 문법으로 변환 필요 | 대상은 EXECUTE IMMEDIATE와 바인딩을 지원한다. 원본 PL/pgSQL EXECUTE 문자열을 IMMEDIATE 포함 문법으로 바꾸고 INTO/USING 의미를 검증해야 한다. [매뉴얼 1](https://github.com/sunjesoft/goldilocks-manuals/blob/f5976dfdb7296116f2aa988746c3e375993b4825/docs/goldilocks/26c.1/ko/part-04-sql-psm-manual/30-psm-language-element-references.md#L1786-L1855) |
| PSM_WITH_PARSE_REVIEW | 2 | 옵티마이저 지시 의미 확인 | 원본 WITH의 MATERIALIZED/NOT MATERIALIZED는 저장 객체 CREATE MATERIALIZED VIEW와 다르다. 대상 CTE 문법에 맞추더라도 평가 횟수·부작용·최적화 의미는 별도 검토해야 한다. [매뉴얼 1](https://github.com/sunjesoft/goldilocks-manuals/blob/f5976dfdb7296116f2aa988746c3e375993b4825/docs/goldilocks/26c.1/ko/part-03-sql-manual/20-sql-references-h-z.md#L3630-L3800) |
| IDENTITY_COLUMN_COUNT_REVIEW | 2 | 매뉴얼 제약과 일치 | 대상 테이블은 IDENTITY 열을 하나만 가질 수 있다. 원본의 다중 IDENTITY를 일괄 호환 처리하면 안 되며 시퀀스·기본값 대안이 필요하다. [매뉴얼 1](https://github.com/sunjesoft/goldilocks-manuals/blob/f5976dfdb7296116f2aa988746c3e375993b4825/docs/goldilocks/26c.1/ko/part-03-sql-manual/19-sql-references-c-g.md#L3410-L4005) |
| PSM_VALUES_PARSE_REVIEW | 2 | 분석기·원본 문맥 확인 필요 | VALUES를 일반 DML 문장 시작으로 처리하는 현재 파서 경로의 실패다. 대상 조회식과 원본 RULE 본문 의미를 분리해서 확인해야 한다. [매뉴얼 1](https://github.com/sunjesoft/goldilocks-manuals/blob/f5976dfdb7296116f2aa988746c3e375993b4825/docs/goldilocks/26c.1/ko/part-03-sql-manual/20-sql-references-h-z.md#L3630-L3800) |
| DESTRUCTIVE_SQL_BLOCKED | 1 | 차단 사유 오탐·변환 검토 유지 | CREATE TEMP TABLE ... ON COMMIT DROP의 DROP를 최상위 DROP 명령으로 차단한 것은 오탐이다. 다만 대상 GTT 매뉴얼은 ON COMMIT PRESERVE/DELETE ROWS만 명시하므로 DROP 동작 자체의 원문 호환으로 재분류할 수 없다. [매뉴얼 1](https://github.com/sunjesoft/goldilocks-manuals/blob/f5976dfdb7296116f2aa988746c3e375993b4825/docs/goldilocks/26c.1/ko/part-03-sql-manual/19-sql-references-c-g.md#L1214-L1298) |
| PSM_PARSE_ERROR | 1 | 변환 결과 문법 확인 필요 | 이번 사례는 프로시저 선언/본문 변환에서 쉼표 위치의 파서 실패다. 대상 프로시저 문법과 원본 SQL 본문 형식을 대조하여 수정해야 하며 파서 실패만으로 대상 미지원을 결론내리지 않는다. [매뉴얼 1](https://github.com/sunjesoft/goldilocks-manuals/blob/f5976dfdb7296116f2aa988746c3e375993b4825/docs/goldilocks/26c.1/ko/part-04-sql-psm-manual/31-psm-sql-references.md#L1402-L1465) |
| PG_ROLE_PASSWORD_REVIEW | 1 | 대상 인증모델 확인 유지 | 대상 ROLE과 로그인 USER를 구분해야 한다. 원본 비로그인 ROLE의 PASSWORD를 임의 제거하거나 USER로 변경하면 인증 모델이 바뀐다. [매뉴얼 1](https://github.com/sunjesoft/goldilocks-manuals/blob/f5976dfdb7296116f2aa988746c3e375993b4825/docs/goldilocks/26c.1/ko/part-03-sql-manual/19-sql-references-c-g.md#L2623-L2668) [매뉴얼 2](https://github.com/sunjesoft/goldilocks-manuals/blob/f5976dfdb7296116f2aa988746c3e375993b4825/docs/goldilocks/26c.1/ko/part-03-sql-manual/19-sql-references-c-g.md#L5846-L5882) |
| PG_PASSWORD_REVIEW | 1 | 인증값 의미 확인 유지 | 원본 NULL/escape/해시 비밀번호를 대상 평문 IDENTIFIED BY와 동일시할 근거가 없다. 비밀값을 추정하거나 새 값을 만들지 않는다. [매뉴얼 1](https://github.com/sunjesoft/goldilocks-manuals/blob/f5976dfdb7296116f2aa988746c3e375993b4825/docs/goldilocks/26c.1/ko/part-03-sql-manual/19-sql-references-c-g.md#L5846-L5882) |
| PG_BUILTIN_SEMANTICS_REVIEW | 1 | NULL 의미 차이 검토 타당 | GREATEST의 대상 문서는 인자 하나라도 NULL이면 NULL이라고 명시한다. PostgreSQL은 NULL 인자를 무시하므로 단순 이름 유지로 동등성을 보장할 수 없다. [매뉴얼 1](https://github.com/sunjesoft/goldilocks-manuals/blob/f5976dfdb7296116f2aa988746c3e375993b4825/docs/goldilocks/26c.1/ko/part-03-sql-manual/17-built-in-function-references.md#L2859-L2882) |
| PG_SERIAL_IDENTITY_REVIEW | 1 | 보조 객체·개수 제약 확인 | 복수 SERIAL 열은 각각의 보조 시퀀스를 가질 수 있지만 대상 IDENTITY는 테이블당 하나다. 보조 시퀀스 이름·소유관계·DEFAULT·참조를 보존하는 설계가 필요하다. [매뉴얼 1](https://github.com/sunjesoft/goldilocks-manuals/blob/f5976dfdb7296116f2aa988746c3e375993b4825/docs/goldilocks/26c.1/ko/part-03-sql-manual/19-sql-references-c-g.md#L3410-L4005) |

문장별 연결: `manual-recheck.csv`. 근거 파일 SHA256 및 전체 집계: `manual-recheck.json`. 원래 엔진 분류는 `analysis/changes.json`에 보존된다.
