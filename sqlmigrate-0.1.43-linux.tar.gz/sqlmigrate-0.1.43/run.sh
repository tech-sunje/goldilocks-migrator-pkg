#!/bin/sh
set -eu
BASE=$(CDPATH= cd -- "$(dirname -- "$0")" && pwd)
if [ -n "${JAVA_HOME:-}" ]; then
  exec "$JAVA_HOME/bin/java" -jar "$BASE/sqlmigrate.jar" "$@"
fi
exec java -jar "$BASE/sqlmigrate.jar" "$@"
