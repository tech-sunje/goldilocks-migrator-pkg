# GOLDILOCKS function grammar audit

The 26c.1 SQL reference function chapter contains 250 headings, including
operators, overload headings, aggregate and window variants. A function name
catalog is not a syntax grammar, and grammar acceptance does not establish
source-vendor availability, target availability, argument count or type validity.

`GoldilocksFunctionGrammarTest` tests all 174 headings whose first syntax block
has an ordinary named `function(...)` form. It uses a single argument as a
**grammar name probe**, not as an assertion of valid function signatures. It
also probes the 44 ordinary window-function headings with an `OVER ()` suffix;
FIRST/LAST are separate KEEP forms, not standalone function names. Existing
747-routine ANTLR fixture comparisons remain covered by `AntlrPsmTest`.

LEAST and GREATEST already parsed through qualified names and generic call
postfixes. Their missing automatic classification was a semantic catalog issue.
The grammar also accepts nested schema-qualified calls and unknown source
function names, so syntax acceptance cannot replace function support checks.
REPLACE, REVERSE, and package ENABLE/DISABLE members did have grammar gaps because their existing keyword tokens
were excluded from ordinary identifier positions. Finite bundled source/target
function membership now permits contextual call names; package ENABLE/DISABLE
are accepted only as members and CURRENT_USER as a builtin value. Declaration
and statement identifiers retain their original keyword restrictions.

Implemented separator syntax, with positive and malformed negative cases:

- EXTRACT(field FROM expression), including timezone fields.
- TRIM(direction/character FROM source), as well as ordinary TRIM(source).
- SUBSTRING and SUBSTR with FROM and optional FOR; comma calls remain accepted.
- POSITION(needle IN haystack).
- OVERLAY(source PLACING replacement FROM start [FOR length]).
- DATEADD/DATEDIFF datepart metadata, and ADDDATE/DATE_ADD dynamic INTERVAL
  amount/unit arguments (alongside existing standard typed interval literals).
- Aggregate ALL/DISTINCT arguments, FILTER with optional WHERE, and OVER with a
  window name or partition/order specification and ROWS/RANGE frame boundaries.

Additional structured coverage includes JSON_OBJECT and JSON_OBJECTAGG
KEY/VALUE or colon pairs, NULL/ABSENT ON NULL, WITH/WITHOUT UNIQUE KEYS,
RETURNING types with optional PRETTY, JSON_ARRAY/JSON_ARRAYAGG values and internal aggregate ORDER BY.
WITHIN GROUP and KEEP DENSE_RANK FIRST/LAST have explicit ordered grammar;
RESPECT/IGNORE NULLS is accepted inside or outside call arguments, and NTH_VALUE
supports FROM FIRST/LAST. Malformed clauses have negative tests. Qualified
DBMS_OUTPUT ENABLE, DISABLE and NEW_LINE are tested with and without parentheses.

Special scalar and JSON forms produce ordinary CALL AST nodes. Field/direction metadata
is a SQL_META child, and real arguments remain expression children. FILTER and
WINDOW produce wrappers containing the call and real predicate, partition,
ordering and frame-offset expressions. WITHIN GROUP and KEEP also use WINDOW
wrappers; null-treatment and JSON options are syntax metadata retained by source
spans and never synthesized into variable references. Source spans preserve the original SQL;
these nodes are not a SQL serializer or a target execution guarantee.

Remaining grammar limitations are real parser coverage gaps, not evidence that
GOLDILOCKS rejects the syntax:

- The reusable SELECT grammar remains a subset: hierarchical/model/pivot
  clauses and other full-query forms require separate structured grammar work.
  Recursive CTE SEARCH/CYCLE syntax and vendor-specific recursive-reference
  restrictions are not covered by the common CTE implementation. Raw SQL statement capture
  inside PSM is not proof that those statements passed SELECT validation.

NEXT VALUE FOR a sequence is represented as NEXTVAL CALL with SQL_SEQUENCE
syntax and SQL_META sequence identity. Named WINDOW definitions and inherited
specifications retain real partition/order/frame expressions; Query.windowNames
and windowParents retain definition metadata, while WINDOW expression syntax
retains a referenced window name. GROUPS and all four documented EXCLUDE forms
are explicitly parsed. Duplicate window names and unknown preceding definition
parents are rejected. This AST does not itself prove all semantic restrictions
on window inheritance, frame bound ordering or sequence existence.

Common query coverage now includes WITH CTE lists (optional explicit column
lists), scalar and correlated subqueries, EXISTS/NOT EXISTS, and IN/NOT IN with
a subquery. Expr.query retains the complete nested Query AST; CTE records retain
their names, column aliases and child queries. CTE child queries also appear in
Query.nested for existing semantic traversal. Duplicate CTE names/column names
and explicit CTE result-width mismatches are rejected. Malformed parentheses,
SELECT lists, empty EXISTS and incomplete WITH definitions have negative tests.
EXISTS is a real predicate token; collection member `.EXISTS(...)` remains valid.
These features do not validate remote table/column existence or runtime scalar
subquery cardinality.

All bundled Oracle SQL, PostgreSQL 18 and 210 explicitly headed Altibase 7.3
builtin names/aliases are additionally probed
in ordinary unqualified and SYS-qualified call positions, excluding CAST/EXTRACT
which require separator syntax. ParserBuiltinNames consults the finite bundled
Oracle, PostgreSQL and GOLDILOCKS catalogs; its membership is syntax context only,
not semantic source/target support. The Altibase resource comes from explicit function headings and aliases in the
checked-in SQL Reference; CASE WHEN and prose headings are excluded.
Reserved keyword names absent from those catalogs (FROM and SELECT) remain
invalid calls. Special CAST and SQL separator forms are not admitted through the
new contextual keyword-name fallback.

No catch-all raw expression acceptance was introduced. A complete target grammar
claim requires a vendor-versioned syntax inventory, representative signatures
and negative cases for each family, source-vendor checks, and target execution
validation where available.

## Reviewed regression changes (0.1.30)

Offline source snapshots, object identities/counts and every converted SQL payload
SHA remain unchanged. Updated fingerprints cover six expanded Oracle files,
18 expanded PostgreSQL files, one official Oracle sample, one HR file, two CO
files (diagnostic positions), and the Pagila schema. Changes remove prior parser
coverage reviews for supported structured query forms, recognize target native
functions, and add package signature evidence. A cursor FOR construct remains
under its specific existing review instead of an earlier generic parser error.
These diagnostic changes do not assert successful database execution.

The manual review detail now has explicit return-to-list buttons. Return renders
current classifications and counts without a document reload, preserving saved
in-memory SQL edits, filters and pagination; browser hash navigation back to the
list also refreshes it. Unsaved edits are not silently saved by navigation.
