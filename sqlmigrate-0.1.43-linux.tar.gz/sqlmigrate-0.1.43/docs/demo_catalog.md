# 분리된 오프라인 변환 데모

배포본의 기본 `migrate.ini`는 **source/alti만** 읽습니다. 다른 DBMS의 SQL을 같은 입력 폴더에 섞지 마십시오.

| INI | 소스 버전 | 입력 | 출력 |
| --- | --- | --- | --- |
| migrate.ini / alti-demo.ini | Altibase 7.3 | source/alti | target/alti |
| ora-demo.ini | Oracle 19c | source/ora | target/ora |
| pg-demo.ini / postgresql-demo.ini | PostgreSQL 18 | source/pg | target/pg |

`java -jar sqlmigrate.jar --config ora-demo.ini`처럼 실행하거나 브라우저에서 INI를 선택하십시오. 경로는 INI 위치 기준입니다. 각 INI는 전체 규칙 목록과 독립된 검토 규칙 sidecar 경로를 포함합니다. DB 접속 없이 변환, SQL 검토, HTML/XLSX 보고서 생성만 합니다. 원본 예제의 보존용 `source/example.sql`은 기본 입력 대상이 아닙니다.

## 파일과 객체

각 DBMS 폴더의 `10_datatypes.sql`은 타입 목록, `20_business_tables.sql`은 송장/청구/감사 테이블·뷰·시퀀스·인덱스·데이터, `30_procedure_300.sql`은 정산 프로시저, `31_function_300.sql`은 견적 함수, `40_trigger.sql`은 금액 검증 트리거입니다. `90_manual_review.sql`의 권한·사용자·동의어·벤더 전용 객체는 자동 이식 성공을 주장하지 않고 원문과 검토 항목을 확인하는 예제입니다.

Oracle/Altibase `32_package_300.sql`은 패키지 명세와 300행 이상의 본문입니다. **PostgreSQL에는 네이티브 PACKAGE가 없습니다.** `32_schema_library_300.sql`은 `demo_settlement_library` 스키마와 300행 이상의 함수로 구성한 라이브러리이며 패키지 변환을 대체했다고 주장하지 않습니다.

긴 프로시저/함수/패키지는 각각 350행 이상 실제 코드입니다. 36개의 서로 다른 업무 항목(운임·보험·보관·통관·반품·보증·탄소비용 등)에 각기 다른 상한과 요율을 적용합니다. 변수, 커서 OPEN/FETCH/CLOSE, 반복, 조건, INSERT/UPDATE, 예외 처리와 감사 기록을 포함합니다. 주석/공백으로 분량을 늘리지 않았습니다. 개발 소스의 `demos/tools/generate.py`가 모든 원본 SQL을 재생성합니다. 모든 예제 코드는 이 프로젝트를 위해 새로 작성했습니다.

## 타입 범위와 검토 경계

정확한 모든 선언/별칭 목록과 개수는 배포본 `docs/demo_inventory.json`에 수록했습니다.

- Altibase: 정수/부동소수/정밀수 및 별칭, 문자/국가문자, DATE, BYTE/VARBYTE/NIBBLE/BIT/VARBIT, BLOB/CLOB/GEOMETRY와 메모리/디스크 바이너리 차이. 공간 타입·LOB·컬렉션·DB link·tablespace 등은 대상 의미와 지원 범위를 검토해야 합니다.
- Oracle 19c: 문자 길이 BYTE/CHAR, 국가문자, NUMBER(*,s), ANSI 숫자 별칭, BINARY_FLOAT/DOUBLE, DATE와 TIMESTAMP/TZ/LOCAL TZ, 두 INTERVAL, RAW/ROWID/UROWID, BLOB/CLOB/NCLOB/BFILE, XMLTYPE와 Oracle 제공 객체 타입. LONG과 LONG RAW는 각각 별도 테이블입니다. SQL BOOLEAN은 Oracle 19c 테이블 타입이 아니므로 넣지 않았습니다. ANYTYPE/ANYDATASET 같은 비영속 타입은 아래 설명대로 검토 선언으로 분리했습니다.
- PostgreSQL 18: 정수/serial 별칭, numeric/float/money, bool, 문자/bytea, 날짜/시간/TZ, interval, bit/varbit, UUID/XML/JSON/JSONB/JSONPATH, 모든 기본 기하·네트워크 타입, 전문검색, 배열/enum/composite/domain, 기본 range/multirange, OID/reg*와 시스템 식별자. pseudo-type은 테이블 컬럼에 넣지 않았습니다.

Oracle의 객체 타입/TYPE BODY/컬렉션, materialized view, directory, database link, bitmap index와 cluster를 포함합니다. PostgreSQL은 materialized view, role/user/schema/privilege, FDW/server/foreign table, publication, RLS policy를 포함합니다. Altibase는 사용자 소유 스키마·동의어·권한·패키지·TYPESET과 PSM 타입·DB link·directory·materialized view·tablespace를 포함합니다. DBMS에 없는 객체 종류를 해당 DBMS의 네이티브 구문인 것처럼 만들지 않습니다.

이것은 **정적 변환 검토 카탈로그**입니다. 파일 번호는 읽기 편의를 위한 분류이며 데이터베이스 실행 순서나 설치 스크립트가 아닙니다. 선택 기능은 별도 설치/권한이 필요하고, 변환기가 보존한 원문은 대상 DB에서 실행되기 전에 수작업 설계가 필요합니다. 금액 함수는 감사 INSERT를 포함하므로 Oracle SQL SELECT 내부 호출 시 부작용 제한을 별도로 고려해야 합니다. 예제 계정/암호/원격 주소는 기능 설명용 합성 값이며 실제 접속 정보나 user mapping은 포함하지 않습니다. 이 데모 검증은 실제 DB에 SQL을 실행하지 않습니다.

타입 목록 근거: [Oracle 19c Data Types](https://docs.oracle.com/en/database/oracle/oracle-database/19/sqlrf/Data-Types.html), [PostgreSQL 18 Data Types](https://www.postgresql.org/docs/18/datatype.html), [Altibase 7.3 SQL Reference](https://manual.altibase.com/7.3/en/ref/sql/)와 프로젝트의 타입 호환성 픽스처(`test/source/compatibility/altibase`). 내장/확장 타입의 모든 가능한 매개변수 조합이나 사용자 정의 타입을 완전 열거하는 것은 아닙니다.

PostgreSQL 네이티브 `name CURSOR FOR SELECT` 선언은 현 정적 PSM 파서에서 `PSM_PARSE_ERROR`로 표시될 수 있습니다. 원본 전체가 보존되고 해당 루틴은 수작업 검토로 표시됩니다. 이것은 원본 SQL의 구문 오류가 아니라 현재 변환 범위의 제한입니다. DB link/tablespace/schema 내부 DDL 등도 검토로 남을 수 있습니다.

0.1.29부터 TYPESET 및 CREATE DIRECTORY는 미지원 객체로 수동 검토로 분류합니다. 기본 DATAFILE 디스크 테이블스페이스 예제는 DISK DATA를 명시하는 자동 변환 대상입니다. 이진 타입의 확정 매핑과 정상 범위는 자동 처리합니다.

PostgreSQL SERIAL 계열의 여섯 이름은 각각 독립된 `demo_smallserial`, `demo_serial2`, `demo_serial`, `demo_serial4`, `demo_bigserial`, `demo_serial8` 테이블에 선언합니다. GOLDILOCKS의 테이블당 IDENTITY 1개 제한에 맞춰 각 정수 범위와 자동 증가 변환을 개별 확인할 수 있습니다.
