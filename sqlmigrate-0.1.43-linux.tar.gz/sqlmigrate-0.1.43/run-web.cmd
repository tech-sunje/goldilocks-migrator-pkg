@echo off
setlocal
if defined JAVA_HOME (
  set "MIGRATOR_JAVA=%JAVA_HOME%\bin\java.exe"
) else (
  set "MIGRATOR_JAVA=java.exe"
)
"%MIGRATOR_JAVA%" -jar "%~dp0sqlmigrate.jar" web %*
if errorlevel 1 (
  echo.
  echo GOLDILOCKS Migrator could not start. Java 8 or later is required.
  echo Check JAVA_HOME or run java -version from Command Prompt.
  pause
)
endlocal
