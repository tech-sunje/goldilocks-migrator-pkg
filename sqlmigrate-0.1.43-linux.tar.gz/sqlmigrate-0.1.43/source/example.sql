-- Sample Altibase DDL for the bundled migrate.ini.
CREATE TABLE MIGRATOR_SAMPLE (ID INTEGER, NAME VARCHAR(100));
