-- Original offline migration specimen. Review before any database execution.
CREATE ROLE demo_reader;
CREATE USER demo_operator IDENTIFIED BY "DEMO_ONLY_REPLACE_BEFORE_EXECUTION";
GRANT SELECT ON demo_invoice TO demo_reader;
REVOKE UPDATE ON demo_invoice FROM demo_reader;
CREATE SYNONYM demo_invoice_alias FOR demo_invoice;
CREATE PUBLIC SYNONYM demo_public_invoice FOR demo_invoice;
COMMENT ON TABLE demo_invoice IS 'Original static conversion example';
CREATE TYPESET demo_settlement_types AS
    TYPE charge_record IS RECORD(invoice_id INTEGER, charge_code VARCHAR(120), amount NUMERIC(18,2));
    TYPE amount_list IS TABLE OF NUMERIC(18,2) INDEX BY INTEGER;
    TYPE invoice_cursor IS REF CURSOR;
END;
/
-- Altibase users own their schemas; there is no separate CREATE SCHEMA object here.
CREATE DATABASE LINK demo_archive CONNECT TO "DEMO_USER" IDENTIFIED BY "DEMO_ONLY_REPLACE_BEFORE_EXECUTION" USING DEMO_ARCHIVE;
CREATE DIRECTORY demo_import_dir AS '/review/demo/import';
CREATE MATERIALIZED VIEW demo_customer_totals AS SELECT customer_id, SUM(invoice_total) AS total FROM demo_invoice GROUP BY customer_id;
CREATE TABLESPACE demo_disk DATAFILE 'demo_disk.dbf' SIZE 10M;
-- Oracle-style standalone TYPE/TYPE BODY are not claimed as Altibase native objects.
-- PSM named types / associative collections are deliberately retained for manual review.
CREATE OR REPLACE PROCEDURE demo_collection_review AS
    TYPE amount_array IS TABLE OF NUMERIC(18,2) INDEX BY INTEGER;
    v_amounts amount_array;
BEGIN
    v_amounts[1] := 125.50;
END;
/
