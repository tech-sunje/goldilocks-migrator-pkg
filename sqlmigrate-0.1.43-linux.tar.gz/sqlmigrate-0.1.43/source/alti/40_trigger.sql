-- Original offline migration specimen. Review before any database execution.
CREATE OR REPLACE TRIGGER demo_invoice_guard
BEFORE INSERT OR UPDATE ON demo_invoice
REFERENCING NEW ROW AS N
FOR EACH ROW
AS
BEGIN
    IF N.invoice_total < 0 THEN
        N.invoice_total := 0;
    END IF;
END;
/
