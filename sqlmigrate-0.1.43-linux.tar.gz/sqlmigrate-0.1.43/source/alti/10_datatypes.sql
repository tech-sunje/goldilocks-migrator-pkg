-- Original offline migration specimen. Review before any database execution.
CREATE TABLE demo_datatype_inventory (
    inventory_id INTEGER PRIMARY KEY,
    sample_01 SMALLINT,
    sample_02 INTEGER,
    sample_03 INT,
    sample_04 BIGINT,
    sample_05 REAL,
    sample_06 DOUBLE,
    sample_07 FLOAT,
    sample_08 FLOAT(126),
    sample_09 NUMBER,
    sample_10 NUMBER(18,4),
    sample_11 NUMERIC(38,8),
    sample_12 DECIMAL(18,2),
    sample_13 DEC(10,2),
    sample_14 CHAR(20),
    sample_15 VARCHAR(120),
    sample_16 VARCHAR2(120),
    sample_17 NCHAR(20),
    sample_18 NVARCHAR(120),
    sample_19 DATE,
    sample_20 BYTE(32),
    sample_21 VARBYTE(512),
    sample_22 NIBBLE(16),
    sample_23 BIT(32),
    sample_24 VARBIT(64),
    sample_25 BLOB,
    sample_26 CLOB,
    sample_27 GEOMETRY
);

CREATE TABLE demo_disk_binary (id INTEGER, b BYTE(32000), v VARBYTE(32000), n NIBBLE(16)) TABLESPACE SYS_TBS_DISK_DATA;
