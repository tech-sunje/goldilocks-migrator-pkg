-- Original offline migration specimen. Review before any database execution.
CREATE OR REPLACE TRIGGER demo_invoice_guard
BEFORE INSERT OR UPDATE ON demo_invoice
FOR EACH ROW
BEGIN
    IF :NEW.invoice_total < 0 THEN
        :NEW.invoice_total := 0;
    END IF;
END;
/
