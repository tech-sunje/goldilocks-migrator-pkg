-- Original offline migration specimen. Review before any database execution.
CREATE ROLE demo_reader;
CREATE USER demo_operator IDENTIFIED BY "DEMO_ONLY_REPLACE_BEFORE_EXECUTION";
GRANT SELECT ON demo_invoice TO demo_reader;
REVOKE UPDATE ON demo_invoice FROM demo_reader;
CREATE SYNONYM demo_invoice_alias FOR demo_invoice;
CREATE PUBLIC SYNONYM demo_public_invoice FOR demo_invoice;
COMMENT ON TABLE demo_invoice IS 'Original static conversion example';
CREATE SCHEMA AUTHORIZATION demo_operator CREATE TABLE demo_owned (id NUMBER);
CREATE TYPE demo_money_object AS OBJECT (amount NUMBER(18,2), currency_code VARCHAR2(3), MEMBER FUNCTION rounded_amount RETURN NUMBER);
/
CREATE TYPE BODY demo_money_object AS
    MEMBER FUNCTION rounded_amount RETURN NUMBER IS
    BEGIN
        RETURN ROUND(SELF.amount, 2);
    END;
END;
/
CREATE OR REPLACE PROCEDURE demo_transient_any_review(p_type IN SYS.ANYTYPE, p_rows IN SYS.ANYDATASET) AS
BEGIN
    IF p_rows IS NULL THEN
        RETURN;
    END IF;
END;
/
CREATE TYPE demo_money_list AS TABLE OF demo_money_object;
/
CREATE MATERIALIZED VIEW demo_customer_totals BUILD DEFERRED REFRESH COMPLETE ON DEMAND AS SELECT customer_id, SUM(invoice_total) AS total FROM demo_invoice GROUP BY customer_id;
CREATE DIRECTORY demo_import_dir AS '/review/demo/import';
CREATE DATABASE LINK demo_archive CONNECT TO CURRENT_USER USING 'DEMO_ARCHIVE_SERVICE';
CREATE BITMAP INDEX demo_invoice_status_bix ON demo_invoice(status);
CREATE CLUSTER demo_customer_cluster (customer_id NUMBER);
CREATE TABLE demo_clustered_invoice (customer_id NUMBER, invoice_id NUMBER) CLUSTER demo_customer_cluster(customer_id);
