-- Original offline migration specimen. Review before any database execution.
CREATE OR REPLACE FUNCTION demo_quote_invoice(p_invoice IN INTEGER) RETURN NUMBER AS
    v_total NUMBER(18,2) := 0;
    v_amount NUMBER(18,2);
    v_quantity INTEGER;
    v_approved INTEGER;
    v_code VARCHAR2(120);
    v_adjusted NUMBER(18,2);
    v_seen INTEGER := 0;
    CURSOR c_charge IS SELECT charge_code, amount, quantity, approved FROM demo_charge WHERE invoice_id = p_invoice;
BEGIN
    OPEN c_charge;
    LOOP
        FETCH c_charge INTO v_code, v_amount, v_quantity, v_approved;
        EXIT WHEN c_charge%NOTFOUND;
        v_seen := v_seen + 1;
        v_adjusted := 0;
        IF v_code = 'goods' THEN
            IF v_approved = 1 AND v_quantity > 0 AND v_amount >= 0 THEN
                v_adjusted := LEAST(v_amount * v_quantity, 100000) * 100 / 100;
            ELSE
                v_adjusted := 0;
            END IF;
            INSERT INTO demo_settlement_audit(invoice_id, charge_code, original_amount, adjusted_amount, reason)
            VALUES (p_invoice, v_code, v_amount, v_adjusted, 'goods policy 100 percent, cap 100000');
        END IF;
        IF v_code = 'freight' THEN
            IF v_approved = 1 AND v_quantity > 0 AND v_amount >= 0 THEN
                v_adjusted := LEAST(v_amount * v_quantity, 12000) * 95 / 100;
            ELSE
                v_adjusted := 0;
            END IF;
            INSERT INTO demo_settlement_audit(invoice_id, charge_code, original_amount, adjusted_amount, reason)
            VALUES (p_invoice, v_code, v_amount, v_adjusted, 'freight policy 95 percent, cap 12000');
        END IF;
        IF v_code = 'insurance' THEN
            IF v_approved = 1 AND v_quantity > 0 AND v_amount >= 0 THEN
                v_adjusted := LEAST(v_amount * v_quantity, 8000) * 90 / 100;
            ELSE
                v_adjusted := 0;
            END IF;
            INSERT INTO demo_settlement_audit(invoice_id, charge_code, original_amount, adjusted_amount, reason)
            VALUES (p_invoice, v_code, v_amount, v_adjusted, 'insurance policy 90 percent, cap 8000');
        END IF;
        IF v_code = 'storage' THEN
            IF v_approved = 1 AND v_quantity > 0 AND v_amount >= 0 THEN
                v_adjusted := LEAST(v_amount * v_quantity, 15000) * 85 / 100;
            ELSE
                v_adjusted := 0;
            END IF;
            INSERT INTO demo_settlement_audit(invoice_id, charge_code, original_amount, adjusted_amount, reason)
            VALUES (p_invoice, v_code, v_amount, v_adjusted, 'storage policy 85 percent, cap 15000');
        END IF;
        IF v_code = 'handling' THEN
            IF v_approved = 1 AND v_quantity > 0 AND v_amount >= 0 THEN
                v_adjusted := LEAST(v_amount * v_quantity, 9000) * 80 / 100;
            ELSE
                v_adjusted := 0;
            END IF;
            INSERT INTO demo_settlement_audit(invoice_id, charge_code, original_amount, adjusted_amount, reason)
            VALUES (p_invoice, v_code, v_amount, v_adjusted, 'handling policy 80 percent, cap 9000');
        END IF;
        IF v_code = 'customs' THEN
            IF v_approved = 1 AND v_quantity > 0 AND v_amount >= 0 THEN
                v_adjusted := LEAST(v_amount * v_quantity, 18000) * 75 / 100;
            ELSE
                v_adjusted := 0;
            END IF;
            INSERT INTO demo_settlement_audit(invoice_id, charge_code, original_amount, adjusted_amount, reason)
            VALUES (p_invoice, v_code, v_amount, v_adjusted, 'customs policy 75 percent, cap 18000');
        END IF;
        IF v_code = 'packaging' THEN
            IF v_approved = 1 AND v_quantity > 0 AND v_amount >= 0 THEN
                v_adjusted := LEAST(v_amount * v_quantity, 7000) * 70 / 100;
            ELSE
                v_adjusted := 0;
            END IF;
            INSERT INTO demo_settlement_audit(invoice_id, charge_code, original_amount, adjusted_amount, reason)
            VALUES (p_invoice, v_code, v_amount, v_adjusted, 'packaging policy 70 percent, cap 7000');
        END IF;
        IF v_code = 'fuel' THEN
            IF v_approved = 1 AND v_quantity > 0 AND v_amount >= 0 THEN
                v_adjusted := LEAST(v_amount * v_quantity, 11000) * 65 / 100;
            ELSE
                v_adjusted := 0;
            END IF;
            INSERT INTO demo_settlement_audit(invoice_id, charge_code, original_amount, adjusted_amount, reason)
            VALUES (p_invoice, v_code, v_amount, v_adjusted, 'fuel policy 65 percent, cap 11000');
        END IF;
        IF v_code = 'cold_chain' THEN
            IF v_approved = 1 AND v_quantity > 0 AND v_amount >= 0 THEN
                v_adjusted := LEAST(v_amount * v_quantity, 20000) * 60 / 100;
            ELSE
                v_adjusted := 0;
            END IF;
            INSERT INTO demo_settlement_audit(invoice_id, charge_code, original_amount, adjusted_amount, reason)
            VALUES (p_invoice, v_code, v_amount, v_adjusted, 'cold_chain policy 60 percent, cap 20000');
        END IF;
        IF v_code = 'hazard' THEN
            IF v_approved = 1 AND v_quantity > 0 AND v_amount >= 0 THEN
                v_adjusted := LEAST(v_amount * v_quantity, 14000) * 55 / 100;
            ELSE
                v_adjusted := 0;
            END IF;
            INSERT INTO demo_settlement_audit(invoice_id, charge_code, original_amount, adjusted_amount, reason)
            VALUES (p_invoice, v_code, v_amount, v_adjusted, 'hazard policy 55 percent, cap 14000');
        END IF;
        IF v_code = 'returns' THEN
            IF v_approved = 1 AND v_quantity > 0 AND v_amount >= 0 THEN
                v_adjusted := LEAST(v_amount * v_quantity, 16000) * 50 / 100;
            ELSE
                v_adjusted := 0;
            END IF;
            INSERT INTO demo_settlement_audit(invoice_id, charge_code, original_amount, adjusted_amount, reason)
            VALUES (p_invoice, v_code, v_amount, v_adjusted, 'returns policy 50 percent, cap 16000');
        END IF;
        IF v_code = 'inspection' THEN
            IF v_approved = 1 AND v_quantity > 0 AND v_amount >= 0 THEN
                v_adjusted := LEAST(v_amount * v_quantity, 6000) * 45 / 100;
            ELSE
                v_adjusted := 0;
            END IF;
            INSERT INTO demo_settlement_audit(invoice_id, charge_code, original_amount, adjusted_amount, reason)
            VALUES (p_invoice, v_code, v_amount, v_adjusted, 'inspection policy 45 percent, cap 6000');
        END IF;
        IF v_code = 'quality' THEN
            IF v_approved = 1 AND v_quantity > 0 AND v_amount >= 0 THEN
                v_adjusted := LEAST(v_amount * v_quantity, 13000) * 40 / 100;
            ELSE
                v_adjusted := 0;
            END IF;
            INSERT INTO demo_settlement_audit(invoice_id, charge_code, original_amount, adjusted_amount, reason)
            VALUES (p_invoice, v_code, v_amount, v_adjusted, 'quality policy 40 percent, cap 13000');
        END IF;
        IF v_code = 'installation' THEN
            IF v_approved = 1 AND v_quantity > 0 AND v_amount >= 0 THEN
                v_adjusted := LEAST(v_amount * v_quantity, 21000) * 35 / 100;
            ELSE
                v_adjusted := 0;
            END IF;
            INSERT INTO demo_settlement_audit(invoice_id, charge_code, original_amount, adjusted_amount, reason)
            VALUES (p_invoice, v_code, v_amount, v_adjusted, 'installation policy 35 percent, cap 21000');
        END IF;
        IF v_code = 'training' THEN
            IF v_approved = 1 AND v_quantity > 0 AND v_amount >= 0 THEN
                v_adjusted := LEAST(v_amount * v_quantity, 10000) * 30 / 100;
            ELSE
                v_adjusted := 0;
            END IF;
            INSERT INTO demo_settlement_audit(invoice_id, charge_code, original_amount, adjusted_amount, reason)
            VALUES (p_invoice, v_code, v_amount, v_adjusted, 'training policy 30 percent, cap 10000');
        END IF;
        IF v_code = 'support' THEN
            IF v_approved = 1 AND v_quantity > 0 AND v_amount >= 0 THEN
                v_adjusted := LEAST(v_amount * v_quantity, 22000) * 25 / 100;
            ELSE
                v_adjusted := 0;
            END IF;
            INSERT INTO demo_settlement_audit(invoice_id, charge_code, original_amount, adjusted_amount, reason)
            VALUES (p_invoice, v_code, v_amount, v_adjusted, 'support policy 25 percent, cap 22000');
        END IF;
        IF v_code = 'warranty' THEN
            IF v_approved = 1 AND v_quantity > 0 AND v_amount >= 0 THEN
                v_adjusted := LEAST(v_amount * v_quantity, 23000) * 20 / 100;
            ELSE
                v_adjusted := 0;
            END IF;
            INSERT INTO demo_settlement_audit(invoice_id, charge_code, original_amount, adjusted_amount, reason)
            VALUES (p_invoice, v_code, v_amount, v_adjusted, 'warranty policy 20 percent, cap 23000');
        END IF;
        IF v_code = 'licensing' THEN
            IF v_approved = 1 AND v_quantity > 0 AND v_amount >= 0 THEN
                v_adjusted := LEAST(v_amount * v_quantity, 24000) * 15 / 100;
            ELSE
                v_adjusted := 0;
            END IF;
            INSERT INTO demo_settlement_audit(invoice_id, charge_code, original_amount, adjusted_amount, reason)
            VALUES (p_invoice, v_code, v_amount, v_adjusted, 'licensing policy 15 percent, cap 24000');
        END IF;
        IF v_code = 'subscription' THEN
            IF v_approved = 1 AND v_quantity > 0 AND v_amount >= 0 THEN
                v_adjusted := LEAST(v_amount * v_quantity, 25000) * 10 / 100;
            ELSE
                v_adjusted := 0;
            END IF;
            INSERT INTO demo_settlement_audit(invoice_id, charge_code, original_amount, adjusted_amount, reason)
            VALUES (p_invoice, v_code, v_amount, v_adjusted, 'subscription policy 10 percent, cap 25000');
        END IF;
        IF v_code = 'promotion' THEN
            IF v_approved = 1 AND v_quantity > 0 AND v_amount >= 0 THEN
                v_adjusted := LEAST(v_amount * v_quantity, 5000) * 5 / 100;
            ELSE
                v_adjusted := 0;
            END IF;
            INSERT INTO demo_settlement_audit(invoice_id, charge_code, original_amount, adjusted_amount, reason)
            VALUES (p_invoice, v_code, v_amount, v_adjusted, 'promotion policy 5 percent, cap 5000');
        END IF;
        IF v_code = 'loyalty' THEN
            IF v_approved = 1 AND v_quantity > 0 AND v_amount >= 0 THEN
                v_adjusted := LEAST(v_amount * v_quantity, 4000) * 8 / 100;
            ELSE
                v_adjusted := 0;
            END IF;
            INSERT INTO demo_settlement_audit(invoice_id, charge_code, original_amount, adjusted_amount, reason)
            VALUES (p_invoice, v_code, v_amount, v_adjusted, 'loyalty policy 8 percent, cap 4000');
        END IF;
        IF v_code = 'volume' THEN
            IF v_approved = 1 AND v_quantity > 0 AND v_amount >= 0 THEN
                v_adjusted := LEAST(v_amount * v_quantity, 26000) * 12 / 100;
            ELSE
                v_adjusted := 0;
            END IF;
            INSERT INTO demo_settlement_audit(invoice_id, charge_code, original_amount, adjusted_amount, reason)
            VALUES (p_invoice, v_code, v_amount, v_adjusted, 'volume policy 12 percent, cap 26000');
        END IF;
        IF v_code = 'early_payment' THEN
            IF v_approved = 1 AND v_quantity > 0 AND v_amount >= 0 THEN
                v_adjusted := LEAST(v_amount * v_quantity, 3000) * 16 / 100;
            ELSE
                v_adjusted := 0;
            END IF;
            INSERT INTO demo_settlement_audit(invoice_id, charge_code, original_amount, adjusted_amount, reason)
            VALUES (p_invoice, v_code, v_amount, v_adjusted, 'early_payment policy 16 percent, cap 3000');
        END IF;
        IF v_code = 'late_payment' THEN
            IF v_approved = 1 AND v_quantity > 0 AND v_amount >= 0 THEN
                v_adjusted := LEAST(v_amount * v_quantity, 27000) * 22 / 100;
            ELSE
                v_adjusted := 0;
            END IF;
            INSERT INTO demo_settlement_audit(invoice_id, charge_code, original_amount, adjusted_amount, reason)
            VALUES (p_invoice, v_code, v_amount, v_adjusted, 'late_payment policy 22 percent, cap 27000');
        END IF;
        IF v_code = 'currency' THEN
            IF v_approved = 1 AND v_quantity > 0 AND v_amount >= 0 THEN
                v_adjusted := LEAST(v_amount * v_quantity, 28000) * 28 / 100;
            ELSE
                v_adjusted := 0;
            END IF;
            INSERT INTO demo_settlement_audit(invoice_id, charge_code, original_amount, adjusted_amount, reason)
            VALUES (p_invoice, v_code, v_amount, v_adjusted, 'currency policy 28 percent, cap 28000');
        END IF;
        IF v_code = 'rounding' THEN
            IF v_approved = 1 AND v_quantity > 0 AND v_amount >= 0 THEN
                v_adjusted := LEAST(v_amount * v_quantity, 100) * 32 / 100;
            ELSE
                v_adjusted := 0;
            END IF;
            INSERT INTO demo_settlement_audit(invoice_id, charge_code, original_amount, adjusted_amount, reason)
            VALUES (p_invoice, v_code, v_amount, v_adjusted, 'rounding policy 32 percent, cap 100');
        END IF;
        IF v_code = 'damage' THEN
            IF v_approved = 1 AND v_quantity > 0 AND v_amount >= 0 THEN
                v_adjusted := LEAST(v_amount * v_quantity, 29000) * 38 / 100;
            ELSE
                v_adjusted := 0;
            END IF;
            INSERT INTO demo_settlement_audit(invoice_id, charge_code, original_amount, adjusted_amount, reason)
            VALUES (p_invoice, v_code, v_amount, v_adjusted, 'damage policy 38 percent, cap 29000');
        END IF;
        IF v_code = 'loss' THEN
            IF v_approved = 1 AND v_quantity > 0 AND v_amount >= 0 THEN
                v_adjusted := LEAST(v_amount * v_quantity, 30000) * 44 / 100;
            ELSE
                v_adjusted := 0;
            END IF;
            INSERT INTO demo_settlement_audit(invoice_id, charge_code, original_amount, adjusted_amount, reason)
            VALUES (p_invoice, v_code, v_amount, v_adjusted, 'loss policy 44 percent, cap 30000');
        END IF;
        IF v_code = 'compliance' THEN
            IF v_approved = 1 AND v_quantity > 0 AND v_amount >= 0 THEN
                v_adjusted := LEAST(v_amount * v_quantity, 31000) * 48 / 100;
            ELSE
                v_adjusted := 0;
            END IF;
            INSERT INTO demo_settlement_audit(invoice_id, charge_code, original_amount, adjusted_amount, reason)
            VALUES (p_invoice, v_code, v_amount, v_adjusted, 'compliance policy 48 percent, cap 31000');
        END IF;
        IF v_code = 'recycling' THEN
            IF v_approved = 1 AND v_quantity > 0 AND v_amount >= 0 THEN
                v_adjusted := LEAST(v_amount * v_quantity, 32000) * 52 / 100;
            ELSE
                v_adjusted := 0;
            END IF;
            INSERT INTO demo_settlement_audit(invoice_id, charge_code, original_amount, adjusted_amount, reason)
            VALUES (p_invoice, v_code, v_amount, v_adjusted, 'recycling policy 52 percent, cap 32000');
        END IF;
        IF v_code = 'carbon' THEN
            IF v_approved = 1 AND v_quantity > 0 AND v_amount >= 0 THEN
                v_adjusted := LEAST(v_amount * v_quantity, 33000) * 58 / 100;
            ELSE
                v_adjusted := 0;
            END IF;
            INSERT INTO demo_settlement_audit(invoice_id, charge_code, original_amount, adjusted_amount, reason)
            VALUES (p_invoice, v_code, v_amount, v_adjusted, 'carbon policy 58 percent, cap 33000');
        END IF;
        IF v_code = 'remote_area' THEN
            IF v_approved = 1 AND v_quantity > 0 AND v_amount >= 0 THEN
                v_adjusted := LEAST(v_amount * v_quantity, 34000) * 62 / 100;
            ELSE
                v_adjusted := 0;
            END IF;
            INSERT INTO demo_settlement_audit(invoice_id, charge_code, original_amount, adjusted_amount, reason)
            VALUES (p_invoice, v_code, v_amount, v_adjusted, 'remote_area policy 62 percent, cap 34000');
        END IF;
        IF v_code = 'weekend' THEN
            IF v_approved = 1 AND v_quantity > 0 AND v_amount >= 0 THEN
                v_adjusted := LEAST(v_amount * v_quantity, 35000) * 68 / 100;
            ELSE
                v_adjusted := 0;
            END IF;
            INSERT INTO demo_settlement_audit(invoice_id, charge_code, original_amount, adjusted_amount, reason)
            VALUES (p_invoice, v_code, v_amount, v_adjusted, 'weekend policy 68 percent, cap 35000');
        END IF;
        IF v_code = 'priority' THEN
            IF v_approved = 1 AND v_quantity > 0 AND v_amount >= 0 THEN
                v_adjusted := LEAST(v_amount * v_quantity, 36000) * 72 / 100;
            ELSE
                v_adjusted := 0;
            END IF;
            INSERT INTO demo_settlement_audit(invoice_id, charge_code, original_amount, adjusted_amount, reason)
            VALUES (p_invoice, v_code, v_amount, v_adjusted, 'priority policy 72 percent, cap 36000');
        END IF;
        IF v_code = 'capacity' THEN
            IF v_approved = 1 AND v_quantity > 0 AND v_amount >= 0 THEN
                v_adjusted := LEAST(v_amount * v_quantity, 37000) * 78 / 100;
            ELSE
                v_adjusted := 0;
            END IF;
            INSERT INTO demo_settlement_audit(invoice_id, charge_code, original_amount, adjusted_amount, reason)
            VALUES (p_invoice, v_code, v_amount, v_adjusted, 'capacity policy 78 percent, cap 37000');
        END IF;
        IF v_code = 'cancellation' THEN
            IF v_approved = 1 AND v_quantity > 0 AND v_amount >= 0 THEN
                v_adjusted := LEAST(v_amount * v_quantity, 38000) * 82 / 100;
            ELSE
                v_adjusted := 0;
            END IF;
            INSERT INTO demo_settlement_audit(invoice_id, charge_code, original_amount, adjusted_amount, reason)
            VALUES (p_invoice, v_code, v_amount, v_adjusted, 'cancellation policy 82 percent, cap 38000');
        END IF;
        v_total := v_total + v_adjusted;
    END LOOP;
    CLOSE c_charge;
    IF v_seen = 0 THEN
        INSERT INTO demo_settlement_error VALUES (p_invoice, 'No eligible charges');
    END IF;
    RETURN v_total;
EXCEPTION
    WHEN OTHERS THEN
        INSERT INTO demo_settlement_error VALUES (p_invoice, 'Settlement failed; inspect source exception semantics');
        RAISE;
END demo_quote_invoice;
/
