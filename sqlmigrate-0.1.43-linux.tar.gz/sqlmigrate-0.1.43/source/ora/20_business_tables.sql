-- Original offline migration specimen. Review before any database execution.
CREATE TABLE MIGRATOR_SAMPLE (id INTEGER PRIMARY KEY, label VARCHAR2(120));
CREATE TABLE demo_invoice (invoice_id INTEGER PRIMARY KEY, customer_id INTEGER NOT NULL, invoice_total NUMBER(18,2), settlement_total NUMBER(18,2), status VARCHAR2(120));
CREATE TABLE demo_charge (invoice_id INTEGER, charge_code VARCHAR2(120), amount NUMBER(18,2), quantity INTEGER, approved INTEGER);
CREATE TABLE demo_settlement_audit (invoice_id INTEGER, charge_code VARCHAR2(120), original_amount NUMBER(18,2), adjusted_amount NUMBER(18,2), reason VARCHAR2(120));
CREATE TABLE demo_settlement_error (invoice_id INTEGER, error_message VARCHAR2(120));
CREATE SEQUENCE demo_invoice_seq START WITH 1000 INCREMENT BY 1;
CREATE INDEX demo_charge_invoice_ix ON demo_charge(invoice_id, charge_code);
CREATE VIEW demo_open_invoice AS SELECT invoice_id, customer_id, invoice_total FROM demo_invoice WHERE status = 'OPEN';
INSERT INTO MIGRATOR_SAMPLE VALUES (1, 'offline settlement catalog');
INSERT INTO demo_invoice VALUES (1001, 501, 1250, 0, 'OPEN');
INSERT INTO demo_charge VALUES (1001, 'goods', 1000, 1, 1);
INSERT INTO demo_charge VALUES (1001, 'freight', 250, 1, 1);
