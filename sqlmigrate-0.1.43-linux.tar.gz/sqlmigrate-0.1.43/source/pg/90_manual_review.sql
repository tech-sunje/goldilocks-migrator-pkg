-- Original offline migration specimen. Review before any database execution.
-- Native objects retained for explicit manual design/privilege review.
CREATE ROLE demo_reader NOLOGIN;
CREATE USER demo_operator;
CREATE SCHEMA demo_reporting;
GRANT SELECT ON demo_invoice TO demo_reader;
REVOKE UPDATE ON demo_invoice FROM demo_reader;
CREATE MATERIALIZED VIEW demo_customer_totals AS SELECT customer_id, SUM(invoice_total) AS total FROM demo_invoice GROUP BY customer_id;
CREATE UNIQUE INDEX demo_customer_totals_ix ON demo_customer_totals(customer_id);
CREATE EXTENSION IF NOT EXISTS postgres_fdw;
CREATE SERVER demo_archive FOREIGN DATA WRAPPER postgres_fdw OPTIONS (host 'archive.invalid', dbname 'archive');
CREATE FOREIGN TABLE demo_external_invoice (invoice_id integer, amount numeric(18,2)) SERVER demo_archive;
CREATE PUBLICATION demo_invoice_pub FOR TABLE demo_invoice;
CREATE POLICY demo_invoice_policy ON demo_invoice USING (customer_id > 0);
COMMENT ON TABLE demo_invoice IS 'Original static conversion example';
-- No synonym, directory, native package, or Oracle-style database link exists in PostgreSQL.
-- FDW/server above requires a separate migration design; no user mapping or credentials included.
-- Pseudo-types void/record/trigger/internal/anyelement/cstring are routine-only; never table columns.
