-- Original offline migration specimen. Review before any database execution.
CREATE FUNCTION demo_invoice_guard() RETURNS trigger LANGUAGE plpgsql AS $guard$
BEGIN
    IF NEW.invoice_total < 0 THEN
        RAISE EXCEPTION 'invoice total must be nonnegative';
    END IF;
    RETURN NEW;
END;
$guard$;
CREATE TRIGGER demo_invoice_guard BEFORE INSERT OR UPDATE ON demo_invoice FOR EACH ROW EXECUTE FUNCTION demo_invoice_guard();
