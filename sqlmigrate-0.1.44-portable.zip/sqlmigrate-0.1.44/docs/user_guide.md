# SQL Migrator 사용자 매뉴얼

기준 버전: 0.1.44 / 최종 정리: 2026-10-28 / 대상: GOLDILOCKS Cluster 26c.1

이 문서는 설치, 입력 SQL 준비, INI 설정, 실행 옵션, 변환 정책, 터미널 검토(TUI), HTML·Excel 보고서 사용법을 한곳에서 설명합니다. 사용자에게 보이는 동작·옵션·변환 규칙·화면이 바뀌면 코드와 함께 이 문서도 갱신합니다.

## 목차

1. [제품과 실행 환경](#environment)
2. [압축 해제와 설치](#installation)
3. [입력 SQL 준비](#source-files)
4. [INI 설정](#configuration)
5. [실행 방법과 옵션](#execution)
6. [변환 규칙](#conversion-rules)
7. [결과 파일](#outputs)
8. [터미널 검토 화면](#tui)
9. [HTML 보고서](#html-report)
10. [Excel·JSON과 집계 기준](#counts)
11. [대상 DB에서 별도 검증](#database-verification)
12. [문제 해결](#troubleshooting)
13. [개발 환경의 빌드·테스트·배포](#development)
14. [전체 INI 예제](#full-ini)

<a id="environment"></a>
## 1. 제품과 실행 환경

Oracle 또는 Altibase에서 추출한 SQL을 정적으로 분석하여 GOLDILOCKS Cluster용 변환 초안과 검토 보고서를 생성합니다. 자료형, DDL·DML, 뷰의 조회문, 프로시저·함수·트리거·패키지 내부 구문을 인식 범위에서 검사합니다. 모든 벤더 문법을 완전히 지원한다는 의미는 아니며, 인식하지 못하거나 정책이 확정되지 않은 구문은 위치·사유와 함께 검토 대상으로 표시합니다.

| 항목 | 현재 조건 |
|---|---|
| 실행 OS | Linux |
| Java | JRE 1.8 이상. JRE는 배포 압축파일에 포함하지 않음 |
| 입력 제품 버전 | Oracle 9i 이상, Altibase 3 이상. 버전별 모든 문법의 검증 완료를 의미하지 않음 |
| 대상 프로필 | GOLDILOCKS Cluster 26c.1 |
| 실행 방식 | `method=file`만 구현. `direct`는 예약 상태이며 선택 시 오류 |
| DB 기동·접속 | 파일 변환에는 불필요. Altibase·GOLDILOCKS가 꺼져 있어도 실행 가능 |
| 인터넷 | 불필요. 외부 서버·CDN·매뉴얼 파일을 실행 중 조회하지 않음 |
| 추가 설치 | 현장 실행에 JDK·Python·Go·ANTLR 설치 불필요 |
| TUI | 실제 터미널과 Linux `stty` 필요. X Window 불필요 |
| HTML 검토 | JavaScript를 사용할 수 있는 브라우저. HTML을 다른 PC로 복사해 열어도 됨 |

변환기는 데이터 행을 전송하지 않으며, 생성된 SQL을 DB에 실행하지 않습니다. `자동 처리 완료`는 정적 분석·파일 변환의 결과입니다. DB 생성 성공, 업무 로직, 성능·의미의 동등성은 별도 검증 항목입니다.

<a id="installation"></a>
## 2. 압축 해제와 설치

배포 파일 `sqlmigrate-<버전>-linux.tar.gz`와 체크섬 파일을 서버로 복사합니다. 아래 명령은 0.1.28 예제입니다. 압축을 푼 디렉터리에는 쓰기 권한이 필요합니다.

```sh
# 체크섬 파일도 같은 디렉터리에 복사한 경우
sha256sum -c sqlmigrate-0.1.28-linux.tar.gz.sha256

tar -xzf sqlmigrate-0.1.28-linux.tar.gz
cd sqlmigrate-0.1.28
java -version

# java가 PATH에 없거나 사용할 JRE를 직접 지정하는 경우
export JAVA_HOME=/path/to/jre
```

별도 설치 프로그램이나 서비스 등록은 없습니다. `JAVA_HOME`이 있으면 실행 스크립트는 `$JAVA_HOME/bin/java`를 사용하고, 없으면 PATH의 `java`를 사용합니다.

```text
sqlmigrate-0.1.28/
  sqlmigrate.jar          실행 프로그램
  sqlmigrate             실행 스크립트
  run.sh                 실행 스크립트
  review.sh              터미널 검토 실행 스크립트
  migrate.ini            실제 실행 설정
  migrate.conf.example   설정 예제
  README.md              이 사용자 매뉴얼의 위치 안내
  docs/user_guide.md      통합 사용자 매뉴얼
  licenses/              라이선스
  source/                사용자가 추출한 .sql 파일을 둘 위치
```

`migrate.ini`가 실행 설정입니다. 파일명은 고정되지 않습니다. `migrator.ini`로 저장했다면 `--config migrator.ini`로 지정합니다. 예제 파일을 수정해도 `--config`에서 그 파일을 선택하지 않으면 적용되지 않습니다.

<a id="source-files"></a>
## 3. 입력 SQL 준비

1. 원본 DB에서 DDL·SQL을 텍스트로 추출합니다. Altibase는 aexport로 추출한 SQL을 사용할 수 있습니다.
2. 변환할 파일을 배포 디렉터리의 `source/` 아래에 복사합니다.
3. 모든 입력 확장자는 `.sql`로 통일합니다. `.SQL`도 인식합니다. 하위 디렉터리도 재귀적으로 읽습니다.
4. INI의 `input`을 해당 디렉터리로 지정합니다.

```text
source/
  tables.sql
  indexes.sql
  routines/
    procedures.sql
    functions.sql
    packages.sql
  security.sql
```

한 파일에 여러 객체가 있어도 됩니다. 프로시저·함수·패키지의 줄바꿈·주석을 유지한 추출물을 그대로 넣습니다. 바이너리 덤프나 데이터 파일은 SQL 입력이 아닙니다. `.sql` 이외 파일은 변환 입력에서 제외합니다. aexport가 만든 `run_*.sh`를 실행할 필요는 없습니다.

기본 인코딩은 UTF-8입니다. 원본이 MS949/EUC-KR 등이라면 INI의 `encoding`을 실제 인코딩에 맞춥니다. 잘못된 바이트를 임의의 문자로 대체하지 않고 오류로 알립니다. 변환 SQL 파일은 원본 인코딩·BOM·줄바꿈 형식을 보존하며, HTML·검토 텍스트·JSON은 UTF-8입니다. HTML에서 일괄 다운로드하는 SQL은 UTF-8입니다.

원본 파일은 수정하지 않습니다. `output`은 `input` 하위 디렉터리로 지정할 수 있습니다(예: `input=../test1`, `output=../test1/output`). 출력 디렉터리 전체는 입력 SQL 수집에서 제외하므로 재실행 시 이전 결과를 다시 변환하지 않습니다. 두 경로가 같거나 `output`이 `input`의 상위 경로인 경우는 원본 보호를 위해 허용하지 않습니다. 입력 파일 및 경로의 심볼릭 링크는 허용하지 않습니다.

<a id="configuration"></a>
## 4. INI 설정

### 4.1 먼저 수정할 항목

배포본 `migrate.ini`에는 변환 규칙이 들어 있습니다. 기본 정책을 사용할 경우 `[common]`의 입력·출력 경로와 원본 제품·버전을 확인하고 실행합니다. 테이블스페이스와 원본 익스텐트 크기는 현장 값에 맞는지 확인합니다.

```ini
[common]
method = file
source = altibase
target = goldilocks
source_version = 7.3
target_version = 26c.1
input = source
output = target
convert = true
report = html,xlsx
encoding = UTF-8
```

상대 경로는 **INI 파일이 있는 디렉터리 기준**입니다. 예를 들어 `/opt/sqlmigrate/migrate.ini`에 `input=source`라고 쓰면 `/opt/sqlmigrate/source`를 읽습니다. 명령을 실행한 현재 디렉터리 기준이 아닙니다. CLI에서 직접 지정한 상대 경로는 실행한 현재 디렉터리 기준입니다.

### 4.2 공통 설정과 접속정보

| 섹션·항목 | 의미·값 |
|---|---|
| `[common] method` | `file`. `direct`는 현재 미구현 |
| `base` | `altibase`, `oracle`, `postgresql`. 기존 `source`도 같은 의미로 지원하며 함께 중복 지정할 수 없음 |
| `target` | `goldilocks` |
| `source_version` | 생략 시 A7/ORA19/PG18 기본 프로필. 예: `7.3`, `3`, `9i`, `19c`, `18` |
| `target_version` | `26c.1`. 생략 기본값도 동일 |
| `input` | `.sql` 원본이 있는 디렉터리 |
| `output` | 결과 디렉터리. 기존 결과는 정상 저장 시 새 결과로 교체 |
| `convert` | `true`: 변환 SQL과 보고서 생성. `false`: 분석 보고서만 생성. 코드 기본값은 false이므로 변환 시 명시 |
| `report` | `html,xlsx`, `html`, `xlsx`. 기본은 둘 다 |
| `encoding` | 기본 `UTF-8`. 예: `MS949`, `EUC-KR` |
| `[oracle] ip,port,user,pwd,service_name` | 예약된 direct 접속정보. 예: localhost, 1521, test, 비밀번호, orclpdb1. file 모드에서는 접속하지 않음 |
| `[altibase] ip,port,user,pwd` | 예약된 direct 모드 접속정보. file 모드에서는 사용하여 접속하지 않음 |
| `[goldilocks] ip,port,user,pwd` | 위와 동일. 실제 DB 생성 검증을 수행하는 설정이 아님 |
| `[migration-rule] review_rules` | TUI에서 저장한 사용자 개별·전체 처리 규칙 파일 경로 |

설정 파일은 UTF-8입니다. `#`, `;`로 시작하는 줄은 주석입니다. 키의 공백·밑줄·하이픈을 동일하게 처리합니다. 중복 키·알 수 없는 항목·잘못된 값은 오류입니다. 경로의 바깥 큰따옴표는 제거하고, 테이블스페이스 SQL 식별자의 따옴표는 보존합니다.

### 4.3 규칙 섹션

```ini
[rule.parallel]
action = REMOVE
scope = table_option
review = true

[rule.integer_fixed]
action = AUTO_CONVERT
scope = data_type
review = false
```

| 항목 | 의미 |
|---|---|
| `action=AUTO_CONVERT` | 지원되는 규칙 변환 수행 |
| `action=REMOVE` | 해당 규칙이 지목하는 절·토큰 제거 |
| `action=REVIEW` / `PRESERVE` | 자동 수정을 보류하고 원문 유지·검토. 모든 action을 모든 규칙에 사용할 수 있는 것은 아님 |
| `action=BLOCK` | 실행 차단. destructive_sql 규칙에서 사용 |
| `scope` | 적용 구문 영역. 해당 규칙에 정해진 값을 사용하며 임의 변경 불가 |
| `review=true` | 자동 변환·제거 후에도 검토 대상으로 표시. 규칙별 고유 검토가 추가로 남을 수도 있음 |
| `review=false` | 설정에 의한 추가 검토 표시를 끔. 실제 오류·미지원·별도 검토 판정까지 해제하는 옵션은 아님 |
| `value` 등 | 규칙별 추가 매개변수. 전체 예제 참조 |

기존 `[migration-rule]` 변환 항목도 지원하지만 같은 정책의 `[rule.*]` 설정이 우선합니다. CLI에 명시한 일반 옵션은 INI보다 우선합니다. `unsupported_feature`는 REVIEW, `destructive_sql`은 BLOCK만 허용합니다. CONSTANT·벤더 예외 등의 필수 검토는 `review=false`로 해제할 수 없습니다.

### 4.4 테이블스페이스와 물리 설정

```ini
[rule.tablespace]
action = AUTO_CONVERT
scope = tablespace
review = false
data_tbs = MEM_DATA_TBS
mem_tbs = MEM_DATA_TBS
disk_tbs = MEM_DATA_TBS
index_tbs = MEM_TEMP_TBS
temp_tbs = MEM_TEMP_TBS

[rule.storage]
action = AUTO_CONVERT
scope = table_option
value = extent_bytes
source_extent_bytes = 524288

[rule.maxtrans]
action = AUTO_CONVERT
scope = table_option
value = cpu_cores
cpu_cores = auto
```

| 원본·설정 | 동작 |
|---|---|
| 일반 CREATE TABLE | `data_tbs`. 코드 기본값 `MEM_DATA_TBS` |
| CREATE MEMORY TABLE / 메모리 계열 원본 배치 | `mem_tbs`로 배치 |
| CREATE DISK TABLE / 디스크 계열 원본 배치 | `disk_tbs`로 배치 |
| 일반 인덱스 | 원본 이름 유지, `index_tbs` 사용. 코드 기본값 `MEM_TEMP_TBS` |
| 임시 테이블 | `temp_tbs`. 해당 구문·조건에 따른 변환·검토 적용 |
| PK에 원본 TABLESPACE 있음 | `index_tbs`로 치환 |
| PK에 원본 TABLESPACE 없음 | TABLESPACE를 추가하지 않음 |
| `source_extent_bytes` | 원본 익스텐트 한 개의 바이트 크기. 예제 524288은 512 KiB이며 현장 값으로 수정 |
| `cpu_cores=auto` | Java가 실행 환경에서 인식한 CPU 수 사용. MAXTRANS는 최대 32 |

`mem_tbs`·`disk_tbs`에는 자동 기본값이 없으므로 명시합니다. 필요한 배치 설정이 없으면 `STORAGE_CONFIG_REQUIRED`로 필요한 키를 알리고 원문을 보존합니다. 변환기는 대상 테이블스페이스를 생성하거나 존재 여부를 조회하지 않습니다.

<a id="execution"></a>
## 5. 실행 방법과 옵션

이하 배포본 명령은 압축을 푼 디렉터리에서 실행합니다.

### 5.1 일괄 변환과 터미널 검토

```sh
# INI로 일괄 분석·변환
sh run.sh --config migrate.ini

# 설정 파일명을 migrator.ini로 정한 경우
sh run.sh --config migrator.ini

# 터미널에서 검토하고 수정·저장
sh run.sh review --config migrate.ini
# 같은 기능
sh review.sh --config migrate.ini

# 실행 버전과 옵션 안내
sh run.sh --version
sh run.sh --help
```

개발 소스 디렉터리에서는 프로젝트 루트에서 `sh src/run.sh --config src/review-demo.ini`를 실행합니다. 이 예제의 입력은 `altibase/`, 출력은 `test/target/review-demo/`입니다. 개발용 직접 JAR 실행 경로는 `src/build/sqlmigrate.jar`, 배포본은 `sqlmigrate.jar`입니다.

```sh
# INI 없이 CLI 옵션으로 실행
sh run.sh analyze --source altibase --source-version 7.3 \
  --input ./source --output ./target --convert --report html,xlsx

# Oracle 입력 예제
sh run.sh analyze --source oracle --source-version 19c \
  --input ./source --output ./target --convert

# INI 일부를 이번 실행에서만 덮어씀
sh run.sh --config migrate.ini --output ./target-check --report html

# 스크립트를 사용하지 않는 경우
java -jar sqlmigrate.jar --config migrate.ini
```

### 5.2 CLI 옵션

| 옵션·명령 | 설명 |
|---|---|
| `analyze` | 일반 분석·변환. `--config`로 시작하면 생략 가능 |
| `review` | TUI 검토 후 저장 또는 취소 |
| `--config FILE` | 사용할 INI 경로. 설정 파일명을 자동으로 선택하지 않음 |
| `--base oracle\|altibase\|postgresql` / `--source oracle\|altibase\|postgresql` | 원본 제품. 두 별칭을 동시에 지정하지 않음 |
| `--source-version VERSION` | 원본 버전. 생략 시 DB별 기본 버전 적용 |
| `--target-version 26c.1` | 대상 프로필 |
| `--input DIRECTORY` | 원본 디렉터리 |
| `--output DIRECTORY` | 결과 디렉터리 |
| `--convert` | 변환 파일 생성. 끄려면 INI에 `convert=false`로 두고 이 옵션을 생략 |
| `--report html,xlsx` | 생성할 보고서. `html` 또는 `xlsx`만 지정 가능 |
| `--encoding CHARSET` | 입력 인코딩 |
| `--table-tablespace NAME` | 일반 테이블 배치 설정 |
| `--index-tablespace NAME` | 인덱스 배치 설정 |
| `--help`, `--version` | 도움말 또는 실행 버전 표시 |

현재 `--help`의 일부 경로 문구에는 초기 버전의 ‘새 출력 경로’ 설명이 남아 있습니다. 실제 동작은 기존 출력 디렉터리의 결과를 정상 저장 시 교체하는 방식입니다. 원본 경로는 덮어쓰지 않습니다.

### 5.3 완료와 종료 코드

완료하면 파일·객체·규칙 처리 건수, 객체 유형별 원본/자동 처리/검토/변환 대기 수, 실행 시작·완료 일시와 실제 소요 초, 결과 파일 경로를 출력합니다. 예상 검토 공수·인시는 표시하지 않습니다.

| 종료 코드 | 의미 |
|---|---|
| `0` | 분석·보고서 생성 성공. 검토·차단 대상이 남아 있어도 0일 수 있음 |
| `2` | 옵션·설정·경로 등의 사용법 오류 |
| `1` | 파일 입출력·인코딩 등 실행 실패 |

파일 변환은 읽기·분석·변환·보고서 본문 생성까지의 시간을 측정합니다. 최종 실행 정보 기록과 출력 경로 교체는 제외합니다. TUI에서는 사용자 입력 대기도 포함합니다. 날짜에는 실행 서버의 시간대·UTC 오프셋을 표시합니다.

<a id="conversion-rules"></a>
## 6. 변환 규칙

아래는 기본 정책입니다. 인식한 구문과 자료형 범위에서 적용하며, 미인식·범위 초과·정책 불명확 항목은 원문과 사유를 남깁니다. 실제 실행 설정은 `changes.json`의 `rules`에서 확인할 수 있습니다.

### 6.1 테이블·인덱스·물리 옵션

| 규칙 섹션 | 기본 동작 |
|---|---|
| `rule.cluster` | 일반 영구 테이블을 `CLONED AT CLUSTER WIDE`로 생성. 샤딩 키나 HASH/RANGE/LIST 추정 안 함 |
| `rule.tablespace` | 설정한 테이블·인덱스·임시 테이블 배치 적용 |
| `rule.primary_key` | CREATE TABLE 내부 PK를 테이블 생성 후 `ALTER TABLE ... ADD PRIMARY KEY`로 분리 |
| `rule.constraint_index` | 원본 제약조건·인덱스 이름 보존. Oracle의 이름 있는 `USING INDEX`는 입력의 일치하는 UNIQUE 인덱스 선언을 PK/UNIQUE 생성에 통합하여 물리 인덱스를 하나만 생성. 이름이 없으면 MIG_* 등의 임의 이름을 만들지 않음 |
| `rule.integer_fixed` | `INTEGER FIXED`의 INTEGER를 INT로 변환 |
| `rule.column_storage` | FIXED/VARIABLE/지원하는 IN ROW 저장 옵션 제거 |
| `rule.compression`, `rule.logging` | COMPRESSED/UNCOMPRESSED 등 압축 및 LOGGING/NOLOGGING 절 제거 |
| `rule.lob_storage` | 미지원 `LOB (...) STORE AS (...)` 절 전체 제거. LOB용 내부 TABLESPACE도 함께 제거 |
| `rule.parallel` | PARALLEL/NOPARALLEL 절 제거 후 미지원 검토 유지 |
| `rule.maxrows` | MAXROWS 절 제거 후 미지원 검토 유지. 초안에는 MAXROWS가 남지 않음 |
| `rule.partition` | 파티션 절을 제거하고 추가 검토 제외. 마지막 자동 규칙 표에 기록 |
| `rule.maxtrans` | `MAXTRANS=min(CPU 수,32)` 적용 |
| `rule.storage` | 원본 익스텐트 수를 바이트로 환산하여 INITIAL/NEXT/MAXSIZE로 변환. MINEXTENTS는 INITIAL 최소값에 반영, MAXSIZE 상한 32 TiB |
| `rule.temporary_table` | 인식한 임시 테이블 구문을 GLOBAL TEMPORARY 형태로 변환하고 ON COMMIT 정책 보존. 영구 테이블의 CLONED 정책을 임의 적용하지 않음 |

PCTFREE/PCTUSED/INITRANS 등 인식한 공통 물리 옵션은 허용 범위를 검사하여 보존합니다. 미인식 옵션은 추정 삭제하지 않습니다. 테이블 구문 분석에 실패하면 LOB STORE 등 절을 임의의 문자열 패턴으로 잘라내지 않고 검토합니다.

```sql
-- 원본 예제
CREATE TABLE customer (
    id INTEGER FIXED PRIMARY KEY,
    name NVARCHAR(20),
    memo BLOB
);

-- 변환 형태 예제: 원본 PK에 TABLESPACE가 없으므로 추가하지 않음
CREATE TABLE customer (
    id INT,
    name VARCHAR(20 CHARACTERS),
    memo LONG VARBINARY
)
CLONED AT CLUSTER WIDE TABLESPACE MEM_DATA_TBS;
ALTER TABLE customer ADD PRIMARY KEY (id);
```

예제는 동작 설명을 위한 형태이며 실제 공백·주석·물리 옵션은 입력에 따라 달라집니다.

### 6.2 자료형

| 규칙·원본 | 기본 변환·검토 |
|---|---|
| `rule.byte`: BYTE(n) | BINARY(n). 명시 길이 1..2000 범위에서 변환 |
| `rule.nibble`: NIBBLE(n) | VARBINARY(n). 예: NIBBLE(7)은 VARBINARY(7). 보고서에 변환 기록 |
| `rule.blob`: BLOB | LONG VARBINARY |
| `rule.clob`: CLOB | LONG VARCHAR |
| `rule.national_character`: NCHAR(n) | CHAR(n CHARACTERS) |
| NVARCHAR(n)/NVARCHAR2(n) | VARCHAR(n CHARACTERS) |
| `rule.nvarchar_unspecified_length`: 길이 없는 NVARCHAR | VARCHAR(2000 CHARACTERS) |
| `rule.varchar_unspecified_length`: 길이 없는 VARCHAR | VARCHAR(4000) 자동 변환, 추가 검토 제외 |
| `rule.varchar_units` | 일반 CHAR/VARCHAR 계열의 생략 길이 단위 OCTETS. 원본에 명시된 단위는 보존 |
| `rule.float_precision`: Altibase FLOAT(p) | 십진 정밀도를 대상 이진 정밀도로 환산. FLOAT(20)→FLOAT(67), FLOAT(38)→FLOAT(126) |
| `rule.type_alias` | 인식 범위에서 VARCHAR2→VARCHAR, DEC→DECIMAL 등 별칭 정규화. Oracle NUMBER(*,s)의 정밀도 38 명시 |
| `rule.local_timezone` | 인식한 WITH LOCAL TIME ZONE을 WITH TIME ZONE으로 변환 |

NCHAR/NVARCHAR 변환은 CHARACTERS 길이 규칙입니다. 원본 national charset을 별도 생성하거나 대상 문자셋을 바꾸는 기능은 아닙니다. BLOB/CLOB 대상 LONG 타입의 최대 크기 100MB 등 원본과 차이가 있는 제한은 보고서에서 확인합니다. AST로 인식한 PSM 매개변수·반환값·지역변수에도 해당 자료형 규칙을 적용합니다. 날짜·시간 및 기타 자료형은 실제 인식한 구문의 판정·사유를 확인하십시오.

### 6.3 PSM·내장 기능·권한

| 규칙·항목 | 기본 동작 |
|---|---|
| PSM 구조 검사 | 선언, 매개변수 IN/OUT/IN OUT, 반환 타입, 표현식, IF/CASE/반복/예외·커서·조회·DML 구조 등을 인식 범위에서 검사 |
| 사용자 객체 참조 | 미생성 의존성 자체로 차단하지 않음. 입력에 선언된 호출의 인자·타입·반환값 등은 검사 |
| 내장 기능 | 사용자 선언과 구분. 대상 미지원·미확인 내장 기능은 구체적 사유와 위치 표시 |
| `rule.dynamic_sql` | 고정 문자열 SQL과 바인드를 검사·변환. 지원 정적 DDL은 EXECUTE IMMEDIATE 형태로 생성. 값을 확정할 수 없는 동적 SQL은 검토 |
| `rule.collection_subscript` | associative array의 원소 접근 `[]`를 `()`로 변환 |
| `rule.collection_delete_all` | 지원 문맥의 `n := a.DELETE()`를 삭제 개수 저장 및 키 순회 삭제 구문으로 변환 |
| `rule.constant` | CONSTANT만 제거하고 초기값·타입 보존. 읽기 전용 제약 제거 검토는 필수 유지 |
| `rule.vendor_exception` | 지원하는 벤더 파일 예외의 마지막 WHEN을 OTHERS 초안으로 변경하고 검토 유지. RAISE·중복 OTHERS 등 충돌은 별도 검토 |
| PRAGMA EXCEPTION_INIT | 구문 인식. 벤더 오류 코드 대응은 숫자 위치에서 검토 |
| TYPESET, VARRAY, 오버로드, NOCOPY, BULK COLLECT | 현재 구현의 검토 정책 유지. 호환으로 일괄 승인하지 않음 |
| `rule.print` | PRINT→DBMS_OUTPUT.PUT, PRINTLN 및 단독 PUT_LINE→DBMS_OUTPUT.PUT_LINE. 다중 인자 등 미지원 호출은 검토 |
| `rule.privilege_object` | 입력에 정의된 객체 종류로 권한 대상을 변환. 시퀀스 SELECT 권한→USAGE ON SEQUENCE 등 |
| SEQUENCE·ROLE·GRANT·REVOKE | 인식한 옵션·권한·대상·수신자 구조 검사 후 변환 또는 원문 유지 |
| `rule.client_command` | CONNECT/CONN을 gsql `\connect`로 변환. Oracle REM/REMARK·PROMPT·SQL*Plus 전용 SET은 `--` 주석으로 자동 변환. 실제 SQL SET은 유지 |

DBMS_OUTPUT 호출이 생성되면 대상 DB에 해당 표준 패키지가 준비되어 있어야 합니다. 변환기는 패키지를 설치하지 않습니다. 변환 초안에서 주석·문자열·인용 식별자를 보존하며 사용자 루틴을 이름만 보고 내장 함수로 치환하지 않습니다.

### Oracle 19c 파일 변환

`oracle-demo.ini`는 Oracle 입력용 설정 예제입니다. `[common] base=oracle`, `source_version=19c`, `input`, `output`을 지정하여 실행합니다. `method=file`은 Oracle·GOLDILOCKS 접속이나 문서 파일 없이 수행됩니다. `[oracle]` 접속정보는 예약 설정이며 자동 DB 검증을 켜는 항목이 아닙니다.

```sh
sh run.sh --config oracle-demo.ini
sh run.sh review --config oracle-demo.ini
```

Oracle INTEGER/INT/SMALLINT는 NUMBER(38,0), RAW(n)은 VARBINARY(n), LONG은 LONG VARCHAR, LONG RAW는 LONG VARBINARY로 변환합니다. PLS_INTEGER/BINARY_INTEGER는 NATIVE_INTEGER로 변환하고 Oracle FLOAT의 이진 정밀도는 유지합니다. NCHAR/NVARCHAR2는 CHAR/VARCHAR의 CHARACTERS 길이로 자동 변환하며 확정된 타입 변경은 추가 검토에서 제외합니다. 길이 없는 NVARCHAR2의 기본 초안은 VARCHAR(2000 CHARACTERS)입니다. BFILE·객체 TYPE·정밀도 범위 초과 등의 미확정 항목은 개별 사유를 확인하십시오. 소스 내장 함수·패키지는 내장 목록으로 구분하며 목록에 있다는 이유만으로 대상 지원을 승인하지 않습니다.

Oracle STORAGE는 `rule.oracle_storage`로 변환합니다. INITIAL/NEXT의 K·M·G·T 단위를 바이트로 정규화하고, PCTINCREASE=0이면 `MAXSIZE = INITIAL + NEXT × (MAXEXTENTS − 1)`로 환산합니다. 결과가 32TB를 넘거나 MAXEXTENTS가 UNLIMITED이면 `MAXSIZE 35184372088832`로 제한합니다. MAXEXTENTS=1은 INITIAL만 사용합니다. 테이블과 인덱스 모두 적용합니다. 필요한 값이 없거나 PCTINCREASE가 0이 아니면 MAXSIZE 환산을 보류하고 이유를 검토 대상으로 남깁니다. MAXEXTENTS가 없으면 MAXSIZE를 추가하지 않습니다.

예: `INITIAL 64K NEXT 1M MAXEXTENTS 3 PCTINCREASE 0` → `STORAGE(INITIAL 65536 NEXT 1048576 MAXSIZE 2162688)`. MINEXTENTS·캐시·freelist 등 별도 미확정 속성의 검토 정책은 유지됩니다.

### Oracle 조건식과 사용자 오류 발생 API

PSM·조회문의 BETWEEN/NOT BETWEEN, IN/NOT IN 목록, NOT LIKE 조건을 공통 AST로 검사합니다. BETWEEN 내부의 AND와 외부 논리 AND/OR를 구분하며 지원 구문은 원문을 유지합니다.

`rule.raise_application_error`는 Oracle 단독 내장 호출을 `DBMS_STANDARD.RAISE_APPLICATION_ERROR`로 자동 변환합니다. 기본 action=AUTO_CONVERT, scope=psm_statement, review=false입니다. 이미 패키지명이 있는 호출과 입력에 선언된 동일 이름의 사용자 루틴은 재작성하지 않습니다. 인자는 2~3개이며 오류 코드·메시지·선택적 BOOLEAN 인자를 검사합니다. 숫자 리터럴 오류 코드가 -20999..-20000 범위 밖이면 대응을 결정해야 하므로 수동 검토에 남깁니다.

현재 테스트 DB에서는 단독 이름이 unknown routine name으로 실패하고 패키지명을 지정한 호출은 표준 패키지를 준비한 테스트 스키마에서 VALID로 생성되는 것을 확인했습니다. 대상 DB에는 표준 DBMS_STANDARD 패키지가 준비되어 있어야 하며 변환기는 패키지를 설치하지 않습니다. 개발용 실제 생성 테스트는 해당 패키지를 임시 테스트 스키마에만 준비하고 정리하며, 전역 BUILTIN_PACKAGE_SCHEMA를 변경하지 않습니다. 패키지 준비 여부는 구문 미지원과 구분합니다.

### 뷰·IOT의 자동 제거와 검토 분류

`rule.view_read_only`의 기본 동작은 REMOVE, scope는 view_option, review=false입니다. AST로 인식한 뷰 끝의 WITH READ ONLY와 선택적인 CONSTRAINT 이름을 제거하고 조회문과 주석을 보존합니다. 문자열 안의 같은 글자는 바꾸지 않습니다. GOLDILOCKS 26c CREATE VIEW에는 해당 절이 없으며, 현재 개발 DB에서 일반 뷰의 INSERT·UPDATE·DELETE가 거부되는 것을 확인했습니다. WITH CHECK OPTION 등 다른 절에는 이 제거 규칙을 적용하지 않습니다.

`rule.oracle_iot`의 기본 동작은 REMOVE, scope는 table_option, review=true입니다. ORGANIZATION INDEX를 제거하여 일반 CLONED 테이블 초안을 만들고 기존 PK 규칙을 적용합니다. NOCOMPRESS는 기존 압축 제거 규칙으로 제거합니다. IOT 구조 변경은 자동 변환 후 **추가 확인(CONFIRM)** 으로 표시하며, 직접 수정해야 하는 **수동 검토(MANUAL)** 로 분류하지 않습니다. 인식하지 못한 IOT 세부 옵션은 임의로 지우지 않습니다. 자동 규칙이 정해진 항목은 규칙대로 처리하고, 미확정 규칙으로 사용자가 직접 수정해야 하는 항목만 수동 검토에 남깁니다.

### 트리거: Altibase·Oracle → GOLDILOCKS 26c

두 경로 모두 공통 ANTLR 헤더와 SQL/PSM 본문 AST로 검사합니다. BEFORE/AFTER, INSERT/UPDATE/DELETE 및 OR 조합, UPDATE OF, FOR EACH ROW/STATEMENT, OLD/NEW 행 별칭, WHEN 조건과 선언·본문을 인식합니다. 실행 단위를 생략하면 문장 트리거입니다.

- Altibase: 본문 앞 AS를 제거합니다(`rule.trigger_body_as`). 지역변수 선언이 바로 이어지면 DECLARE를 추가합니다(`rule.trigger_declare`). 행 별칭과 본문은 보존합니다.
- Oracle: `:NEW`, `:OLD` 및 명시한 행 별칭의 콜론을 제거합니다. 암시적 별칭은 REFERENCING 절과 WHEN·본문에서 동일한 이름으로 변환합니다(`rule.oracle_trigger`). 생성 별칭은 입력 식별자와 충돌하지 않게 선택합니다.
- INSTEAD OF, COMPOUND, 헤더·본문 분석 실패 등은 해당 구문 위치와 사유를 검토 대상으로 표시합니다. 모든 트리거를 일괄 호환 처리하지 않습니다.

오프라인 회귀 입력은 `test/source/altibase-trigger/`, `test/source/oracle-trigger/`에 각각 9개이며 `sh test/check.sh`에 포함됩니다. 개발 DB가 실행 중이면 `python3 test/trigger/live_matrix.py`로 실제 Altibase 생성·aexport와 Oracle 생성·DBMS_METADATA 추출물의 변환 및 GOLDILOCKS VALID 상태를 검사할 수 있습니다. 결과 경로는 `test/results/latest-trigger-matrix.txt`에 기록됩니다. 이 생성 검증은 DML을 수행하거나 트리거 본문 로직을 실행하지 않습니다.

### 6.4 차단과 검토

독립된 최상위 DROP/TRUNCATE SQL은 실행되지 않도록 주석 처리합니다. 프로시저·함수·패키지 내부에 DDL이 있다는 이유로 객체 전체를 차단하지 않습니다. 고정 SQL은 지원 범위에서 변환하며 불명확한 동적 SQL은 검토합니다. 문자열·구문 손상이나 미인식 접속 명령은 별도 차단·검토 사유가 될 수 있습니다.

```text
1. DROP TABLE old_table;
   - 주석 사유: 최상위 DROP 문 실행 차단
```

자동 제거하면서도 검토를 유지하는 항목이 있습니다. MAXROWS·PARALLEL·CONSTANT 등이 이에 해당합니다. 해당 절을 원문 그대로 두라는 의미가 아니라, 변경 사실과 영향 여부를 사용자가 확인하라는 의미입니다.

<a id="outputs"></a>
## 7. 결과 파일

`output=target`이면 다음 위치에 결과를 생성합니다.

```text
target/
  converted/                 변환 SQL. 원본 디렉터리 구조 유지
    tables.sql
    routines/procedures.sql
  reports/
    report.html              오프라인 HTML 보고서
    report.xlsx              Excel 보고서
  review/
    index.txt                검토 대상의 원본 파일·행·사유와 상세 경로
    README.txt
    tables.sql.review.txt    파일별 검토 상세
  changes.json               전체 분석·변환 내역과 실행 설정
```

`convert=false`이면 변환 SQL을 만들지 않습니다. 보고서 형식은 `report` 설정을 따릅니다.

각 객체는 **원본 SQL을 주석으로 먼저 보존하고 그 다음에 변환 SQL을 배치**합니다. 부분 변환·변환 불가 객체는 명확한 주석과 별도 검토 파일 참조를 남깁니다. 모르는 SQL을 조용히 삭제하지 않습니다. SQL에 있는 `CONVERTED-BEGIN length=...` 등은 출력 구간 식별용 주석이며 DB 명령이 아닙니다.

같은 output으로 재실행하면 정상 저장 시 기존 결과를 교체합니다. 실패하면 이전 결과를 보존하도록 처리합니다. TUI는 S로 저장할 때 반영합니다. 보존할 변환 파일이 있으면 별도로 복사하거나 새로운 output을 사용하십시오. HTML에서 다운로드한 파일은 output 디렉터리의 파일을 자동 갱신하지 않습니다.

<a id="tui"></a>
## 8. 터미널 검토 화면

### 8.1 실행과 기본 흐름

```sh
sh run.sh review --config migrate.ini
```

INI 기본 규칙을 먼저 적용하고 남은 검토 항목을 묶어서 표시합니다. 같은 규칙·같은 원본 조각을 기준으로 묶으며 문법 판단 항목, 일반 확인 안내와 발생 빈도를 고려해 배치합니다. 화면 높이에 맞춰 목록 개수를 조정합니다. 최소 크기는 24열×12행이며, 실무에서는 좌우 SQL이 보이도록 넓은 터미널을 권장합니다.

다음은 화면 구성 예시입니다. 파일명·건수·설명은 실제 입력에 따라 달라집니다.

```text
----------------------------------------------------------------------------
SOURCE: /work/source  | TABLE 2, PROCEDURE 1
----------------------------------------------------------------------------
TARGET: /work/target  | 변환 2, ambiguous 1
----------------------------------------------------------------------------
사용자 확인
> 1. CREATE_TABLE_MAXROWS_REVIEW | MAXROWS  [1건]
  2. PSM_CONSTANT_REVIEW        | CONSTANT [1건]
----------------------------------------------------------------------------
↑↓ 선택  Enter 상세  S 저장  Q 취소
```

### 8.2 SQL 상세 화면 예시

```text
검토 발생 1/3 | tables.sql:8 | TABLE D_MAXROWS
MAXROWS 미지원: 설정에 따라 제거
* SOURCE                               |   TARGET
---------------------------------------+-------------------------------------
  CREATE TABLE D_MAXROWS (              | CREATE TABLE D_MAXROWS (
      ID INTEGER FIXED                  |     ID INT
  )                                    | )
> MAXROWS 1000                         | CLONED AT CLUSTER WIDE
  TABLESPACE OLD_TBS;                   | TABLESPACE MEM_DATA_TBS;
---------------------------------------+-------------------------------------
Tab 영역  방향키 스크롤  PgUp/PgDn 이전·다음 발생  B 목록
```

SOURCE는 원본 파일 행 번호, TARGET은 해당 변환 초안의 행 번호를 표시합니다. 검토할 구문을 해당 위치에서 강조합니다. 강조는 터미널 기본 글자색·배경색 반전과 `>` 기호를 사용합니다. 절이 삭제된 경우 대상에 동일한 줄이 없을 수 있습니다.

### 8.3 키 조작

| 화면·키 | 동작 |
|---|---|
| 목록 ↑↓ 또는 J/K | 항목 선택 |
| 목록 Enter | 해당 항목의 객체 전체 SQL을 좌우로 표시 |
| 상세 Tab | SOURCE/TARGET 활성 영역 전환 |
| 상세 ↑↓ 또는 J/K | 활성 SQL 영역 세로 스크롤 |
| 상세 ←→ | 활성 SQL 영역 가로 스크롤 |
| 상세 PgUp / PgDn | 같은 묶음의 이전/다음 발생 위치로 이동. 예: 1/13→2/13. 확인·수정 처리 없이 이동 |
| 상세 B | 목록으로 돌아감 |
| 상세 Enter | 원본 조각→대상 조각 입력. 대상 빈 값은 제거, `:q`는 입력 취소 |
| 적용 범위 `1` | 현재 발생 위치 하나만 적용 |
| 적용 범위 `A` | 같은 규칙·같은 원본 조각의 현재 미해결 위치 전체에 적용 |
| 상세 E | 객체 전체 대상 SQL을 여러 줄로 수정. 한 줄에 `.`를 입력하면 완료. `/` 종료자는 입력하지 않음 |
| 상세 C | 현재 초안을 내용 변경 없이 사용자 확인 완료 처리. `1`/`A`로 범위 선택 |
| S | 변환 SQL·보고서·검토 파일·사용자 규칙 저장 후 종료 |
| Q | 현재 세션의 미저장 선택을 버리고 종료 |

방향키는 **내용 스크롤**, PgUp/PgDn은 **발생 항목 이동**입니다. 좌우 SQL 영역은 터미널 크기에 맞는 고정 영역 안에서 각각 스크롤됩니다. 창 크기를 바꾼 후 키를 누르면 크기를 반영합니다.

`E` 수정은 해당 객체의 검토 항목을 사용자 처리 완료로 표시합니다. `C` 역시 사용자 확인이며 DB 실행 성공 판정이 아닙니다. 같은 글자가 주석·문자열에 있다는 이유로 전체 파일에서 단순 치환하지 않습니다. 사용자 수정 후 차단 조건을 다시 검사하며, 차단 객체는 일반 수정 목록에서 제외될 수 있습니다.

### 8.4 TUI 사용자 규칙 저장

기본 사용자 규칙 경로는 `<INI 파일명>.rules`입니다. 예를 들어 `migrator.ini`를 지정하면 `migrator.ini.rules`가 기본입니다. `[migration-rule] review_rules`를 지정하면 그 경로가 우선합니다. 배포 INI 예제에는 `migrate.ini.rules`가 명시돼 있습니다.

단일 위치 결정은 원본 상대 경로·SHA-256·위치가 같을 때만 재적용합니다. 전체 결정은 같은 문제 유형·원본 토큰 조각에 적용합니다. 저장한 규칙은 다음 TUI 실행과 일반 일괄 변환에도 적용됩니다. 현장에 전달할 때 필요하면 INI와 `.rules`를 함께 전달합니다. 결정을 취소하려면 규칙 파일을 수정 전 상태로 복원합니다.

<a id="html-report"></a>
## 9. HTML 보고서

### 9.1 열기와 화면 구성

생성한 `target/reports/report.html`을 브라우저에서 엽니다. 단일 HTML에 화면·데이터·스크립트가 포함되어 있어 인터넷과 웹서버가 필요 없습니다. 보고서에서 참조하는 외부 매뉴얼 원문 자체는 포함하지 않으므로 외부 링크를 여는 경우에는 별도 접근 환경이 필요합니다.

```text
SQL 호환성·변환 보고서
[변환 SQL 전체 저장(.sql)] [요약] [전체 객체] [유형별 상세] [참조 문서]

전체 객체 / 자동 처리 완료 (37%) / 수동 검토 필요 (25%) / 차단 / 추가 확인 필요 (38%) / DB 검증 여부
실행 시작 일시 / 완료 일시 / 실제 경과 초

검색 [객체명]  상태 [전체]  유형 [전체]  원본 파일 [전체]  규칙 [전체]
객체 목록: 객체명 | 객체 유형 | 원본 파일 | 상태 | 문제 유형·규칙

유형별 집계: TABLE / INDEX / PROCEDURE / FUNCTION / PACKAGE ...

객체 상세
[원본 SQL 전체]                  [변환 SQL 전체 · 수정/저장]
----------------------------------------------------------
분류 | 원본 위치 | 규칙 | 적용 여부 | 사유·권장 조치·참조
```

### 9.2 요약·필터·객체 상세

대시보드의 자동 처리 완료·수동 검토 필요·추가 확인 필요 세 항목은 제목 옆에 전체 객체 대비 비율을 표시합니다. 예: `자동 처리 완료 (37%)`. 백분율은 정수 반올림이며 전체 객체가 0개이면 0%입니다. 객체 수와 판정 기준은 바꾸지 않습니다. 차단 등 나머지 항목에는 비율을 붙이지 않습니다.

1. 상단에서 객체 수, 정적 분석 판정, DB 실행 미검증 표시와 실행 시간을 확인합니다.
2. 전체 객체 목록에서 상태·객체 유형·원본 파일·규칙 코드 필터와 객체명 검색을 함께 사용합니다. 검토·차단 객체를 위한 별도 중복 목록은 없습니다.
3. 기본 정렬은 검토 우선입니다. 객체명 오름/내림차순·유형·파일 정렬과 25/50/100개 페이지 크기를 선택할 수 있습니다. 전체 개수와 필터 결과·현재 표시 범위를 구분해 표시합니다.
4. 객체명을 누르면 해당 객체의 상세를 엽니다. 유형별 집계에서 유형명을 누르면 같은 유형끼리 이어진 상세 목록의 시작으로 이동합니다. 유형별 상세에는 필터와 무관하게 전체 객체를 보존합니다.
5. 객체 상세에는 상태·핵심 문제·권장 조치·원본 파일·행·SHA-256·DB 검증 여부가 있습니다.
6. 왼쪽에는 원본 SQL 전체, 오른쪽에는 변환 SQL 전체, 하단에는 자동 변환·수동 검토·추가 확인·호환 유지 내역을 표로 표시합니다. 좁은 화면에서는 SQL을 위아래로 배치합니다.
7. 표 행을 선택하면 관련 SQL 줄을 강조합니다. 같은 규칙 설명과 참조 주소는 묶어 표시하며, 발생 위치·적용 여부는 각각 유지합니다. 치환 조각·진단 전문은 보조 정보로 펼쳐 볼 수 있습니다.

### 9.3 개별 SQL 수정·저장·일괄 다운로드

1. 객체 상세 오른쪽의 **변환 SQL 수정**을 누릅니다.
2. 해당 객체의 SQL 전체를 직접 수정합니다. 원본 SQL은 읽기 전용입니다.
3. **저장 · 일괄 다운로드에 반영**을 누릅니다.
4. 다른 객체도 같은 방식으로 수정·저장합니다.
5. 상단 **변환 SQL 전체 저장(.sql)**을 누르면 모든 객체의 저장된 수정 사항을 반영한 SQL 한 파일을 다운로드합니다.

취소는 해당 편집 중 초안을 버립니다. **원래 변환으로 되돌리기**는 해당 객체의 저장된 수동 수정만 되돌립니다. 저장하지 않은 편집이 남아 있으면 저장 또는 취소한 후 일괄 다운로드합니다.

다운로드는 UTF-8이며 원래 변환 파일 순서를 유지하고 파일명 구분 주석을 넣습니다. 원본 SQL 주석·차단 주석도 포함합니다. 수정한 객체에는 `USER-EDITED`와 저장 일시를 기록합니다. 편집이 있으면 기본 파일명은 `converted-edited.sql`, 없으면 `converted.sql`입니다. 분석 전용 실행에는 SQL 편집·다운로드를 제공하지 않습니다.

**HTML의 저장은 현재 화면 메모리에만 보관합니다. 새로고침·창 종료 전에 다운로드하십시오.** 서버의 원본·변환 SQL·HTML 파일을 덮어쓰거나 TUI `.rules`를 생성하는 동작이 아닙니다.

수동 수정 후에도 기존 분석 결과와 집계는 바꾸지 않습니다. `사용자 수정 · 재분석/DB 실행 미검증`을 별도로 표시하고, 수정본에 기존 하이라이트 위치를 그대로 적용하지 않습니다. HTML 안에서 Java 변환 엔진이나 DB를 다시 실행하지 않습니다. 따라서 문법 오류나 최상위 위험 SQL을 수동으로 넣어도 브라우저가 새로 검사해 주는 것은 아닙니다.

<a id="counts"></a>
## 10. Excel·JSON과 집계 기준

### 10.1 객체 수와 규칙 건수

객체 유형별 표의 원본 수는 SQL에서 인식한 원본 객체 정의 수입니다. 참조한 테이블이나 자동 생성한 보조 인덱스를 원본 객체로 다시 세지 않습니다. PACKAGE와 PACKAGE_BODY, TYPE과 TYPE_BODY는 별도로 셉니다. 빈 파일·주석만 있는 파일은 객체를 만들지 않습니다. CLIENT_COMMAND는 CONNECT 등 클라이언트 명령이며 SQL은 일반 SQL·스크립트 구문입니다.

```text
객체 유형      | 원본 객체 수 | 자동 처리 완료 | 검토 대상 | 변환 대기
---------------+--------------+----------------+-----------+----------
TABLE          |            3 |              2 |         1 |         0
FUNCTION       |            2 |              1 |         1 |         0
TOTAL          |            5 |              3 |         2 |         0
```

각 행은 `원본 = 자동 처리 완료 + 검토 대상 + 변환 대기`입니다. 하나의 객체에 여러 규칙이 적용되거나 여러 검토 사유가 있어도 객체 수는 한 번만 셉니다.

| HTML 대시보드 항목 | 기준 |
|---|---|
| 자동 처리 완료 | 변환 실행이며 AUTO_AVAILABLE 또는 COMPATIBLE_IN_SCOPE |
| 변환 대기 | 분석 전용 실행이며 자동 처리 가능한 상태 |
| 변환 차단 | 엔진의 blocked=true |
| 수동 검토 필요 | 차단이 아니고 미해결 MANUAL 규칙 있음 |
| 추가 확인 필요 | 위에 속하지 않고 미해결 CONFIRM 규칙 있음 |
| 기타 검토 필요 | 위에 속하지 않는 나머지 검토 상태. 발생 시 표시 |

MANUAL과 CONFIRM이 함께 있으면 수동 검토로 한 번 집계합니다. 유형별 표의 검토 대상은 차단·수동·추가 확인·기타 검토를 합친 값입니다. 각 범주의 합은 전체 객체 수와 같습니다.

규칙 집계의 `compatible`, `autoAvailable`, `manual`, `confirm`, `applied`는 객체 수가 아닌 검출·적용 건수입니다. `files`, `objects`, `blocked`는 파일 수·원본 객체 수·차단 객체 수입니다. SQL 한 개에 여러 규칙이 있으므로 이 숫자를 객체 집계와 직접 더하거나 비교하지 않습니다.

### 10.2 Excel과 JSON

Excel은 Summary, Objects, Findings, Changes 시트로 전체 집계·객체·규칙·치환 내역을 제공합니다. 긴 셀은 Excel 제한에 맞춰 잘림을 표시하며, 전체 내용은 HTML·JSON에서 확인합니다. SQL 문자열은 수식이 아닌 텍스트로 기록합니다.

`changes.json`에는 객체·규칙·위치·변환 전후 조각·적용·사용자 확인·참조·설정과 실행 정보를 보존합니다. 이전 형식 호환용 minHours/maxHours 값이 남아 있을 수 있으나 사용자 화면·CLI·Excel의 예상 검토 공수로 사용하지 않습니다.

보고서의 DB 실행 상태는 현재 **미검증**입니다. 개발 중 따로 수행한 DB 테스트 결과를 해당 입력의 실행 결과로 가져와 표시하지 않습니다.

<a id="database-verification"></a>
## 11. 대상 DB에서 별도 검증

파일 변환이 끝나도 DB에 자동 실행하지 않습니다. 실제 실행이 필요하면 대상 DB·계정·테이블스페이스·패키지를 준비한 뒤 변환 SQL을 검토하여 gsql 등으로 수행합니다.

```sh
# GOLDILOCKS가 기동돼 있고 gsql이 설치된 별도 검증 환경
# 실제 환경의 계정·비밀번호·파일 경로로 대체
gsql TARGET_USER TARGET_PASSWORD --import target/converted/tables.sql
```

파일 간 생성 순서·계정·대상 객체 준비는 실행 환경에 맞춰 조정합니다. 원본 CONNECT가 변환된 `\connect`는 해당 계정으로 연결을 바꾸므로 대상 계정도 준비되어 있어야 합니다. 일괄 다운로드는 파일 순서를 유지하며 의존성 순서로 재정렬하는 기능이 아닙니다.

현재 검증 기준은 **객체 생성 성공**입니다. 루틴을 실제 호출해 업무 로직·반환값·성능까지 동등한지 확인하는 검증은 별도입니다. gsql은 SQL 오류가 있어도 프로세스 종료 코드가 0일 수 있으므로 출력 오류와 객체 상태도 확인합니다.

<a id="troubleshooting"></a>
## 12. 문제 해결

| 증상 | 확인·조치 |
|---|---|
| Java 실행 불가 | `java -version`, JAVA_HOME 경로와 JRE 1.8 이상 여부 확인 |
| JAR를 찾지 못함 | 배포본의 run.sh와 sqlmigrate.jar가 함께 있는지 확인. 개발본은 src/build/sqlmigrate.jar를 먼저 빌드 |
| 입력 파일이 0개 | INI 기준 input 절대 경로, .sql 확장자, 읽기 권한 확인 |
| 경로 오류·심볼릭 링크 오류 | input/output 분리, 실제 디렉터리 사용, 출력 쓰기 권한 확인 |
| direct 미구현 오류 | `[common] method=file` 사용 |
| 설정을 수정해도 변화 없음 | `--config`로 지정한 파일, CLI 우선 옵션, `[rule.*]` 우선 설정, 기존 `.rules` 적용 여부 확인 |
| 인코딩 오류·한글 문제 | 원본 인코딩에 맞춰 encoding 수정. 기존 문자를 임의로 대체하지 않음 |
| STORAGE_EXTENT_REQUIRED | rule.storage의 source_extent_bytes를 실제 원본 값으로 지정 |
| 메모리/디스크 배치 검토 | rule.tablespace의 mem_tbs/disk_tbs 설정 |
| 어떤 SQL을 검토할지 모름 | review/index.txt 또는 HTML 상태 필터·객체 상세의 구체적 사유 확인 |
| 수정했는데 검토가 남음 | 같은 객체에 다른 미해결 사유가 있는지 확인 |
| HTML 편집이 사라짐 | 현재 화면 메모리 저장이므로 새로고침 전 일괄 다운로드 필요 |
| TUI가 좁거나 키가 동작하지 않음 | 실제 터미널·stty 확인, 화면 크기 확대. 상세 방향키는 스크롤, PgUp/PgDn은 발생 항목 이동 |
| CLI는 성공했는데 SQL 생성 오류 | 종료 0은 보고서 생성 성공. 대상 DB 지원·검토 사유·계정·객체 준비·gsql 오류 확인 |

<a id="development"></a>
## 13. 개발 환경의 빌드·테스트·배포

현장 실행과 달리 빌드에는 JDK 8 이상, 개발 회귀 테스트에는 Python 3, 배포 생성에는 tar·sha256sum이 필요합니다. Node.js·Firefox는 일부 HTML 개발 검증에만 사용합니다. ANTLR 런타임·도구와 생성 Java 소스는 저장소에 포함하며 Maven·인터넷 다운로드 없이 빌드합니다.

프로젝트 루트에서:

```sh
sh src/build.sh
TEST_JAVA_HOME=/path/to/jre8 sh test/check.sh
sh src/package.sh
# 빌드된 JAR를 재포장할 때
sh src/package.sh --skip-build
# 압축 해제 후 실행·매뉴얼 포함 확인
sh test/package-smoke.sh
```

결과는 `src/dist/sqlmigrate-<버전>-linux.tar.gz`와 `.sha256`입니다. 패키지에는 실행 JAR·스크립트·예제 설정·이 통합 사용자 매뉴얼·라이선스를 포함합니다. 현장 입력 SQL·사용자 `.rules`·실제 접속정보·테스트 결과·개발용 참고 매뉴얼은 넣지 않습니다.

개발용 `src/docs/reference/`는 참고 자료이며 제품 실행에 필요하지 않습니다. 빌드 JAR·배포 압축·test/results·test/target·test/build·임시 작업·캐시는 SVN 추적에서 제외합니다. 회귀 입력과 `test/source/altibase-manual-aexport-1792456659/` 원본은 보존합니다.

### Oracle 공식 샘플 스키마 테스트

공식 `oracle-samples/db-sample-schemas`의 HR·CO·SH 생성 SQL과 커밋·해시는 `test/source/oracle-official-samples/`에 보존합니다. 개발용 `python3 test/oracle-samples/run.py`는 Oracle TEST 계정에서 고유 접두어를 붙인 객체를 생성·추출하고 GOLDILOCKS의 임시 스키마에 변환 DDL을 실행한 뒤 해당 객체만 정리합니다. 실제 설치 스크립트와 데이터 적재는 실행하지 않습니다. 결과 시작 화면은 `test/target/oracle-official-samples/index.html`, 스키마별 정적 보고서는 `<hr|co|sh>/reports/report.html`, 실제 생성 결과·오류는 각 폴더의 `db-validation.json`입니다. SQL 파일 수와 DB 객체 수는 서로 다른 단위입니다.

공식 샘플의 고정 추출물 HR 42개·CO 27개·SH 22개와 기존 Oracle19c 140개, 총 231개 SQL 파일은 `sh test/check.sh`의 오프라인 회귀 테스트에 포함됩니다. `test/oracle-samples/test_regression.py`는 `baseline.json`과 변환 SQL 해시·객체 집계·상태·규칙 판정·원본 해시를 비교합니다. 고정 기준은 정적 변환 동작을 검증하며 DB 생성 성공을 의미하지 않습니다. 테스트 JVM의 CPU 수를 8로 고정하여 MAXTRANS 결과를 일정하게 비교합니다. Java8 개발 테스트 실행 시 ActiveProcessorCount 옵션을 지원하는 업데이트 버전을 사용합니다. 공식 원본과 라이선스·커밋·SHA-256도 보존합니다.

DB가 필요한 `test/oracle-samples/run.py`는 선택 실행입니다. 재실행의 추출물은 해당 `test/results/oracle-official-samples-*/<hr|co|sh>/exported/`에 생성하며, 고정된 `test/source/oracle-official-samples/exported/` 회귀 원본을 덮어쓰지 않습니다. 일반 `test/check.sh`는 이 DB 접속 스크립트를 실행하지 않습니다. GOLDILOCKS만 실행 중인 경우 `python3 test/oracle-samples/target.py`로 고정 추출물의 대상 생성 시험과 세 보고서를 다시 만들 수 있습니다.

### Oracle 19c 문법 참고 자료 수집

Oracle 작업의 문법 기준 자료는 `src/docs/reference/oracle-19c/`에 보관합니다. SQL Language Reference와 PL/SQL Language Reference의 목차 연결 본문 및 구문 도표의 텍스트 설명 2,472페이지를 수집했습니다. `sqlrf/`는 SQL, `lnpls/`는 PL/SQL이며, 각 원본 HTML과 검색용 `.html.txt` 또는 `.htm.txt`를 함께 보관합니다.

`manifest.json`에는 원본·최종 URL, 수집 일시, 문서 제목, HTML·텍스트 해시와 수집 실패를 기록합니다. SQL Reference의 색인 `book-index.html` 1건은 공식 링크가 HTTP 404여서 실패로 남겼습니다. CSS·JavaScript·도표 이미지를 포함하는 전체 웹사이트 복제본은 아니며, 문법 텍스트를 개발 검토에 사용합니다.

이 자료 수집만으로 Oracle 변환 규칙이나 호환 판정을 확대하지 않습니다. Oracle 19c 문서 개정 내용과 개별 Release Update 차이, 9i 이후 구버전과의 차이는 변환 구현·테스트 시 따로 확인합니다. 개발 참고 자료는 현장 실행에서 읽지 않고 배포 압축파일에도 포함하지 않습니다.

<a id="full-ini"></a>
## 14. 전체 INI 예제

기본 Altibase 파일 변환 설정입니다. Oracle은 base와 source_version, input·output을 함께 변경합니다.

```ini
# 파일 기반 변환/터미널 검토용 전체 설정. 상대 경로는 이 INI 위치 기준.
[common]
method = file
base = altibase
target = goldilocks
source_version = 7.3
target_version = 26c.1
input = ../altibase
output = ../test/target/review-demo
convert = true
report = html,xlsx
encoding = UTF-8

# direct는 예약된 방식이며 현재는 file만 수행. file 모드에서는 접속하지 않음.
[altibase]
ip = 127.0.0.1
port = 20300
user = sys
pwd = CHANGE_ME

[goldilocks]
ip = 127.0.0.1
port = 22581
user = sys
pwd = CHANGE_ME

[migration-rule]
# TUI에서 저장하는 개별/전체 사용자 치환 규칙
review_rules = review-demo.ini.rules

# [rule.*]가 이전 [migration-rule]의 변환 항목보다 우선합니다.
# REVIEW/PRESERVE: 자동 수정 보류. scope는 규칙마다 고정.

# PARALLEL 절 제거
[rule.parallel]
action = REMOVE
scope = table_option
review = true

# INTEGER FIXED -> INT
[rule.integer_fixed]
action = AUTO_CONVERT
scope = data_type
review = false

# FIXED/VARIABLE/IN ROW 제거
[rule.column_storage]
action = REMOVE
scope = column_option
review = false

# COMPRESSED/UNCOMPRESSED 제거
[rule.compression]
action = REMOVE
scope = table_option
review = false

# LOGGING/NOLOGGING 제거
[rule.logging]
action = REMOVE
scope = table_option
review = false

# GOLDILOCKS 미지원 LOB (...) STORE AS (...) 절 전체 제거
[rule.lob_storage]
action = REMOVE
scope = table_option
review = false

# 파티션 절 제거
[rule.partition]
action = REMOVE
scope = table_option
review = false

# MAXTRANS=min(CPU,32)
[rule.maxtrans]
action = AUTO_CONVERT
scope = table_option
review = false
value = cpu_cores
cpu_cores = auto

# 원본 익스텐트 개수 -> 대상 바이트 단위
[rule.storage]
action = AUTO_CONVERT
scope = table_option
review = false
value = extent_bytes
# 이 예제 원본의 익스텐트는 512KiB. 현장 값으로 조정.
source_extent_bytes = 524288

# 일반 CHAR/VARCHAR 길이 단위
[rule.varchar_units]
action = AUTO_CONVERT
scope = data_type
review = false
value = octets

# NCHAR/NVARCHAR -> CHAR/VARCHAR CHARACTERS
[rule.national_character]
action = AUTO_CONVERT
scope = data_type
review = false
value = characters

# NIBBLE(n) -> VARBINARY(n)
[rule.nibble]
action = AUTO_CONVERT
scope = data_type
review = false
value = varbinary

# WITH LOCAL TIME ZONE -> WITH TIME ZONE
[rule.local_timezone]
action = AUTO_CONVERT
scope = data_type
review = false
value = with_timezone

# BYTE -> BINARY
[rule.byte]
action = AUTO_CONVERT
scope = data_type
review = false

# BLOB -> LONG VARBINARY
[rule.blob]
action = AUTO_CONVERT
scope = data_type
review = false

# CLOB -> LONG VARCHAR
[rule.clob]
action = AUTO_CONVERT
scope = data_type
review = false

# 지원되는 타입 별칭 정규화
[rule.type_alias]
action = AUTO_CONVERT
scope = data_type
review = false

# 테이블/인덱스 TABLESPACE 매핑
[rule.tablespace]
action = AUTO_CONVERT
scope = tablespace
review = false
data_tbs = MEM_DATA_TBS
mem_tbs = MEM_DATA_TBS
disk_tbs = MEM_DATA_TBS
index_tbs = MEM_TEMP_TBS
temp_tbs = MEM_TEMP_TBS

# 일반 테이블 CLONED
[rule.cluster]
action = AUTO_CONVERT
scope = table_distribution
review = false

# PK를 테이블 생성 후 ALTER TABLE ADD로 분리
[rule.primary_key]
action = AUTO_CONVERT
scope = constraint
review = false

# 원본 키/인덱스 이름 보존, 이름 임의 생성 금지
[rule.constraint_index]
action = AUTO_CONVERT
scope = constraint
review = false

# GLOBAL TEMPORARY, ON COMMIT 보존
[rule.temporary_table]
action = AUTO_CONVERT
scope = table_option
review = false

# 벤더 파일 예외 -> OTHERS 초안, 검토 유지
[rule.vendor_exception]
action = AUTO_CONVERT
scope = exception_handler
review = true
value = others_review

# CONNECT -> gsql connect
[rule.client_command]
action = AUTO_CONVERT
scope = client_command
review = false

# 미지원/미확인 기능 검토
[rule.unsupported_feature]
action = REVIEW
scope = any
review = true

# DROP/TRUNCATE 실행 차단, 비활성화 불가
[rule.destructive_sql]
action = BLOCK
scope = any
review = true

# Altibase 십진 FLOAT(p) → GOLDILOCKS 이진 FLOAT(min(126,ceil(p*log2(10))))
[rule.float_precision]
action = AUTO_CONVERT
scope = data_type

# 길이 없는 NVARCHAR -> VARCHAR(2000 CHARACTERS)
[rule.nvarchar_unspecified_length]
action = AUTO_CONVERT
scope = data_type
review = false

# associative array 원소 접근 [] -> ()
[rule.collection_subscript]
action = AUTO_CONVERT
scope = collection_expression
review = false

# DELETE()의 삭제 개수를 저장하고 associative array 전체를 비웁니다.
[rule.collection_delete_all]
action = AUTO_CONVERT
scope = collection_statement
review = false

# 입력에 정의된 객체 종류로 권한 대상 및 시퀀스 USAGE를 변환합니다.
[rule.privilege_object]
action = AUTO_CONVERT
scope = privilege
review = false

# CONSTANT는 제거하되 읽기 전용 제약 변경을 반드시 검토합니다.
[rule.constant]
action = REMOVE
scope = variable_declaration
review = true

# PRINT는 개행 없이 PUT, PRINTLN은 PUT_LINE으로 변환합니다.
[rule.print]
action = AUTO_CONVERT
scope = psm_statement
review = false

# 길이를 생략한 VARCHAR에 4000을 자동 적용하고 마지막 규칙 표에 기록합니다.
[rule.varchar_unspecified_length]
action = AUTO_CONVERT
scope = data_type
review = false

# PSM 내부 SQL 변환 및 정적 DDL의 EXECUTE IMMEDIATE 변환
[rule.dynamic_sql]
action = AUTO_CONVERT
scope = dynamic_sql
review = false

# MAXROWS 절은 초안에서 제거하고 검토 대상으로 유지
[rule.maxrows]
action = REMOVE
scope = table_option
review = true

[oracle]
ip = localhost
port = 1521
service_name = orclpdb1
user = test
pwd = CHANGE_ME

[rule.oracle_data_type]
action = AUTO_CONVERT
scope = data_type
review = false

[rule.oracle_national_character]
action = AUTO_CONVERT
scope = data_type
review = false

[rule.oracle_edition]
action = REMOVE
scope = object_option
review = true

[rule.oracle_sequence_options]
action = REMOVE
scope = sequence_option
review = true

[rule.oracle_trigger]
action = AUTO_CONVERT
scope = trigger
review = false

[rule.oracle_dynamic_bind]
action = AUTO_CONVERT
scope = dynamic_sql
review = false

[rule.oracle_string_literal]
action = AUTO_CONVERT
scope = literal
review = false

# MAXEXTENTS -> MAXSIZE: INITIAL + NEXT * (count - 1), capped at 32TB; PCTINCREASE=0.
[rule.oracle_storage]
action = AUTO_CONVERT
scope = table_option
review = true

[rule.oracle_segment_creation]
action = REMOVE
scope = table_option
review = true

[rule.oracle_collection_method]
action = AUTO_CONVERT
scope = collection_expression
review = false

[rule.trigger_body_as]
action = REMOVE
scope = trigger
review = false

[rule.trigger_declare]
action = AUTO_CONVERT
scope = trigger
review = false

# GOLDILOCKS CREATE VIEW does not accept WITH READ ONLY.
[rule.view_read_only]
action = REMOVE
scope = view_option
review = false

# IOT -> ordinary table draft; confirm the structure change.
[rule.oracle_iot]
action = REMOVE
scope = table_option
review = true

# Oracle standalone builtin -> verified DBMS_STANDARD entry point.
[rule.raise_application_error]
action = AUTO_CONVERT
scope = psm_statement
review = false
```


### Oracle 기존 인덱스와 PK/UNIQUE 제약조건

GOLDILOCKS 26c에서 `INDEX 이름`은 제약조건의 인덱스를 새로 생성하는 절입니다. 기존 인덱스를 재사용하는 Oracle의 `USING INDEX 이름`과 구분합니다. 확인한 26c 문법과 실행 결과에서는 기존 인덱스를 재사용하는 `USING INDEX` 구문을 지원하지 않습니다. 근거는 [26c ALTER TABLE ADD CONSTRAINT 문법](https://github.com/sunjesoft/goldilocks-manuals/blob/main/docs/goldilocks/26c.1/ko/part-03-sql-manual/18-sql-references-a-b.md)과 개발용 참조 사본 `reference/goldilocks-26c.1-sql-a-b.md`입니다.

입력 SQL에 `CREATE UNIQUE INDEX`와 이를 참조하는 PK/UNIQUE 생성문이 함께 있으면, 별도 인덱스 생성문은 주석 처리하고 제약조건에서 인덱스를 한 번만 생성합니다. 서로 다른 입력 파일에 있는 선언도 함께 검사합니다. 원본 제약조건명·인덱스명과 변환된 인덱스 물리 옵션을 유지하며 TABLESPACE는 `index_tbs` 규칙을 적용합니다.

```sql
-- 원본
CREATE UNIQUE INDEX DEPT_PK ON DEPT(ID) TABLESPACE USERS;
ALTER TABLE DEPT ADD CONSTRAINT DEPT_PK PRIMARY KEY(ID) USING INDEX DEPT_PK;

-- 변환: 별도 CREATE UNIQUE INDEX는 주석으로 보존
ALTER TABLE DEPT ADD CONSTRAINT DEPT_PK PRIMARY KEY(ID)
    INDEX DEPT_PK TABLESPACE MEM_TEMP_TBS;
```

인덱스가 UNIQUE인지, 대상 테이블과 키 컬럼이 같은지 확인한 경우에만 통합합니다. 선언을 찾지 못하거나 정의가 맞지 않거나 여러 제약조건이 같은 인덱스를 참조하면 검토 대상으로 남깁니다. 대상 DB에 이미 있는 인덱스를 자동 삭제하지 않습니다. 이전 실행으로 같은 이름의 인덱스가 남은 환경은 별도 정리 후 생성해야 합니다.

`[rule.constraint_index]`의 `action = PRESERVE`를 설정하면 원본 선언과 참조를 유지합니다. 기본 자동 변환은 기존 인덱스를 실행 중에 PK로 변경하는 동작이 아니라, 변환 파일에서 생성문을 통합하는 동작입니다.

### 시퀀스 MAXVALUE 상한

Altibase·Oracle 시퀀스의 명시적 `MAXVALUE`는 `min(원본값, 9223372036854775807)`로 변환합니다. 비교는 큰 정수로 수행하므로 원본이 64비트 범위를 넘어도 잘리지 않습니다. 원본이 상한 이하이면 그대로 유지합니다. `NOMAXVALUE`나 생략된 MAXVALUE에는 값을 추가하지 않습니다.

```ini
[rule.sequence_maxvalue]
action = AUTO_CONVERT
scope = sequence_option
review = false
```

예: `MAXVALUE 9999999999999999999999999999` → `MAXVALUE 9223372036854775807`. 변경 사항은 보고서의 `SEQUENCE_MAXVALUE_CAPPED` 규칙에 기록합니다. START WITH·MINVALUE·INCREMENT BY는 이 규칙으로 변경하지 않으며, 변환된 범위와 맞지 않으면 검토 대상으로 유지합니다. `action = PRESERVE`는 원본 MAXVALUE를 유지하고 기존 범위 검사를 수행합니다.

### Altibase BYTE·NIBBLE 기본값

컬럼 DEFAULT 표현식의 `BYTE'AABB'`는 `X'AABB'`로, `NIBBLE'ABC'`는 홀수 16진수 자리의 끝에 0을 추가하여 `X'ABC0'`로 자동 변환합니다. 짝수 자리 NIBBLE 값은 패딩하지 않습니다. NIBBLE 기본값은 검토 대상에서 제외하고 `ALTIBASE_NIBBLE_DEFAULT_LITERAL`로 기록합니다. BYTE 기본값은 `ALTIBASE_BINARY_DEFAULT_LITERAL`로 자동 변환하되 검토 대상으로 유지합니다. 주석과 일반 문자열은 보존합니다. 16진수가 아닌 값이나 홀수 자리 BYTE는 자동 변환하지 않고 검토 대상으로 유지합니다.

컬럼 자료형 길이 규칙은 별개입니다. `BYTE(8)`은 `BINARY(8)`, `NIBBLE(7)`은 길이 숫자를 유지하여 `VARBINARY(7)`로 변환합니다. 이 규칙은 컬럼 기본값에만 적용하며 데이터 적재 값의 변환 규칙을 추가하지 않습니다.

```ini
[rule.binary_default_literal]
action = AUTO_CONVERT
scope = default_expression
review = true
```

`rule.binary_default_literal`의 `action = PRESERVE`는 BYTE 기본값을 원문 유지합니다. NIBBLE 기본값 보존 여부는 `rule.nibble_default_literal`로 별도 지정합니다.

```ini

# NIBBLE 기본값은 자동 변환 후 검토에서 제외
[rule.nibble_default_literal]
action = AUTO_CONVERT
scope = default_expression
review = false

# FETCH BULK LIMIT 단건 반복 초안은 검토 유지
[rule.fetch_bulk_loop]
action = AUTO_CONVERT
scope = psm_statement
review = true

# FOR STEP 절 제거 후 수동검토
[rule.for_step]
action = REMOVE
scope = psm_statement
review = true
```

### FETCH BULK COLLECT LIMIT와 FOR STEP

`FETCH C BULK COLLECT INTO V_A LIMIT 10;`은 명시적 커서의 SELECT 컬럼 수와 INTO 컬렉션 수를 확인한 후, 최대 10회 단건 FETCH하는 로컬 DECLARE 블록으로 변환합니다. 원문 전체에서 문자열을 치환하지 않고 PSM AST에 기록된 해당 문장의 시작·끝 위치만 교체하므로 긴 본문·중첩 블록·패키지에서도 주변 SQL을 유지합니다. 임시 변수와 반복 인덱스는 원본 식별자와 충돌하지 않게 생성합니다.

기존 컬렉션 원소는 FIRST 키부터 삭제한 후 1부터 순서대로 채우며, 커서 %NOTFOUND이면 종료합니다. OPEN/CLOSE와 예외 처리기는 원래 위치를 유지합니다. 변환 초안은 `PSM_FETCH_BULK_LOOP_REVIEW`로 검토 대상으로 남깁니다. 일괄 FETCH에서 단건 반복으로 바뀌므로 성능과 이후 커서 속성 사용을 검토해야 합니다.

현재 자동 초안 범위는 명시적 커서, 양의 정수 상수 LIMIT, 정수 키 associative array의 스칼라 원소입니다. 여러 INTO 컬렉션도 SELECT 컬럼 수가 일치하면 처리합니다. LIMIT 생략·변수/표현식 LIMIT·REF CURSOR·레코드 컬렉션·불명확한 타입은 구체적 이유와 함께 원문을 유지하고 수동 검토합니다. 함수에서는 SELECT 기반 커서 FETCH만 이 규칙의 대체 대상으로 삼습니다. 함수의 INSERT·UPDATE·DELETE `RETURNING BULK COLLECT`는 SELECT 반복문으로 대체하지 않고 원문과 수동 검토를 유지합니다. 프로시저의 `RETURNING BULK COLLECT`도 이 FETCH 규칙에 포함하지 않습니다. GOLDILOCKS에서 `FOR rec IN (DELETE ... RETURNING ...)` 형태는 컴파일 오류로 확인되어 검토 대상으로 유지합니다.

`FOR ... STEP 값 LOOP`는 STEP 키워드와 증분 표현식을 함께 제거한 초안을 만들고 `PSM_STEP_REVIEW` 수동 검토로 표시합니다. 원본 증분 값과 반복 횟수·처리 범위를 확인해야 합니다. `[rule.for_step] action = PRESERVE`는 절을 유지하고 수동 검토합니다.

### VARCHAR 4000 초과 자동 변환

명시 길이가 4000을 초과하는 VARCHAR 및 Oracle VARCHAR2는 `LONG VARCHAR`로 자동 변환하고 이 타입 변환은 검토 대상에서 제외합니다. 테이블 컬럼, PSM 인자·반환형·지역변수·컬렉션 원소 선언에 동일하게 적용합니다. 예: `VARCHAR(5000 CHARACTERS)` → `LONG VARCHAR`. 원래 길이는 원본 SQL과 `VARCHAR_TO_LONG_VARCHAR` 변환 내역에 보존합니다. 4000 이하의 길이는 기존 규칙을 유지합니다.

GOLDILOCKS 26c의 LONG VARCHAR는 길이 절을 허용하지 않습니다. 테이블과 함수에서 `LONG VARCHAR(n)`은 실제 문법 오류로, 길이 없는 `LONG VARCHAR`는 생성 성공으로 확인했습니다. 최대 저장 크기는 100MB이며 원본의 길이·문자 단위 제약은 대상 타입 선언에 남지 않습니다. LONG VARCHAR의 인덱스·정렬 등 다른 사용 제약은 별도 구문 분석 결과와 실제 생성 결과를 확인합니다.

```ini
[rule.varchar_long]
action = AUTO_CONVERT
scope = data_type
review = false
```

### 원본 DB 버전과 문법 프로필

`base`는 `altibase`, `oracle`, `postgresql` 중 하나입니다. `source_version`을 지정하면 해당 major 버전의 빌드 내장 문법 프로필을 선택합니다. 버전을 생략하면 Altibase는 **A7(7.3)**, Oracle은 **ORA19(19c 계열)**, PostgreSQL은 **PG18**이 기본입니다. 예:

```ini
[common]
method = file
base = postgresql
source_version = 18
input = source
output = target
convert = true

[postgresql]
ip = 127.0.0.1
port = 5432
database = postgres
user = CHANGE_ME
pwd = CHANGE_ME
```

`source_version = A7`, `ORA19`, `PG18` 표기도 해당 DB 종류에서 사용할 수 있습니다. `profile = PG18`처럼 프로필을 직접 지정할 수도 있습니다. base·profile·source_version을 함께 지정하면 DB 종류와 major 버전이 일치해야 합니다. 지정 버전의 프로필이 빌드에 없으면 다른 버전으로 대체하지 않고 사용법 오류로 종료합니다. 파일 모드는 위 접속정보를 사용하지 않으며 DB 서버가 없어도 동작합니다. direct 모드는 계속 미구현입니다.

프로필은 JAR에 내장되며 설치 현장에 매뉴얼·프로필 폴더·네트워크·PostgreSQL이 필요하지 않습니다. 보고서에는 선택 프로필·원본 버전·파서 계열·검증 범위와 근거 링크를 기록합니다. 기존 A3와 Oracle 레거시 버전 프로필은 기존 공통 호환 범위를 보존하기 위한 것으로, 해당 버전 전용 문법 전체가 인증됐다는 의미가 아닙니다. 레거시 범위는 HTML에도 표시합니다.

개발 시 새 버전 매뉴얼을 받으면 `src/resources/dialects/`에 버전별 프로필을 추가합니다. `catalog.properties`에 등록하고, vendor·version·grammar·manual과 버전 차이에 따른 AST 타입 매핑(`type.NAME`)·기능 제한(`feature.OBJECT=REVIEW`, `feature.PSM.STATEMENT=REVIEW`)을 지정합니다. `inherits=A7` 등 공통 프로필 상속을 사용할 수 있으며 다른 DB 계열 상속·순환 상속은 허용하지 않습니다. 예컨대 A4 매뉴얼을 반영할 때는 A4 프로필과 회귀 케이스를 먼저 추가해 빌드합니다. 현재 A4 전용 프로필은 포함하지 않았으므로 source_version=4는 오류로 종료합니다. 새 문법 구조가 공통 AST에 없으면 해당 파서도 개발 시 보강해야 합니다. 매뉴얼을 실행 시 자동 해석하거나, 추가 매뉴얼 없이 미지원 버전을 지원으로 간주하지 않습니다.

### PostgreSQL 18 파일 변환

`sh run.sh --config postgresql-demo.ini`로 실행합니다. 예제 INI는 개발 트리 `src/postgresql-demo.ini`에 있습니다. source에는 SQL 파일 또는 `pg_dump --schema-only --no-owner --no-privileges` 추출물을 둡니다. 데이터 적재 파일·COPY FROM STDIN 데이터 스트림은 현재 초기 검증 범위가 아닙니다.

PostgreSQL 전용 Lexer는 dollar-quoted 본문, E 문자열, 중첩 주석, psql 제어 명령을 분리합니다. 테이블·타입·루틴 노드의 원본 위치를 유지하며 공통 ANTLR SQL/PSM 검증기와 기존 TABLESPACE·CLONED·PK 분리·안전 규칙을 재사용합니다. 대상 루틴에는 gsql 실행 구분자를 추가해 다음 객체를 삼키지 않게 합니다. 원본 SQL은 기존 방식대로 주석 보존합니다.

| 원본 | 변환·분류 |
| --- | --- |
| smallint/int2, integer/int4, bigint/int8 | NATIVE_SMALLINT, NATIVE_INTEGER, NATIVE_BIGINT |
| real/float4, double precision/float8 | NATIVE_REAL, NATIVE_DOUBLE |
| varchar(n), character varying(n) | VARCHAR(n CHARACTERS); 4000 초과는 LONG VARCHAR |
| text, bytea | LONG VARCHAR, LONG VARBINARY; 확정된 타입 변환은 추가 검토 제외 |
| timestamp/timestamptz, time/timetz | 시간대 지정이 명시된 대응 타입 |
| 명시 정밀도 numeric/decimal | 공통 정밀도·스케일 검사; 무제한 numeric 범위는 검토 |
| PARTITION BY RANGE/HASH/LIST, ATTACH/DETACH PARTITION | partition_rule=remove 기본 규칙으로 절 제거·연결문 주석 처리; 독립 테이블 초안과 변경 확인 항목 제공 |
| COMMENT ON TABLE/COLUMN 등 | TABLE/COLUMN은 유지; COMMENT ON VIEW는 COMMENT ON TABLE <뷰이름> IS ...로 변환 |
| 기본 BTREE 인덱스 | USING btree 제거, index_tbs 적용 |
| 시퀀스 AS 타입, CACHE 1 | AS 제거 후 64비트 검사; CACHE 1은 NOCACHE로 자동 변환·검토 제외 |
| nextval('schema.seq'::regclass) | 정적 이름만 schema.seq.NEXTVAL로 변환 |
| 단순 PL/pgSQL, 스칼라 LANGUAGE SQL 함수 | wrapper·인자 순서·선언 타입 변환 후 공통 PSM 검사 |
| pg_dump/psql 제어·세션·소유권 설정 | 확정된 timeout은 ALTER SESSION으로 변환. 미확정 세션 설정과 OWNER TO는 주석 처리·검토 제외. 시퀀스 OWNED BY는 별도 의존 관계 검토 |
| JSONB·배열·ENUM·UUID·확장 타입 | 임의 대응 타입을 정하지 않고 구체적 타입 사유로 검토 |
| GIN/GiST/BRIN, 부분·INCLUDE 인덱스 | 접근 방식·옵션별 검토 |
| 트리거 함수·EXECUTE FUNCTION, 집합 반환 | 본문 통합·반환 구조 규칙이 필요하여 검토 |

미지원 PostgreSQL 내장 함수는 PG18.6의 pg_catalog에서 취득해 JAR에 내장한 이름 목록으로 사용자 함수와 구분합니다. 내장 함수 이름이 존재한다는 이유만으로 GOLDILOCKS 지원을 승인하지 않습니다. 구체적인 신규 매핑은 해당 버전 프로필과 테스트로 보강합니다.

실제 DB 시험은 정적 판정과 별도입니다. 개발용 `test/postgresql18/live.py`는 `~/pg18/bin`으로 전용 임시 클러스터를 생성·삭제하고 추출 SQL을 변환합니다. 기존 `~/pg18/database`는 사용하지 않습니다. 대상 생성 시험은 전용 스키마에 객체 유형 순서를 적용하며 소스의 데이터와 루틴 본문은 실행하지 않습니다. 생성 순서와 DB 오류는 각 결과의 db-validation.json에 기록합니다. Oracle·Altibase 회귀 케이스는 계속 유지합니다.

### PostgreSQL·Pagila 검증 결과 파일

자체 PG18 추출물 보고서는 `test/target/postgresql18/reports/report.html`, 실제 생성 결과는 같은 그룹의 `db-validation.json`입니다. Pagila는 원본 `pagila-schema.sql`만 사용하며 `test/target/postgresql18-pagila/reports/report.html`과 `db-validation.json`에 결과를 남깁니다. Pagila의 원본 커밋·SHA256·라이선스 설명은 `test/source/postgresql18-pagila/schema/`에 보존합니다. 데이터 파일은 실행하지 않습니다.

Pagila DB 검증에서는 public·legacy 스키마를 전용 임시 GOLDILOCKS 스키마로 치환해 기존 사용자 객체를 건드리지 않습니다. 보고서와 변환 원본은 원래 스키마 이름을 유지하며, 시험 때 적용한 이름 매핑·객체 생성 순서·오류·VALID 상태는 db-validation.json에 별도 기록합니다. 주석으로 처리한 소스 전용 설정은 실제 생성 객체로 세지 않습니다. 실행 오류 없는 문장 수와 실제 카탈로그 객체 수는 다른 집계입니다.

`sh test/check.sh`에는 PG18 실제 pg_dump 추출물과 Pagila 스키마의 오프라인 회귀 검증이 포함됩니다. 원본 SHA256, 객체 수·유형·상태, 변환 SQL, 규칙·원본 위치가 고정 기준과 같은지 확인합니다. 이 검사는 DB 서버 없이 수행됩니다. 실제 DB 시험은 `python test/postgresql18/live.py`, `python test/postgresql18/pagila.py`로 별도 실행합니다.

PostgreSQL 함수·프로시저의 본문 변환이 미완료인 경우에도 `AS $$…$$`, `AS $_$…$_$`, `AS $body$…$body$`의 바깥 dollar 구분자는 제거한 초안을 제공합니다. 내부 SQL·주석·위치 인자 `$1`, `$2`는 보존하며, 나머지 미변환 사유와 검토 상태는 유지합니다. 구분자 제거만으로 실행 가능한 SQL이 되는 것은 아닙니다. 원본 SQL에는 구분자도 그대로 보존됩니다.

PostgreSQL SQL 표현식의 비한정 `IF(조건, 참값, 거짓값)` 호출은 `CASE WHEN 조건 THEN 참값 ELSE 거짓값 END`로 자동 변환합니다. 괄호로 구분한 세 인자와 중첩 IF를 처리하며 문자열·주석을 보존합니다. PSM의 `IF … THEN … END IF` 제어문과 스키마 지정·따옴표 이름의 사용자 함수는 이 규칙으로 변경하지 않습니다. 주변 INTERVAL·캐스트 등 다른 미변환 항목의 검토 상태는 유지합니다.

PostgreSQL의 후위 캐스트 `표현식::타입`은 대응 타입이 있는 경우 `CAST(표현식 AS 대상타입)`으로 자동 변환합니다. 예: `1::varchar(10)` → `CAST(1 AS VARCHAR(10 CHARACTERS))`. 괄호·함수 호출·CASE·연속 캐스트의 입력 범위를 구분하고, `a+b::integer`는 `a+CAST(b AS NATIVE_INTEGER)`로 처리합니다. JSONB·배열·수식이 필요한 INTERVAL 등 대응이 미확정인 타입과 경계가 불명확한 입력은 원문과 구체적 검토 사유를 유지합니다. 확정된 CAST 변환 자체는 검토에서 제외하며 다른 미지원 타입·구문의 검토 사유는 유지합니다.

### PostgreSQL 식별자 표기 보존

변환기는 원문 식별자에 임의로 쌍따옴표를 추가하거나 이름을 소문자로 바꾸지 않습니다. 테이블·컬럼·스키마·인덱스·제약조건·별칭·루틴 이름·인자·지역 변수 및 참조는 원문의 표기를 유지합니다. 예: `Sales.Customer` → `Sales.Customer`, `"MixedCase"` → `"MixedCase"`. 원문에 있는 쌍따옴표와 이스케이프된 따옴표도 보존합니다. 따옴표 없는 이름의 저장·검색 대소문자는 대상 GOLDILOCKS의 기본 규칙을 따릅니다.

### PostgreSQL 세션 설정 변환

`SET`·`RESET` 및 pg_dump의 `SELECT pg_catalog.set_config(...)` 세션 설정은 검토 목록에서 제외합니다. 확정된 대응은 자동 변환하고, 그 외 설정은 사유와 원문을 주석으로 남깁니다. 자동 처리 내역은 보고서에 보존합니다.

| PostgreSQL 설정 | GOLDILOCKS 처리 |
| --- | --- |
| `statement_timeout` | `ALTER SESSION SET QUERY_TIMEOUT = 초;` |
| `idle_in_transaction_session_timeout` | 사용자 지정 규칙: `ALTER SESSION SET IDLE_TIMEOUT = 초;` |
| `lock_timeout` | 주석 처리. 전체 잠금 대기에 대응하는 속성은 확인되지 않았으며 DDL 전용 속성으로 임의 대체하지 않음 |
| SET LOCAL, DEFAULT, RESET, 그 외 미확정 설정 | 주석 처리 |

PostgreSQL의 단위 없는 timeout 값은 밀리초입니다. `ms`, `s`, `min`, `h`, `d` 단위를 초로 환산해 정수 초이고 대상 범위 0–10000000 이내일 때만 변환합니다. 예: `5000` → `5`, `'2min'` → `120`. 0은 제한 해제이며, 500ms처럼 정수 초로 정확히 표현할 수 없는 값은 반올림하지 않고 주석 처리합니다. IDLE_TIMEOUT은 일반 세션 유휴 시간에 적용되므로 PostgreSQL의 트랜잭션 내부 유휴 시간과 적용 범위가 다르지만, 위 매핑은 사용자가 지정한 변환 정책으로 적용합니다.

근거: [GOLDILOCKS ALTER SESSION](https://manual.sunjesoft.co.kr/goldilocks/26c_1/manual/ko/7e5e0c9e12e61d15), [GOLDILOCKS Server Property](https://manual.sunjesoft.co.kr/goldilocks/26c_1/manual/ko/e95fbf953ce3e17d), [PostgreSQL 18 Client Connection Defaults](https://www.postgresql.org/docs/18/runtime-config-client.html). 개발 시 확인한 근거이며 실행 환경에서 매뉴얼에 접근하지 않습니다.

### PostgreSQL 소유자 변경 구문

`ALTER FUNCTION … OWNER TO …`를 비롯한 객체 소유자 변경 구문은 실행하지 않고 원문을 주석으로 보존하며 검토 대상에서 제외합니다. 자동 처리 내역에는 `PG_OWNER_TRANSFER_COMMENTED`로 기록합니다. 생성 작업의 실행 사용자나 최종 소유자를 자동으로 변경하는 규칙은 아닙니다. 시퀀스의 `OWNED BY`는 컬럼과의 의존 관계를 지정하는 별도 구문이므로 이 소유자 변경 정책에 포함하지 않습니다.

### 정상 자동 변환의 검토 분류

정상 변환된 `CACHE 1 → NOCACHE`, `nextval(정적 시퀀스 이름::regclass) → 시퀀스.NEXTVAL`, `now() → CURRENT_TIMESTAMP`와 지원 타입으로의 `:: → CAST`는 그 변환 자체를 검토 사유로 추가하지 않습니다. DEFAULT의 스키마 지정 시퀀스 참조, 따옴표 없는 `public` 스키마, CAST의 `AS 대상타입`을 공통 문법으로 인식합니다. 다른 미지원 타입·구문·잘못된 시퀀스 범위 등은 해당 문제로만 검토합니다. 원문 식별자나 확정된 변환 SQL을 임의로 수정해 검토를 우회하지 않습니다.

### PostgreSQL 복제 전용 ALTER

`ALTER TABLE … REPLICA IDENTITY NOTHING/FULL/DEFAULT/USING INDEX …`와 `ALTER TABLE … ENABLE REPLICA TRIGGER …` 등 복제 전용 ALTER 구문은 원문을 주석 처리하고 검토 대상에서 제외합니다. `ONLY`가 있는 형식도 동일하게 처리하며 자동 내역은 `PG_REPLICATION_COMMENTED`로 기록합니다. 객체명·컬럼명·문자열에 `replica`가 포함됐다는 이유로 이 규칙을 적용하지 않습니다.

### 보고서 마지막의 자동 규칙 요약표

검토에서 제외한 확정 자동 규칙은 report.html 맨 마지막의 **검토 제외 · 자동 처리 규칙 요약**에 모아 표시합니다. 원문 패턴 A → 변환 결과 B, 규칙 코드, 처리 근거, 건수를 제공합니다. CACHE 1, 지원 타입 CAST·자료형 매핑, NEXTVAL·now(), SET·OWNER·복제 구문의 자동 변환 또는 주석 처리가 대상입니다. 동일 규칙·동일 변환은 한 행으로 합산하며 건수는 객체 수가 아닌 원본 적용 위치 수입니다. 이 규칙들은 객체별 상세 표에서 반복하지 않지만, 원본/변환 SQL과 JSON의 전체 규칙·분석 내역은 보존합니다. 한 객체가 다른 미지원 사항 때문에 검토에 남는 경우는 해당 문제만 별도로 표시합니다.

### 확정 타입·파티션 규칙의 공통 분류

Altibase·Oracle·PostgreSQL 모두 성공적으로 적용한 자료형 매핑과 `partition_rule=remove`에 따른 파티션 제거는 추가 검토에서 제외합니다. 길이 생략 VARCHAR 기본값, 국가문자형, RAW·부동소수점·LOB, PG text/bytea/NUMERIC 등 확정 매핑의 차이는 마지막 자동 규칙 표에서 일괄 확인합니다. 미지원 타입·범위 초과·경계 분석 실패·PRESERVE/REVIEW 설정처럼 실제 변환이 확정되지 않은 경우는 해당 검토를 유지합니다. 이 변경은 분류 정책이며 기존 변환 SQL은 유지합니다.

자동 규칙 표는 **자료형 → 파티션 → 시퀀스 → SQL 함수·표현식 → 세션 설정 → 소유권 → 복제**의 카테고리 순으로 묶습니다. 다른 카테고리의 항목이 중간에 섞이지 않으며 각 행에 카테고리, A→B, 규칙 코드, 근거, 건수가 표시됩니다.

### 문법 케이스별 정적 자동 처리율

개발 환경에서 `python test/coverage/run.py`를 실행하면 기존 문법별 케이스를 Altibase·Oracle·PG별로 재변환하고 `test/target/spec-coverage/summary.html`과 `summary.json`을 생성합니다. 입력 파일 목록·SHA256, 문법군별 결과, CREATE 객체 기준과 전체 SQL 단위 기준을 함께 기록합니다. 소스 문법 오류를 의도한 음성 케이스는 별도 집계합니다. 이 수치는 현재 케이스의 정적 자동 처리율이며 전체 벤더 문법의 지원률이나 DB 실행 성공률을 의미하지 않습니다. 각 벤더의 상세 report.html도 같은 경로 아래에 생성됩니다.

### 벤더별 Word 전환 참고서

아래 문서는 도구 사용법과 별도로, 담당자가 DDL·SQL을 직접 변환할 때 참고하는 기술 가이드입니다. 표지 제목은 22pt로 표시합니다. 첫 장에는 원본·타깃 SQL 전체 구문 비교표를 제공하고 CREATE TABLE의 STORAGE·물리 속성·제약조건·LOB·파티션 하위 절과 객체별 생성문을 함께 정리합니다. 표지에는 벤더별 전환 가이드 제목만 표시하며, 소개와 목차는 각각 별도 페이지로 구성합니다. 문서 정보 표에는 독자·원본 버전·대상 버전·읽는 순서를 표시합니다. 각 객체는 **변환 원칙 → 자료형 대응표 → 원본·타깃 SQL 예제 → 예제별 의미 차이** 순서로 정리합니다.

- [Altibase → GOLDILOCKS](word/Altibase_to_GOLDILOCKS_conversion_guide.docx): Altibase 7.3 기준
- [Oracle → GOLDILOCKS](word/Oracle_to_GOLDILOCKS_conversion_guide.docx): Oracle 19c 기준
- [PostgreSQL → GOLDILOCKS](word/PostgreSQL_to_GOLDILOCKS_conversion_guide.docx): PostgreSQL 18 기준

대상은 GOLDILOCKS Cluster 26c.1입니다. 자료형·날짜/시간대·테이블·저장소·파티션·키·시퀀스·뷰·루틴·커서·예외·컬렉션·패키지·트리거·사용자 정의 타입·권한·DML을 다룹니다. 직접 대응이 없는 객체에는 동일한 SQL을 타깃 예제로 제시하지 않고 대체 설계 방향을 설명합니다. 본문의 예제는 기술 설명용으로 편집한 것이며 특정 변환기 출력이나 변환기의 지원 범위를 나타내지 않습니다. 시간 정밀도는 초·ms(밀리초)·us(마이크로초)로 표기하며, Oracle TIMESTAMP(9)처럼 필요한 경우 ns(나노초)를 명시합니다.

개발자는 원고 `src/docs/guide_examples.json`에서 대응 원칙·예제 설명을 수정한 뒤 다음 명령으로 Word 문서를 재생성합니다. 이 문서 생성기는 DB나 변환 JAR를 호출하지 않습니다. Python은 문서 제작용 개발 환경에만 필요합니다.

```sh
python src/tools/build_conversion_guides.py
python -m unittest discover -s test/docs -v
```

문서는 `src/docs/word/`에 저장됩니다. `manifest.json`은 원고와 문서의 해시 및 개정 번호를 기록합니다. 제품 매뉴얼에서 확인한 문법과 예제에 사용한 설계 정책을 구분하며, 문법·설계 방침이 바뀌면 관련 설명과 예제를 함께 갱신합니다.

### Oracle·PostgreSQL 확장 문법 회귀 입력

`test/source/expanded-oracle/`와 `test/source/expanded-postgresql/`에는 각각 Oracle 19c 및 PostgreSQL 18에서 생성·컴파일을 확인한 직접 작성 SQL을 보관합니다. DBMS_METADATA·pg_dump 추출물과 구분하며, 기존 추출물은 그대로 보존합니다. 확장 입력은 컬럼·인자 모드·반환형·지역 변수·패키지 선언의 자료형, 제약조건·DEFAULT·인덱스·시퀀스·뷰·커서·예외·트리거와 특수 객체를 포함합니다. 타입 별칭과 사용 위치가 다르면 별도 케이스이며, 전체 벤더 문법을 모두 다룬다는 뜻은 아닙니다.

`manifest.json`은 각 파일의 SHA256·문법군·참조 문서와 원본 DB 검증 정보를 기록합니다. 원본 루틴 본문은 호출하지 않습니다. `test/dialect-matrix/source.py`는 개발용 원본 검증기이며 PostgreSQL은 별도 임시 클러스터, Oracle은 실행마다 고유한 접두사를 사용하고 해당 객체만 정리합니다. 이미 고정한 입력은 덮어쓰지 않습니다. 아래 회귀 실행에는 DB가 필요하지 않습니다.

```sh
python test/dialect-matrix/convert.py
python test/dialect-matrix/test_inventory.py
python test/coverage/run.py
```

객체 수·정적 상태·진단·변환 SQL 해시를 `test/dialect-matrix/baseline.json`과 비교합니다. 의도된 변경일 때만 원문·진단·SQL 차이를 확인한 뒤 `convert.py --record`로 기준을 갱신합니다. 변환 결과는 `test/target/expanded-oracle/`, `test/target/expanded-postgresql/`에, 기존 문법 케이스와 합친 보고서는 `test/target/spec-coverage/`에 생성합니다.

처리율의 CREATE 분모는 분석기의 객체 유형 이름 대신 원문의 CREATE 시작 여부로 결정합니다. 따라서 미지원 CREATE가 SQL로 분류되어도 빠지지 않으며 ALTER TRIGGER는 CREATE 분모에 포함하지 않습니다. 이전 Oracle 집계 287개에는 ALTER TRIGGER 4개가 포함되어 있었으므로 같은 CREATE 기준의 보강 전 수치는 283개입니다. 추가 안내는 대응 자동 변환이 실제 적용된 근거가 있을 때 완료에 포함합니다. 원문 유지·미지원 타입 등 실제 미변환 CONFIRM은 검토에 남깁니다. 이 집계는 엔진의 원래 상태·SQL을 변경하지 않으며 정적 처리율과 실제 타깃 DB 생성 성공률은 구분합니다.

뷰 주석은 `COMMENT_VIEW_TO_TABLE` 규칙에 따라 `COMMENT ON VIEW v IS ...`를 `COMMENT ON TABLE v IS ...`로 변환합니다. `COMMENT ON TABLE`은 테이블·뷰의 설명을 지정하며 객체명과 설명 문자열을 보존합니다.

### 컬렉션 DELETE(key)의 반환값 대입 제거

`V_T := V_A.DELETE(1);`은 `V_A.DELETE(1);`로 자동 변환합니다. GOLDILOCKS의 컬렉션 DELETE(key)는 프로시저 호출이므로 사용자 규칙에 따라 반환값 대입만 제거합니다. **V_T에는 삭제 건수를 넣지 않으며 기존 값이 유지됩니다.** 이 규칙은 자동 처리하며 별도 검토 대상으로 분류하지 않습니다.

PSM AST에서 우변 전체가 단일 키의 컬렉션 DELETE 호출인 대입문만 처리합니다. 중첩 블록·여러 줄 구문과 주석을 보존합니다. 원래 단독 호출은 유지하며, 산술식 내부의 DELETE·다중 인자·확인되지 않은 컬렉션 타입은 자동 변경하지 않습니다. 인자 없는 DELETE()의 기존 전체 삭제 규칙은 유지합니다.

```ini
[rule.collection_delete_assignment]
action = AUTO_CONVERT
scope = collection_statement
review = false
```

```sql
-- 원본
V_T := V_A.DELETE(1);
-- 변환
V_A.DELETE(1);
```


## 시노님·계정·롤과 공통 DDL

### SYNONYM

Altibase A7 및 Oracle ORA19의 아래 문법은 GOLDILOCKS 26c.1과 호환되므로 원문 이름·인용·스키마를 보존합니다. 일반 시노님은 추가 검토에서 제외하며 PUBLIC 시노님도 SYNONYM으로 집계합니다.

```sql
CREATE SYNONYM emp_alias FOR app.employee;
CREATE OR REPLACE PUBLIC SYNONYM employee_lookup FOR app.employee;
```

PUBLIC 시노님 이름에는 스키마를 붙일 수 없습니다. `@DBLINK`, `SHARING`, `IF NOT EXISTS`, `ALTER SYNONYM COMPILE` 등 대응이 확정되지 않은 절은 해당 토큰 위치와 구체적인 사유를 검토 항목으로 남깁니다. GOLDILOCKS 26c.1 실제 검증에서 PROCEDURE/FUNCTION 시노님의 생성·호출도 성공했으므로 해당 별칭을 자동 처리합니다. Oracle PACKAGE 별칭의 생성도 확인했습니다. 대상 객체 종류·미생성 여부만으로 시노님을 검토하거나 차단하지 않습니다. 대상 객체가 아직 생성되지 않았다는 이유만으로 검토하거나 차단하지 않습니다.

PostgreSQL PG18에는 객체 별칭용 CREATE SYNONYM 문법이 없습니다. 텍스트 검색의 synonym dictionary와 별개입니다. PostgreSQL 입력에 해당 구문이 있으면 소스 미지원 문법으로 표시합니다. 최상위 DROP SYNONYM은 기존 DROP 안전 규칙에 따라 주석 처리합니다.

### USER / ROLE / GRANT / REVOKE

| 원본 | 처리 |
|---|---|
| Altibase/Oracle CREATE USER … IDENTIFIED BY 비밀번호 | 이름·비밀번호 보존, 지원하는 계정 상태·프로파일 검사 |
| DEFAULT/TEMPORARY/INDEX TABLESPACE | 각각 data_tbs(temp_tbs/index_tbs) 정책 적용. DEFAULT는 table_tablespace/data_tbs, TEMPORARY는 temp_tbs, INDEX는 index_tbs |
| CREATE USER 옵션 순서 | GOLDILOCKS의 인증 → PROFILE → PASSWORD EXPIRE → ACCOUNT → TABLESPACE → SCHEMA 순서로 정리 |
| ALTER USER의 복수 변경 | GOLDILOCKS ALTER USER 단일 동작 문장으로 분리 |
| CREATE ROLE 이름 | 공통 문법 유지 |
| Oracle CREATE ROLE … NOT IDENTIFIED | NOT IDENTIFIED 제거, 비밀번호 없는 ROLE 생성 |
| PostgreSQL CREATE ROLE … NOLOGIN / CREATE USER … NOLOGIN | GOLDILOCKS ROLE 생성 |
| PostgreSQL CREATE USER 또는 CREATE ROLE … LOGIN PASSWORD '평문' | USER IDENTIFIED BY "평문" WITHOUT SCHEMA로 변환하고 CREATE SESSION ON DATABASE 권한 부여 |
| 원본 CREATE에서 로그인 계정임이 확인된 PostgreSQL ALTER USER/ALTER ROLE PASSWORD | ALTER USER … IDENTIFIED BY로 변환 |
| GRANT/REVOKE | 기존 구조 검사 적용. 시스템 권한, 롤 부여, 객체·컬럼 권한 및 ADMIN/GRANT OPTION 구분 |

PostgreSQL 로그인 변환은 별도 스키마를 임의 생성하지 않습니다. 비밀번호가 없거나 NULL·MD5/SCRAM 해시인 경우 대상 비밀번호를 임의 생성하거나 해시를 평문으로 사용하지 않습니다. SUPERUSER·CREATEDB·CREATEROLE·INHERIT·VALID UNTIL·CONNECTION LIMIT 등 미확정 옵션, Oracle 인증 롤·QUOTA·외부 인증, Altibase ACCESS/LIMIT 등은 옵션 이름과 위치를 수동 검토 항목으로 남깁니다. 비밀번호 문자열에 적힌 USER/ROLE 등의 단어는 구문으로 해석하지 않습니다.

### 추가 보강한 공통 SQL

- ALTER FUNCTION/PROCEDURE … COMPILE, ALTER PACKAGE … COMPILE [PACKAGE/SPECIFICATION/BODY]: Altibase/Oracle에서 확인한 GOLDILOCKS 공통 문법 유지.
- ALTER TABLE ADD [COLUMN] 열 정의: ANTLR 컬럼 노드로 구조를 검사하고 CREATE TABLE과 동일한 자료형·기본값·제약조건 매핑 적용.
- ALTER TABLE/INDEX RENAME, ALTER COLUMN SET/DROP DEFAULT·NOT NULL: 지원하는 구조 유지.
- Oracle/Altibase MODIFY (컬럼 NOT NULL/NULL): ALTER COLUMN SET/DROP NOT NULL로 변환. 복수 컬럼·타입 변경은 별도 검토.
- FK의 ON UPDATE/ON DELETE CASCADE, RESTRICT, NO ACTION, SET NULL, SET DEFAULT: GOLDILOCKS 지원 문법으로 인식. 중복되거나 불완전한 동작은 검토.
- COMMIT, ROLLBACK, SAVEPOINT, PostgreSQL RELEASE SAVEPOINT: 구조 검사. ROLLBACK TO 이름은 ROLLBACK TO SAVEPOINT 이름으로 변환.
- CREATE SCHEMA 이름/AUTHORIZATION: Oracle은 AUTHORIZATION 사용자형, PostgreSQL은 이름/AUTHORIZATION형 검사. 내부 CREATE 객체를 포함한 스키마 정의는 별도 분리 규칙 필요.
- 미지원 MATERIALIZED VIEW, PG STATISTICS/EVENT TRIGGER/CONSTRAINT TRIGGER, PK INCLUDE 등은 기능별 이유를 표시. 일반 SYNTAX_REVIEW로 뭉뚱그리지 않음.

자동 변환 설정은 `[rule.user_ddl] scope=account`, `[rule.role_auth] scope=role`, `[rule.transaction_syntax] scope=transaction`, `[rule.alter_column] scope=column_definition`에 `action=AUTO_CONVERT`, `review=false`가 기본입니다. `action=REVIEW` 또는 `PRESERVE`로 해당 수정의 자동 적용을 보류할 수 있습니다. 미지원 기능을 이 설정으로 호환 판정으로 바꾸지는 않습니다.

테스트 입력은 `test/source/identity-synonym/<altibase|oracle|postgresql>/`에 있습니다. 실제 DB 검증 스크립트는 `test/identity_synonym_live.py`이며 `GSQL`, `GOLDILOCKS_TEST_USER`, `GOLDILOCKS_TEST_PASSWORD` 환경변수를 사용합니다. 고유한 임시 이름만 생성·정리하며 운영 객체에는 적용하지 않습니다.

확인한 문법 근거: [GOLDILOCKS CREATE SYNONYM/USER/ROLE](https://github.com/sunjesoft/goldilocks-manuals/blob/main/docs/goldilocks/26c.1/ko/part-03-sql-manual/19-sql-references-c-g.md), [GOLDILOCKS ALTER USER/TABLE](https://github.com/sunjesoft/goldilocks-manuals/blob/main/docs/goldilocks/26c.1/ko/part-03-sql-manual/18-sql-references-a-b.md), [Altibase A7 SQL Reference](https://github.com/ALTIBASE/Documents/blob/master/Manuals/Altibase_7.3/kor/SQL%20Reference.md), [Oracle CREATE SYNONYM](https://docs.oracle.com/en/database/oracle/oracle-database/19/sqlrf/CREATE-SYNONYM.html), [Oracle CREATE USER](https://docs.oracle.com/en/database/oracle/oracle-database/19/sqlrf/CREATE-USER.html), [PostgreSQL SQL 명령 목록](https://www.postgresql.org/docs/18/sql-commands.html), [PostgreSQL CREATE ROLE](https://www.postgresql.org/docs/18/sql-createrole.html), [PostgreSQL CREATE USER](https://www.postgresql.org/docs/18/sql-createuser.html).


## 브라우저 실행 (JRE 1.8 이상)

`java -jar sqlmigrate.jar web` 또는 인자 없는 JAR 실행은 로컬 브라우저 UI를 시작합니다. Windows 배포 ZIP에서는 `run-web.cmd`를 더블클릭합니다. SQL 파일/폴더 선택, INI 불러오기, 분석·변환 진행 상태, HTML 보고서 보기 및 HTML/Excel/전체 결과 ZIP 저장을 제공합니다. `web --config 경로`로 INI를 지정할 수 있고, 생략하면 현재 폴더 및 JAR 옆의 `migrate.ini` 순서로 찾습니다. 없으면 브라우저에서 설정을 입력합니다. 기존 `--config` 일괄 실행과 `review --config` TUI 동작은 유지됩니다. 자세한 실행 방법은 배포 패키지 README와 `browser_quickstart.md`를 참조하십시오.


## 내장 함수 문법과 자동 처리 (0.1.30)

GOLDILOCKS 26c.1 공식 함수 장에서 226개 이름·별칭의 호출 형식과 인자 범위를 분리해 관리합니다. Oracle `LEAST/GREATEST`, 수학·문자·날짜 함수가 원본과 대상 양쪽에서 지원되는 경우 기존 SQL을 유지하고 호환 처리합니다. 이 과정에서 발견한 원인은 함수 허용 목록 누락, 예약어와 함수 이름의 충돌, SQL 특수 호출 형식의 문법 누락입니다. 지역 함수와 입력 파일의 사용자 함수 서명이 내장 함수보다 우선합니다.

`EXTRACT/TRIM/SUBSTRING/POSITION/OVERLAY`, 집계 `FILTER`, 윈도 `OVER`, JSON 생성 함수, CTE 및 하위 질의에 구조 검사를 추가했습니다. DBMS_OUTPUT, DBMS_LOCK.SLEEP, DBMS_SQL.RETURN_RESULT는 대상에서 확인한 서명·프로시저 문맥·OUT 인자를 검사합니다. 미지원 패키지를 이름만 보고 호환 처리하지 않습니다.

함수 이름이 같아도 결과가 달라질 수 있습니다. Altibase LEAST/GREATEST의 문자열 비교·반환 규칙, PostgreSQL LEAST/GREATEST의 NULL 무시 규칙 등은 의미 차이를 표시합니다. 인자 개수·호출 문맥이 틀린 SQL도 검토 대상으로 남습니다.

지원 벤더의 번들 함수 목록 전체에 대해 호출 이름의 ANTLR 인식을 검사합니다. 이는 모든 벤더 SQL 문법이나 실행 결과가 검증되었다는 뜻은 아닙니다. 남은 문법 범위와 검증 기준은 [함수 문법 감사](development/GOLDILOCKS_FUNCTION_GRAMMAR_AUDIT.md)에 기록합니다. 파서가 아직 인식하지 못하는 구문을 GOLDILOCKS 제품 미지원의 근거로 사용하면 안 됩니다.


## Oracle 전용 객체의 수동 검토 (0.1.31)

`CREATE CLUSTER`(Oracle 테이블 클러스터), `CREATE BITMAP INDEX`, `CREATE [SHARED] [PUBLIC] DATABASE LINK`, 독립 객체인 `CREATE TYPE/CREATE TYPE BODY`는 수동 검토로 분류합니다. GOLDILOCKS의 CLUSTER GROUP/LOCATION 및 PSM 안의 지역 RECORD·연관 배열 TYPE 선언과 구분합니다. 원본 SQL을 보존하고 자동으로 키워드를 제거하거나 다른 객체로 치환하지 않습니다. 클러스터 저장 구조·인덱스 성능·원격 연결 구조·타입 의존 객체를 함께 검토해야 합니다.


## PostgreSQL SERVER/PUBLICATION 및 SERIAL (0.1.34)

`CREATE SERVER`와 `CREATE PUBLICATION`은 GOLDILOCKS 26c.1의 동일 생성 구문이 없어 수동 검토로 분류합니다. SERVER는 외부 테이블·사용자 매핑·접속/인증 구성을, PUBLICATION은 발행 대상·DML 옵션·구독 구성을 함께 검토합니다.

단일 `smallserial/serial/bigserial`과 별칭 `serial2/serial4/serial8`은 크기에 맞는 `NATIVE_SMALLINT/NATIVE_INTEGER/NATIVE_BIGINT GENERATED BY DEFAULT AS IDENTITY`로 변환합니다. 원본 보조 시퀀스 이름·소유 관계에 대한 확인은 일반 자료형 변환 확정 처리와 별도로 유지합니다. 한 테이블의 복수 SERIAL 열은 대상의 테이블당 IDENTITY 1개 제한 때문에 수동 검토로 분류합니다.

2026-10-26 구동 중인 GOLDILOCKS에서 변환 결과를 실제 생성해 SERIAL 계열 여섯 이름 모두 검증했습니다. DISK_DATA_TBS를 사용한 독립된 임시 테이블에서 자동 값 1/2/3, 명시값 100, signed 정수 최솟값·최댓값 저장, 범위 초과 거부를 확인한 후 모두 정리했습니다. 복수 IDENTITY 열 생성 거부도 확인했습니다. 이는 해당 변환 사례의 생성·입력 검증이며 다른 SQL 전체의 실행 검증을 의미하지 않습니다.


## Altibase 호환성 판정 보강 (0.1.34 유지)

- `CREATE [PUBLIC] DATABASE LINK`와 `GEOMETRY` 컬럼·PSM 변수는 대상 대응 기능이 없어 수동 검토로 분류합니다.
- `BYTE(n)`의 명시 길이 1..2000은 BINARY(n), 2001..32000은 LONG VARBINARY로 변환합니다. 긴 BYTE의 기본값 패딩이나 키 제약조건은 별도 수동 검토합니다. LONG VARBINARY에는 원본 바이트열 전체를 적재해야 하며 고정 길이 자동 패딩은 재현되지 않습니다.
- `LEAST/GREATEST`의 문자열 인자는 자동 호환 처리합니다. Altibase 매뉴얼의 문자열 비교·VARCHAR 반환과 대상 첫 인자 타입 기준 규칙이 달라지는 숫자·혼합 인자는 반환 타입·비교 의미 차이 때문에 추가 확인으로 분류합니다.

### 입력변환 판정 건수와 비율

입력변환 창의 요약은 **전체 N건**을 먼저 표시한 뒤 자동변환(호환)·추가 확인·수동 검토의 건수와 비율을 표시합니다. 분모는 객체 수가 아니라 해결된 항목을 제외한 전체 판정 항목 수이며, 분류 필터를 바꿔도 동일합니다. 자동변환(호환)은 AUTO와 COMPATIBLE을 합산합니다. 항목이 없으면 전체 0건과 각 0.0%를 표시합니다. 소수점 한 자리 반올림으로 비율 합계가 100%와 다를 수 있습니다.

Oracle 스크립트의 `rem` 단독 줄, 저작권 안내와 구분선이 있는 REM 줄, PROMPT 줄 및 SQL*Plus 전용 SET 줄은 원문을 남긴 `-- rem ...` 형식의 행 주석으로 자동 변환합니다. 뒤 SQL 본문의 문자열·괄호 오류가 있어도 앞에서 독립적으로 인식한 명령은 주석 변환하고, 오류가 있는 나머지 본문은 별도 검토 대상으로 보존합니다.

### SQL*Plus 명령의 공통 처리 (0.1.35)

입력변환 창이 메인 화면의 DB 선택을 상속해도 REM/REMARK·PROMPT·SQL*Plus 전용 SET 줄은 DB 종류와 관계없이 `--` 행 주석으로 자동 변환합니다. `rem` 단독 줄과 `rem ----`, `rem ****` 구분선도 AUTO로 처리하며 추가 확인으로 남기지 않습니다. SQL 문자열·루틴 내부 변수 및 실제 SQL SET 구문은 기존 보호 규칙을 유지합니다.

### VIEW 진단과 문제 행 강조 (0.1.36)

COALESCE와 일반 집계·JOIN VIEW의 기존 호환 판정은 유지합니다. SELECT 분석 실패 위치가 JSON_TABLE 또는 LISTAGG의 ON OVERFLOW 절이면 일반 괄호/파서 메시지 대신 해당 기능과 정확한 위치를 수동 검토로 표시합니다. GOLDILOCKS 26c.1 매뉴얼에서 해당 기능/옵션의 지원을 확인하지 못했다는 근거와 대체 구현 또는 의미 차이 확인 안내를 제공하며, 실제 DB에서 미지원이 확정됐다는 뜻은 아닙니다. LISTAGG 자체를 미지원으로 분류하거나 ON OVERFLOW 옵션을 임의로 제거하지 않습니다.

입력변환과 HTML 보고서에서 판정 항목을 선택하면 원문과 변환문의 실제 문제 행을 강조합니다. 진단의 원문 조각이 객체 전체인 경우에도 CREATE VIEW 첫 줄 대신 진단 행을 찾습니다. 다른 규칙이 문장을 변경했거나 사용자 편집으로 판정이 오래된 경우에는 기존 하이라이트 보호 정책을 유지합니다.

### GROUPING SETS·ROLLUP·CUBE 인식 (0.1.37)

GOLDILOCKS 26c.1의 GROUP BY 문법에 맞춰 GROUPING SETS, 빈 그룹 `()`, 복합 그룹 `(a,b)`, 중첩 GROUPING SETS, ROLLUP·CUBE 및 GROUP BY ALL/DISTINCT를 인식합니다. GROUPING SETS·ROLLUP·CUBE는 일반 함수 호출과 구분하며, 그룹 키 안의 COALESCE 등 표현식도 기존 SQL 분석으로 검사합니다. 인식한 그룹 구성은 호환·원문 유지로 표시하고 선택 시 해당 행을 강조합니다. Oracle `store_orders` VIEW는 원문을 유지하며 호환 처리됩니다. 빈 GROUPING SETS 목록, 빈 ROLLUP/CUBE 인자 및 잘못된 구문은 계속 검토 대상으로 남깁니다.

공유 조회문 분석을 사용하므로 VIEW·일반 SELECT·PSM 내부 SELECT에 적용됩니다. 이 변경은 정적 문법 판정 보강이며, 테이블·컬럼·데이터 타입의 실제 유효성 및 결과 동등성을 대상 DB에서 실행 검증한 것은 아닙니다. 근거: [GOLDILOCKS GROUP BY 문법](https://github.com/sunjesoft/goldilocks-manuals/blob/main/docs/goldilocks/26c.1/ko/part-03-sql-manual/20-sql-references-h-z.md#14659507262e5348).

### 암시적 커서 FOR 및 동적 SQL 판정 (0.1.38)

`FOR r IN (SELECT ...) LOOP`는 GOLDILOCKS가 지원하는 암시적 커서이며, 별도 커서 선언을 요구하지 않습니다. 조회문의 표현식·조건을 검사하고 행 레코드를 루프 범위에 연결합니다. 다중 컬럼 조회를 스칼라 하위 조회로 취급하지 않습니다. 명시적 커서의 선언·인자 검사와 정수 FOR 루프 검사는 유지합니다.

문자열 변수·표현식을 사용하는 EXECUTE IMMEDIATE는 지원 문법으로 호환 표시합니다. 실행 시 결정되는 내부 SQL은 **추가 확인(CONFIRM)** 으로 분리하며, 미지원 또는 실행 불가라는 뜻이 아닙니다. 해당 명령 행을 강조하고 원문을 유지합니다. 문자열 타입 오류, 잘못된 OUT 바인딩 및 확정 가능한 SQL의 구문 오류는 기존 수동 검토를 유지합니다. 정적 분석은 실제 DB에서 동적 SQL을 실행하지 않습니다.

### IDENTITY 열 문법 누락 보강 (0.1.39)

기존 열 후행 절 검사와 TableDdlParser에 GENERATED ... AS IDENTITY 규칙이 빠져, 지원 구문도 COLUMN_CLAUSE_REVIEW로 표시되는 원인을 수정했습니다. 테이블 ANTLR 문법과 기존 열 검사가 같은 IDENTITY 문법·옵션 검사를 사용합니다. 사용자 실행 확인 사례인 Oracle NUMBER GENERATED ALWAYS AS IDENTITY는 타입과 IDENTITY를 유지하며 자동 처리(호환)로 분류합니다. VARCHAR2 정규화·OCTETS 지정·기본키 분리는 기존 정책대로 적용합니다. IDENTITY 판정 선택 시 기본키 분리 이후에도 원문과 변환문의 해당 행을 강조합니다.

ALWAYS/BY DEFAULT 및 START WITH·INCREMENT BY·MINVALUE·MAXVALUE·CYCLE·CACHE와 NO 옵션의 확인된 문법을 인식합니다. 미확인 확장 옵션, 잘못된 옵션 값·중복, DEFAULT와 IDENTITY 혼용, 복수 IDENTITY 열은 검토 대상으로 남깁니다. 기존 IDENTITY 테스트가 추가 확인 진단의 부재를 검사하지 못한 공백도 회귀 테스트로 보강했습니다. 이 변경에서 실제 DB의 테이블 생성은 수행하지 않았습니다.

### 이름 없는 UNIQUE 및 내장 기본값 (0.1.40)

이름 없는 UNIQUE도 PK와 동일하게 DB 자동 명명·기본 인덱스 배치를 허용하는 기본 정책으로 호환 처리합니다. 원본 이름이 없다는 사실은 추가 확인 대상이 아닌 정보 안내입니다. 새로운 이름을 만들거나 index_tbs를 강제로 적용하지 않으며, 기존 이름이 있는 제약조건 정책은 그대로 유지합니다.

열 기본값의 내장 값 인식을 별도 고정 목록에서 GOLDILOCKS 내장 VALUE 목록과 연계했습니다. DEFAULT SYSTIMESTAMP 및 DEFAULT USER는 원문을 유지하고 호환으로 처리합니다. USER는 대상 DB에서 읽기 전용 SELECT로 확인한 값 별칭으로 목록에 등록했습니다. SYSTIMESTAMP·USER·CURRENT_USER의 SELECT 인식은 확인했으며, 이번 변경에서 사용자 테이블을 생성하거나 수정하지 않았습니다. 알려지지 않은 함수·잘못된 인자 형식은 계속 검토합니다.

### 숫자 문자열 연결·날짜 산술·자율 트랜잭션 진단 (0.1.41)

숫자(NUMBER·INTEGER 계열)와 문자열의 `||` 연결은 대상의 암시적 문자열 변환을 허용하며 원문을 유지합니다. 문자열 타입만 허용하던 연산자 검사에서 발생한 숫자→문자열 오진을 제거했습니다. 이 변경을 모든 문자열 인자 문맥으로 확대하지 않으며, 숫자만을 EXECUTE IMMEDIATE SQL 본문으로 전달하는 등의 타입 검사는 유지합니다.

DATE ± 숫자(일수), 숫자 + DATE, DATE - DATE의 숫자형 일수 결과를 인식합니다. TRUNC에 날짜/타임스탬프가 들어오면 DATE 반환형으로 추론하고, 열 타입이 알려지지 않으면 임의로 확정하지 않습니다. forecast_reorder_qty의 NUMBER 일수 파라미터가 DATE→INTEGER 오류로 표시되던 문제를 수정했습니다. 전체 함수는 입력 SQL을 보존하며 호환 분류합니다.

검증한 DB에서 숫자 문자열 연결 SELECT, 날짜에서 숫자·숫자 바인드 변수를 빼는 SELECT, 날짜 차이와 가중치 계산(1일 차이·가중치29)을 확인했습니다. 오류 메시지 프로시저와 전체 forecast 함수는 구문 준비만 통과했으며 생성·호출하지 않았습니다. PRAGMA AUTONOMOUS_TRANSACTION은 정상 프로시저 대조군과 달리 구문 준비 단계에서 SQLSTATE 42000/코드16062 오류가 확인됐습니다. 해당 지시문은 구체적인 수동 검토로 표시하며 자동 제거하지 않습니다. 제거 시 내부 COMMIT과 호출자 트랜잭션의 관계가 바뀌므로 독립 로그 저장 방식의 별도 설계가 필요합니다.

### Altibase INSERT 리터럴 (0.1.42)

Altibase INSERT의 `''`는 GOLDILOCKS에서도 NULL로 처리되므로 자동 호환으로 분류하고 원문을 유지합니다. `' '` 공백은 NULL로 바꾸지 않습니다. 기존 SELECT 조건 등 다른 문맥의 검토 정책은 유지합니다.

`BIGINT'3'`는 GOLDILOCKS 원문 호환 문법이 아니므로 `CAST('3' AS BIGINT)`로 자동 변환합니다. 부호를 포함한 64비트 정수 범위를 검사하며, 잘못된 정수·범위 초과는 원문을 보존하고 검토 대상으로 표시합니다. 문자열 내부 내용과 주석은 변환하지 않습니다.

검증 DB에서 읽기 전용 SELECT로 빈 문자열/공백/DATE NULL 변환과 CAST를 확인했습니다. 전체 INSERT의 실행 성공이나 날짜 문자열의 형식 호환성을 보장하는 검증은 아닙니다.

### Altibase AUTOCOMMIT (0.1.43)

`ALTER SESSION SET AUTOCOMMIT = TRUE;`는 `SET AUTOCOMMIT ON;`, `FALSE`는 `SET AUTOCOMMIT OFF;`로 자동 변환합니다. 결과는 gsql 클라이언트 명령입니다. JDBC SQL로 직접 실행하는 문장이 아닙니다. 대소문자 및 중간 주석을 처리하고, TRUE/FALSE 이외 값과 추가 옵션은 기존 검토 정책을 유지합니다.


### Oracle 감사 정책과 비밀번호 PROFILE (0.1.44)

`CREATE/ALTER AUDIT POLICY`, `AUDIT/NOAUDIT POLICY`, `CREATE/ALTER PROFILE`의 Oracle→GOLDILOCKS 공통 범위를 처리합니다. 감사 정책은 접근 제한이 아니라 행위 기록이며, PROFILE은 비밀번호 주기·잠금·재사용 정책입니다. PG의 행 보안 CREATE POLICY 및 Altibase AUDIT과 일괄 치환하지 않습니다.

PROFILE은 FAILED_LOGIN_ATTEMPTS, PASSWORD_LOCK_TIME, PASSWORD_LIFE_TIME, PASSWORD_GRACE_TIME, PASSWORD_REUSE_MAX, PASSWORD_REUSE_TIME과 PASSWORD_VERIFY_FUNCTION의 NULL/DEFAULT를 처리합니다. 일수의 정수/분수는 유지하고 소수는 정확한 분수로 바꿉니다. CPU·세션 자원 제한, INACTIVE_ACCOUNT_TIME, PASSWORD_ROLLOVER_TIME, CONTAINER와 검증 함수는 별도 검토합니다. 이름이 같은 내장 비밀번호 검증 정책도 원본 함수 본문과 완전히 같다고 보지 않습니다. DEFAULT/생략 값은 대상 DEFAULT profile에서 결정되며 원본 DEFAULT 값을 자동 조회·복사하지 않습니다. 기존 USER 규칙으로 `ALTER USER app_user PROFILE app_profile;`을 처리합니다.

감사 정책의 공통 객체 action과 롤/권한 목록은 유지하고 생성과 활성화를 분리합니다. WHEN/EVALUATE 조건, ONLY TOPLEVEL, CONTAINER, COMPONENT, BY USERS WITH GRANTED ROLES 및 확인하지 않은 action은 제거하지 않고 해당 위치를 표시합니다. 전체 action인 ALL도 DB별 감사 대상 집합 차이 때문에 검토로 남깁니다. 통합 감사는 Oracle12c 이상이며 Oracle19 매뉴얼을 기준으로 비교했습니다. 실제 top-level DROP은 기존 안전 차단을 유지합니다.

자세한 지원 범위·예제·매뉴얼 근거는 [감사 정책·PROFILE 규칙](development/ORACLE_SECURITY_POLICY.md)을 참조하세요. 정적 분석과 DB 생성/보안 동작 검증은 별도이며 이번 기능의 실제 DB DDL 실행은 수행하지 않았습니다.
